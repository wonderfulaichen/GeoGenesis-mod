package com.geogenesis.worldgen.hydrology;

import com.geogenesis.worldgen.hydrology.riverline.RiverLineRegion;
import com.geogenesis.worldgen.terrain.CellGenerator;
import com.geogenesis.worldgen.terrain.TerrainParams;

import java.util.LinkedHashSet;
import java.util.Set;

/** 扫描多个 chunk 统计真实灌水列，验证水文河流有水。 */
public final class HydrologyWaterFillProbe {
    private HydrologyWaterFillProbe() { }

    public static void main(String[] args) {
        long seed = args.length > 0 ? Long.parseLong(args[0]) : 12345L;
        double horizontalScale = args.length > 1 ? Double.parseDouble(args[1]) : 2.0;
        // ★ 多种子扫描（2026-09-06）：干河段是【概率性】缺陷。单种子只覆盖 ~144 个
        //   含河 chunk，8 个种子全为 0 仍复现不了玩家世界里的一条干槽——这类问题
        //   必须放大样本量。第 3 个参数 = 扫描种子数：
        //   gradlew runHydrologyWaterFillProbe -PprobeArgs="12345 2.0 60"
        int sweep = args.length > 2 ? Math.max(1, Integer.parseInt(args[2])) : 1;
        if (sweep > 1) {
            System.out.println("=== HydrologyWaterFillProbe SWEEP base=" + seed
                    + " count=" + sweep + " ===");
            for (int i = 0; i < sweep; i++) {
                long sd = seed + i * 7919L;
                System.out.println("---- seed=" + sd + " ----");
                probeOne(sd, horizontalScale);
            }
            return;
        }
        probeOne(seed, horizontalScale);
    }

    private static void probeOne(long seed, double horizontalScale) {
        TerrainParams params = TerrainParams.defaults();
        CellGenerator terrain = new CellGenerator(params, params.minY(), params.maxY());
        terrain.seed(seed);
        HydrologyExperimentEngine engine = new HydrologyExperimentEngine(terrain, seed);
        int chunks = 0, riverChunks = 0, waterColumns = 0, invalid = 0, uplift = 0;
        int surfaceAboveTerrain = 0, filledAboveTerrain = 0;
        int channelColumns = 0, dryChannel = 0, suspended = 0;
        int noWaterBlock = 0;   // 连续门控通过、但取整后水柱区间为空（游戏内可见的断流）
        int bankColumns = 0, bankOverflow = 0;
        int estuaryColumns = 0, estuaryCarved = 0;
        double seaLevelY = terrain.heightCurve().seaLevelY();
        double maxErosion = 0.0;
        Set<Long> riverChunkKeys = new LinkedHashSet<>();
        for (int rz = -1; rz <= 1; rz++) for (int rx = -1; rx <= 1; rx++) {
            RiverLineRegion region = engine.network().region(rx, rz);
            for (RiverLineRegion.RiverPolyline river : region.rivers) {
                for (var node : river.nodes) {
                    int bx = (int) Math.floor(node.x() * horizontalScale);
                    int bz = (int) Math.floor(node.z() * horizontalScale);
                    riverChunkKeys.add(pack(Math.floorDiv(bx, 16), Math.floorDiv(bz, 16)));
                    if (riverChunkKeys.size() >= 144) break;
                }
                if (riverChunkKeys.size() >= 144) break;
            }
        }
        for (long key : riverChunkKeys) {
            int cx = (int) (key >> 32), cz = (int) key;
            chunks++;
            double[] ground = ground(terrain, cx, cz, horizontalScale);
            var columns = HydrologyBlockCarver.carveChunk(engine, cx, cz, horizontalScale, ground);
            if (columns.isEmpty()) continue;
            riverChunks++;
            for (HydrologyBlockCarvedColumn column : columns) {
                if (column.fillWater()) waterColumns++;
                if (!Double.isFinite(column.carvedGroundY())
                        || column.carvedGroundY() > column.originalGroundY()) invalid++;
                if (column.carvedGroundY() > column.originalGroundY() + 1e-9) uplift++;
                // 切穿列（水面高于雕刻前地形、河床已切到水面下）是预期行为，仅计数。
                if (column.waterSurfaceY() > column.originalGroundY() + 1e-9) {
                    surfaceAboveTerrain++;
                    if (column.fillWater()) filledAboveTerrain++;
                }
                // 核心不变量：河道半宽内（命中最近段 dist<=width）不允许干列。
                var samples = engine.sampleBlockAll(column.blockX(), column.blockZ(), horizontalScale);
                // width > 80 block 为湖命中（lakeRadius×2×scale），湖缘本就不要求满灌。
                if (!samples.isEmpty() && samples.get(0).width() <= 80) {
                    double d = samples.get(0).distToCenter();
                    double w = samples.get(0).width();
                    // 湿核心带（≤0.7w）必须有水；河缘带允许因地形高于水面而不灌（那是岸）。
                    if (d <= w * 0.7) {
                        channelColumns++;
                        if (!column.fillWater()) {
                            dryChannel++;
                            if (dryChannel <= 8) {
                                var s0 = samples.get(0);
                                System.out.printf("dry: bx=%d bz=%d dist=%.2f width=%.2f "
                                                + "orig=%.2f carved=%.2f ws=%.2f depth=%.2f%n",
                                        column.blockX(), column.blockZ(),
                                        s0.distToCenter(), s0.width(),
                                        column.originalGroundY(), column.carvedGroundY(),
                                        column.waterSurfaceY(), s0.depth());
                            }
                        }
                        if (column.carvedGroundY() >= column.waterSurfaceY()) suspended++;
                        // ★ 块空间干槽（2026-09-06）：上面那条 dryChannel 查的是【连续】门控
                        //   fillWater()（carved < ws − 0.5），但真正落块时水柱只占
                        //   y ∈ (floor(carved), floor(max(ws,lip))] 这段【整数】区间。
                        //   连续门控允许 carved 与 ws 落在同一整数层（ws=69.90/carved=69.35
                        //   → floor 均为 69），此时 y=69 被河床块占掉、水柱区间为空：
                        //   该列铺出沙质河床却一个水块都没有 → 游戏内河中段凭空断流。
                        //   实测 60 种子 × ~1.5 万核心列按连续判据全为 0，而玩家世界能看见，
                        //   根因就在这道没被建模的取整。必须按落块口径复核。
                        double topY = Math.max(column.waterSurfaceY(), column.lipSurfaceY());
                        if (column.fillWater()
                                && Math.floor(topY) <= Math.floor(column.carvedGroundY())) {
                            noWaterBlock++;
                            if (noWaterBlock <= 8) {
                                System.out.printf("noWaterBlock: bx=%d bz=%d carved=%.2f "
                                                + "ws=%.2f lip=%.2f floorBed=%d floorTop=%d%n",
                                        column.blockX(), column.blockZ(),
                                        column.carvedGroundY(), column.waterSurfaceY(),
                                        column.lipSurfaceY(),
                                        (int) Math.floor(column.carvedGroundY()),
                                        (int) Math.floor(topY));
                            }
                        }
                    }
                    // 河缘带（会灌水且靠近河岸）：水面必须低于原始地形，
                    // 否则水会从河缘漫到地面上，表现为"一侧河岸被水盖过"。
                    // 河心列（d <= 0.7w）允许水面高于原地形——那是切穿出的河槽，属正常。
                    if (d > w * 0.7 && d <= w) {
                        bankColumns++;
                        // ★ 海床列豁免（2026-09-06）：本判据要抓的是"河水漫到【陆地】上"。
                        //   若原始地面本就低于海平面，那列是海床，那里的水是【海水】，
                        //   不是河漫出去的水。实测 20 种子全部 bankOverflow 命中列
                        //   orig=62.13~62.92 均 < 海平面 63、ws=63.00~63.06，且
                        //   floor(ws)=63 与海面同高 → 落块后就是海水，无任何可见异常。
                        //   （此前把它当作细流带来的回退，对照后确认细流关闭态更多：4 vs 3）
                        if (column.fillWater()
                                && column.originalGroundY() >= seaLevelY
                                && column.waterSurfaceY() > column.originalGroundY() + 1e-6) {
                            bankOverflow++;
                            if (bankOverflow <= 8) {
                                System.out.printf("bank: bx=%d bz=%d dist=%.2f width=%.2f "
                                                + "orig=%.2f ws=%.2f%n",
                                        column.blockX(), column.blockZ(), d, w,
                                        column.originalGroundY(), column.waterSurfaceY());
                            }
                        }
                    }
                }
                // 河口延伸：地形低于海平面且仍命中河线的列，应有雕刻量向海延伸，
                // 而不是在海岸线处直接截断（fadeE 二值化为 0 时 estuaryCarved 会恒为 0）。
                if (column.originalGroundY() < seaLevelY && !samples.isEmpty()
                        && samples.get(0).width() <= 80) {
                    estuaryColumns++;
                    if (column.erosion() > 1e-3) estuaryCarved++;
                }
                maxErosion = Math.max(maxErosion, column.erosion());
            }
        }
        System.out.println("=== HydrologyWaterFillProbe ===");
        System.out.println("seed=" + seed + " horizontalScale=" + horizontalScale);
        System.out.println("chunks=" + chunks + " riverChunks=" + riverChunks);
        System.out.println("waterColumns=" + waterColumns + " channelColumns=" + channelColumns
                + " dryChannel=" + dryChannel);
        System.out.println("invalid=" + invalid + " uplift=" + uplift + " suspended=" + suspended);
        System.out.println("noWaterBlock=" + noWaterBlock
                + " (门控判定有水、但取整后水柱区间为空 = 游戏内断流干槽)");
        System.out.println("bankColumns=" + bankColumns + " bankOverflow=" + bankOverflow
                + " (河岸带水面高于原始地形 = 一侧河岸被水盖过)");
        System.out.println("surfaceAboveTerrain=" + surfaceAboveTerrain
                + " filledAboveTerrain=" + filledAboveTerrain + " (含河心切穿列，预期>0)");
        System.out.println("estuaryColumns=" + estuaryColumns + " estuaryCarved=" + estuaryCarved
                + " (入海列中有雕刻延伸的数量，用于确认河口不再截断)");
        System.out.println("maxErosion=" + maxErosion);
        System.out.println("status=" + (waterColumns > 0 && channelColumns > 0
                && dryChannel == 0 && noWaterBlock == 0
                && invalid == 0 && uplift == 0 && suspended == 0
                && bankOverflow == 0 ? "PASS" : "FAIL"));
    }

    private static long pack(int x, int z) {
        return ((long) x << 32) | (z & 0xffffffffL);
    }

    private static double[] ground(CellGenerator terrain, int cx, int cz, double scale) {
        double[] values = new double[256];
        for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
            values[x * 16 + z] = terrain.sample((cx * 16 + x) / scale,
                    (cz * 16 + z) / scale).height;
        }
        return values;
    }
}
