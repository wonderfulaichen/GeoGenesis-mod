package com.geogenesis.worldgen.hydrology.riverline;

import com.geogenesis.worldgen.hydrology.riverline.MidpointDisplacement.Node;

import java.util.List;

/**
 * 一个 region 的河流网络（物理范式，2026-08-28 重写）。
 *
 * <p>河网从地形汇流场"流"出来：高位布源 → 沿 D8 下坡追踪 → 汇入已有河，
 * 形成树状水系。每条河 {@link RiverPolyline} 携带节点折线 + 逐节点
 * 水面（= 当地地表谷底，Streams 范式）+ 半宽 + 河深。</p>
 */
public final class RiverLineRegion {

    /** 一条河（支流或主流）：折线节点 + 逐节点水面/半宽/河深。 */
    public static final class RiverPolyline {
        public final Node[] nodes;
        public final double[] surfaceY;   // 水面世界 Y（= 当地地表谷底）
        public final double[] width;      // 半宽（block）：由汇流面积驱动
        public final double[] depth;      // 河深（block）
        /** 逐节点跌水落差（block）：0 = 普通河段；>0 = 本节点位于跌水潭侧，供水幕填充。 */
        public final double[] fallDrop;
        /**
         * 分支层级（Strahler 式）：1 = 直接入海/入湖的河（干流）；
         * n+1 = 汇入 n 级河的支流。用于诊断"分支的分支"是否生成
         * （层级 1 占绝对多数 = 只有干流没有支系；出现 3、4 级 = 树状水系成型）。
         */
        public final int level;
        /**
         * 逐节点湖面（2026-09-07 河成湖）：NaN = 普通河节点；有限值 = 该节点在
         * 低梯度"河成湖"段内，值为湖面高程（全段水平）。null = 本河未检测。
         */
        public final double[] lakeLevel;
        /**
         * 逐节点【build 时刻】地形 Y（2026-09-07 侵蚀修复配套）：水面 cap 用的正是
         * 这份 terrainY（sampleWu 含侵蚀 tile），而侵蚀 tile 的河网雕刻层随注册时序
         * 变化，探针事后重采样无法复现（WaterfallProbe 实测：事后 sampleWu 得
         * wellViolation=47，sample() 又与生产脱节）。存下 build 时刻值，探针即可
         * 精确复核"水面 ≤ 当时的地形"。null = 旧折线（未记录）。
         */
        public final double[] terrainY;
        /**
         * ★ 2026-09-22 逐节点所属【生产湖】（与 {@link #lakeLevel} 平行，null = 无）：
         * 入湖锚点段必须有它 ⇒ 发出的是【湖命中】(isLake=true + LakeNode)
         * ⇒ 雕刻侧走湖分支（不挖地、水面取雕刻侧湖面）⇒ 河湖水位【同源齐平】。
         */
        public final LakeNode[] lakeNodes;

        public RiverPolyline(Node[] nodes, double[] surfaceY, double[] width,
                             double[] depth, double[] fallDrop, int level) {
            this(nodes, surfaceY, width, depth, fallDrop, level, null, null, null);
        }

        public RiverPolyline(Node[] nodes, double[] surfaceY, double[] width,
                             double[] depth, double[] fallDrop, int level, double[] lakeLevel) {
            this(nodes, surfaceY, width, depth, fallDrop, level, lakeLevel, null, null);
        }

        public RiverPolyline(Node[] nodes, double[] surfaceY, double[] width,
                             double[] depth, double[] fallDrop, int level, double[] lakeLevel,
                             double[] terrainY) {
            this(nodes, surfaceY, width, depth, fallDrop, level, lakeLevel, terrainY, null);
        }

        public RiverPolyline(Node[] nodes, double[] surfaceY, double[] width,
                             double[] depth, double[] fallDrop, int level, double[] lakeLevel,
                             double[] terrainY, LakeNode[] lakeNodes) {
            this.nodes = nodes;
            this.surfaceY = surfaceY;
            this.width = width;
            this.depth = depth;
            this.fallDrop = fallDrop;
            this.level = level;
            this.lakeLevel = lakeLevel;
            this.terrainY = terrainY;
            this.lakeNodes = lakeNodes;
        }
    }

    /**
     * 湖泊节点：湖面展平 + 半径/淡出（PL-RGA outlet_local_minimum）。
     *
     * <p><b>2026-09-07 起改由 priority-flood 洼地提取生成</b>（此前只在"河 trace 撞
     * 内流洼地"时按河节点水面造一个，实测 0 个——本地形闭合洼地极少）：</p>
     * <ul>
     *   <li>{@code height} = 洼地溢出高程（spill），不是河节点水面——只有取 spill
     *       才能保证"湖面 = 溢出口坎高"，与下游续流河水面连续；</li>
     *   <li>{@code radius} = 按洼地面积换算的半径（wu），取代原来的全局 lakeRadius；</li>
     *   <li>{@code depth} = 最大水深（block），仅用于诊断——<b>湖不挖地</b>：
     *       洼地天然低于 spill，雕刻只铺水面、保留自然盆底。</li>
     * </ul>
     */
    public static final class LakeNode {
        public final double x, z;     // 世界坐标（wu，湖心 = 洼地格形心）
        public final double height;   // 湖面世界 Y（= 洼地溢出高程 spill，无侵蚀基线的坎高）
        public final double radius;   // 湖面半径（wu，按洼地面积换算）—— 仅诊断/包围盒，不用于命中
        public final double depth;    // 最大水深（block，诊断用）
        // ===== 逐格洼地轮廓（2026-09-09 B1：取代圆盘命中）=====
        /** 洼地格中心 wu（与 cellZ 平行数组）；null = 旧式（无轮廓，退化为圆盘）。 */
        public final double[] cellX;
        /** 洼地格中心 wu。 */
        public final double[] cellZ;
        /** 单格覆盖半宽（wu）= gridCell/2；格方块 = 中心 ± cellHalf。 */
        public final double cellHalf;
        // ===== 溢出口坎邻格（2026-09-09 侵蚀短板重算）=====
        //   rim = 湖盆外圈 8 邻中"无侵蚀 spill 高程附近"（fillE ≤ spill+0.05）的格 ——
        //   即真正挡水/溢出的【墙缺口】。侵蚀会削低这些坎 → 湖水位必须随之降低
        //   （短板效应：水从被削低的缺口漏走，旧 spill 包不住）。湖的真正水位 =
        //   min(原 spill, 这些 rim 格的侵蚀后高度)。
        /** 湖盆外圈溢出口坎格中心 wu（与 rimZ 平行）；null = 未记录（用原 spill）。 */
        public final double[] rimX;
        /** 湖盆外圈溢出口坎格中心 wu。 */
        public final double[] rimZ;
        /** 侵蚀后短板水位缓存（lazy，carver 湖分支算一次；NaN=未算）。跨 chunk 复用。 */
        public volatile double erodedSpill = Double.NaN;

        public LakeNode(double x, double z, double height, double radius, double depth) {
            this(x, z, height, radius, depth, null, null, 0.0, null, null);
        }

        public LakeNode(double x, double z, double height, double radius, double depth,
                        double[] cellX, double[] cellZ, double cellHalf) {
            this(x, z, height, radius, depth, cellX, cellZ, cellHalf, null, null);
        }

        public LakeNode(double x, double z, double height, double radius, double depth,
                        double[] cellX, double[] cellZ, double cellHalf,
                        double[] rimX, double[] rimZ) {
            this.x = x; this.z = z; this.height = height;
            this.radius = radius; this.depth = depth;
            this.cellX = cellX; this.cellZ = cellZ; this.cellHalf = cellHalf;
            this.rimX = rimX; this.rimZ = rimZ;
        }

        /** 是否有逐格溢出口坎（决定能否做侵蚀短板重算）。 */
        public boolean hasRim() { return rimX != null && rimX.length > 0; }

        /**
         * 侵蚀后短板水位：min(原 spill, 全部 rim 坎的侵蚀后高度)。
         *
         * <p>侵蚀把溢出口坎削低 → 水位随之降（水从低缺口漏走，包不住）；
         * 侵蚀把坎垫高 → 保持原 spill（水没到更高坎前不漫，内流加深）。
         * 只降不升：无侵蚀 spill 是上界。</p>
         *
         * @param erodedY 侵蚀后地面高度采样（如 CellGenerator.sampleWu(wx,wz).height）
         */
        public double erodedWaterLevel(java.util.function.ToDoubleBiFunction<Double, Double> erodedY) {
            double s = erodedSpill;
            if (!Double.isNaN(s)) return s;
            synchronized (this) {
                s = erodedSpill;
                if (!Double.isNaN(s)) return s;
                double level = height;
                if (rimX != null) {
                    for (int i = 0; i < rimX.length; i++) {
                        double rimH = erodedY.applyAsDouble(rimX[i], rimZ[i]);
                        level = Math.min(level, rimH);
                    }
                }
                erodedSpill = level;
                return level;
            }
        }

        /**
         * ★★★ 2026-09-17【真·短板水位】= 在【侵蚀后地形】上求"最小最大路径逃逸高度" ★★★
         *
         * <h4>为什么必须换掉旧实现</h4>
         * <p>旧实现 = {@code min(无侵蚀 spill, rim 圈各坎的侵蚀后高度)}，其中 rim 只取
         * <b>洼地格 8 邻那一圈</b>。实测（块(-15,661)，路径剖面）证明它<b>不够</b>：</p>
         * <pre>
         *   湖心块(17,752) → 违反点(-15,661)，共 96 块，路径最高地面 = 162.150
         *   而水位却是 166.627  ⇒ 路径上【无坎】，水本应流走 ⇒ 水位过高 ≥4.5 块
         * </pre>
         * <p>根因：<b>侵蚀把出口削低的新位置不在"rim 圈"上</b> ⇒ 旧实现找不到它。</p>
         *
         * <h4>新定义（minimax escape height）</h4>
         * <p>自盆底起，用优先队列按"当前最大高度"做 Dijkstra 式扩展：
         * {@code cost(邻) = max(cost(当前), 邻地面高度)}。当扩展到<b>搜索域边界</b>时，
         * 该 cost 即为"水从此逃逸所需越过的最低高度" ⇒ <b>水温 = 逃逸高度</b>。
         * 这是 priority-flood 的标准语义，且：</p>
         * <ul>
         *   <li><b>含侵蚀</b>（{@code erodedY} 采样的是最终地形）；</li>
         *   <li><b>含大范围</b>（搜索域 = 洼地包围盒 + {@link #ESCAPE_MARGIN}）；</li>
         *   <li><b>对河/湖/海统一</b>（同一个"逃逸高度"概念）。</li>
         * </ul>
         *
         * <p><b>⚠ 2026-09-18 文档校正：由粗到细【尚未实现】。</b>
         * 下述"先按 {@code coarseStep} 粗格扩展锁定逃逸走廊、再在走廊附近按 {@code fineStep}
         * 复算 ⇒ 实测同结果、快 ~13×"是<b>设计意图</b>，非事实：{@code coarseStep} 只经本方法
         * 透传给 {@code computeEscape}，<b>函数体内从未被使用</b>（实际只有 {@code fineStep}
         * 一个阶段）⇒ 该 13× 无实测来源。<br>
         * ⚠ 勿与 {@code FLOOD_COARSE_REUSE} 混淆：那是<b>另一个</b>"由粗到细"（深水区复用粗格
         * BFS 采样），<b>已实现</b>但实测净亏、默认关闭。两者同名不同物，历史讨论中常被张冠李戴。</p>
         *
         * @param erodedY    侵蚀后地面高度采样
         * @param coarseStep 粗格步长（wu），如 24；<b>当前未被使用（见上）</b>
         * @param fineStep   细格步长（wu），如 6
         * @return 逃逸高度（块）；无法求解（域内即溢到海/边界）时返回 {@code NaN}
         */
        public double escapeWaterLevel(
                java.util.function.ToDoubleBiFunction<Double, Double> erodedY,
                double coarseStep, double fineStep) {
            return escapeWaterLevel(erodedY, coarseStep, fineStep, Double.POSITIVE_INFINITY);
        }

        /**
         * ★ 2026-09-17【性能：上界剪枝】真正干活的这个重载。
         *
         * <h4>为何剪枝是<b>严格等价</b>的</h4>
         * <p>调用方 {@code GeoGenesisTerrain} 的语义是 {@code spill = min(spill, escape)}。
         * 若某条路径的"路径最高点"已 &gt; 上界（= 当前水位），则该路径 cost &gt; 上界 ≥ min 的结果
         * ⇒ <b>无论它通向哪里都不可能改变最终采用的水位</b> ⇒ 松弛时可直接丢弃（不再采样其邻居）。
         * 反之，若真实逃逸高度 ≤ 上界，其最优路径上每格都 ≤ 逃逸高度 ≤ 上界 ⇒ 一格都不会被误剪
         * ⇒ 返回值与不剪枝时<b>逐位相同</b>。</p>
         *
         * <p><b>实测收益</b>（ChunkLoadPerfProbe 48×48 chunk）：escape 段占 hydro 的 <b>54%</b>
         * （关掉 LAKE_ESCAPE_LEVEL：hydro 6316→2902ms、单块峰值 4971→1484ms）。
         * 剪枝后只探索"低于当前水位"的格（盆地内部），远小于全域
         * {@code ((bbox+2×240wu)/fineStep)²}（可达 2 万格 × 昂贵的 finalGroundFn）。</p>
         *
         * @param upperBound 上界（调用方传当前水位）；{@code +∞} = 不剪枝（旧行为）
         */
        public double escapeWaterLevel(
                java.util.function.ToDoubleBiFunction<Double, Double> erodedY,
                double coarseStep, double fineStep, double upperBound) {
            // ★ 2026-09-17 修复：原实现以 `escapeLevel != NaN` 当"已算"标记 ⇒
            //   求解失败（返 NaN，这是合法结果"逃逸高度不可达"）时**永不命中缓存**
            //   ⇒ 同一湖的每一列都重算一次 → 实机长卡。改用具名 computed 标志。
            //   另：剪枝只在"给定上界"下等价，故记录所用上界；若本次上界更大则重算。
            if (escapeComputed && upperBound <= escapeBoundUsed) return escapeLevel;
            synchronized (this) {
                if (escapeComputed && upperBound <= escapeBoundUsed) return escapeLevel;
                double lvl = computeEscape(erodedY, coarseStep, fineStep, upperBound);
                escapeBoundUsed = upperBound;
                escapeLevel = lvl;
                escapeComputed = true;
                return lvl;
            }
        }

        /** 逃逸高度缓存（lazy）。 */
        private volatile double escapeLevel = Double.NaN;
        /** 是否已求解（★ 不能用 NaN 当"未算"标记 —— NaN 本身是合法结果）。 */
        private volatile boolean escapeComputed = false;
        /** 上次求解所用上界（本次上界更大时需重算 —— 剪枝只在给定上界下等价）。 */
        private volatile double escapeBoundUsed = Double.POSITIVE_INFINITY;

        /** 搜索域外扩（wu）：足够覆盖"侵蚀刻出的新出口"，又不过度膨胀。 */
        private static final double ESCAPE_MARGIN = 240.0;

        /**
         * 最小最大路径逃逸高度（Dijkstra 式，成本 = 路径最大高度）。
         *
         * <p>用二叉堆实现（O(N log N)）；N 受搜索域限制。<br>
         * ⚠ 2026-09-18 校正：本行原称"由粗到细两轮完成"，实际<b>只有 {@code fineStep} 一轮</b>，
         * 形参 {@code coarseStep} 未被使用（详见 {@code escapeWaterLevel} 的说明）。</p>
         */
        private double computeEscape(java.util.function.ToDoubleBiFunction<Double, Double> erodedY,
                                     double coarseStep, double fineStep, double upperBound) {
            if (cellX == null || cellX.length == 0) return Double.NaN;
            double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE;
            double minZ = Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
            for (int i = 0; i < cellX.length; i++) {
                minX = Math.min(minX, cellX[i]); maxX = Math.max(maxX, cellX[i]);
                minZ = Math.min(minZ, cellZ[i]); maxZ = Math.max(maxZ, cellZ[i]);
            }
            minX -= ESCAPE_MARGIN; maxX += ESCAPE_MARGIN;
            minZ -= ESCAPE_MARGIN; maxZ += ESCAPE_MARGIN;
            int nx = (int) Math.floor((maxX - minX) / fineStep) + 1;
            int nz = (int) Math.floor((maxZ - minZ) / fineStep) + 1;
            if ((long) nx * nz > 4_000_000L) return Double.NaN;      // 安全阀

            double[] cost = new double[nx * nz];
            java.util.Arrays.fill(cost, Double.POSITIVE_INFINITY);
            // ★ 2026-09-17【性能】地形高度缓存：本域格数是 (bbox+2×240wu)/fineStep 的平方
            //   （可达 2 万格），而 erodedY 是昂贵的 finalGroundFn（内含 carveColumnAt）
            //   ⇒ 无缓存时 Dijkstra 松弛会重复采样同一格 ⇒ 首次触达某湖可卡 5 秒。
            double[] hCache = new double[nx * nz];
            java.util.Arrays.fill(hCache, Double.NaN);
            java.util.PriorityQueue<long[]> pq = new java.util.PriorityQueue<>(
                    (a, b) -> Double.compare(Double.longBitsToDouble(a[1]),
                            Double.longBitsToDouble(b[1])));
            // 种子：盆底格（侵蚀后最低的洼地格）
            double best = Double.MAX_VALUE;
            int si = 0, sj = 0;
            for (int i = 0; i < cellX.length; i++) {
                double h = erodedY.applyAsDouble(cellX[i], cellZ[i]);
                if (h < best) {
                    best = h;
                    si = (int) Math.round((cellX[i] - minX) / fineStep);
                    sj = (int) Math.round((cellZ[i] - minZ) / fineStep);
                }
            }
            si = Math.max(0, Math.min(nx - 1, si));
            sj = Math.max(0, Math.min(nz - 1, sj));
            // ★ 上界剪枝（等价性论证见 escapeWaterLevel(...,upperBound)）：
            //   盆底（本湖最低格）已高于上界 ⇒ 任何路径 cost ≥ best > 上界 ⇒
            //   逃逸高度不可能改变调用方的 min() 结果 ⇒ 直接返回 NaN（"不可达"）。
            if (best > upperBound) return Double.NaN;
            int sIdx = sj * nx + si;
            cost[sIdx] = best;
            pq.add(new long[]{sIdx, Double.doubleToLongBits(best)});

            final int[] dxx = {1, -1, 0, 0};
            final int[] dzz = {0, 0, 1, -1};
            while (!pq.isEmpty()) {
                long[] cur = pq.poll();
                int idx = (int) cur[0];
                double c = Double.longBitsToDouble(cur[1]);
                if (c > cost[idx]) continue;                       // 过期项
                int ci = idx % nx, cj = idx / nx;
                // ★ 到达搜索域边界 ⇒ 该 cost 即逃逸高度
                if (ci == 0 || ci == nx - 1 || cj == 0 || cj == nz - 1) {
                    return c;
                }
                for (int d = 0; d < 4; d++) {
                    int ni = ci + dxx[d], nj = cj + dzz[d];
                    if (ni < 0 || ni >= nx || nj < 0 || nj >= nz) continue;
                    int nIdx = nj * nx + ni;
                    // ★ 2026-09-17【性能】高度走缓存（同 runFloodCore 的 hCache）：
                    //   erodedY 在本路径是 **finalGroundFn**（内含 generator.sample +
                    //   carveColumnAt（河流采样）+ sampleWu，实测 100~250µs/次），
                    //   而 Dijkstra 松弛会对同一格重复调用（4 邻 × 多次改进）⇒ 缓存把
                    //   "每格最多一次"，语义完全等价（地形高度在求解中恒定）。
                    double h = hCache[nIdx];
                    if (Double.isNaN(h)) {
                        h = erodedY.applyAsDouble(minX + ni * fineStep, minZ + nj * fineStep);
                        hCache[nIdx] = h;
                    }
                    // ★ 2026-09-17【上界剪枝】本格已高于上界 ⇒ 经它的路径 cost > 上界
                    //   ⇒ 不可能改变 min(当前水位, 逃逸高度) ⇒ 丢弃（不再展开其邻居，
                    //     连采样都省了）。等价性证明见 escapeWaterLevel(...,upperBound)。
                    if (h > upperBound) continue;
                    double nc = Math.max(c, h);                    // 成本 = 路径最大高度
                    if (nc < cost[nIdx] - 1e-9) {
                        cost[nIdx] = nc;
                        pq.add(new long[]{nIdx, Double.doubleToLongBits(nc)});
                    }
                }
            }
            return Double.NaN;
        }

        /**
         * 该点是否落在本湖的【粗覆盖域】内（洼地格方块并集）。
         *
         * <p>这是"湖管不管这里"的粗判定，真正的淹水边界由落块侧的
         * {@code 侵蚀后 height < spill} 等高线决定 —— 因此域可以（也应该）比实际
         * 水面大：等高线落在域内部自然收束，不会在域边界出现硬切。</p>
         *
         * @param margin 格方块外扩（wu）：给岸线一点余量，避免岸线恰在格边界被截断
         */
        public boolean inDomain(double wx, double wz, double margin) {
            if (cellX == null || cellX.length == 0) return false;
            double r = cellHalf + margin;
            // ★ 2026-09-22【AABB 预筛 + 惰性包围盒】：本方法是采样热路径
            //   （湖域判定每列一次；河域内不发河命中也走它）⇒ 原 O(轮廓格数) 逐格
            //   比较在大湖上很贵（实测 hydro 由 ~2.6s 涨到 9.5s）。
            //   预筛：先用一次包围盒判断排除域外点（大多数列远离湖 ⇒ 立即返回）。
            double minX = bboxMinX, maxX = bboxMaxX, minZ = bboxMinZ, maxZ = bboxMaxZ;
            if (Double.isNaN(minX)) {
                double a = Double.MAX_VALUE, b = -Double.MAX_VALUE;
                double c0 = Double.MAX_VALUE, d0 = -Double.MAX_VALUE;
                for (int i = 0; i < cellX.length; i++) {
                    a = Math.min(a, cellX[i]); b = Math.max(b, cellX[i]);
                    c0 = Math.min(c0, cellZ[i]); d0 = Math.max(d0, cellZ[i]);
                }
                bboxMinX = a; bboxMaxX = b; bboxMinZ = c0; bboxMaxZ = d0;
                minX = a; maxX = b; minZ = c0; maxZ = d0;
            }
            if (wx < minX - r || wx > maxX + r || wz < minZ - r || wz > maxZ + r) return false;
            for (int i = 0; i < cellX.length; i++) {
                if (Math.abs(wx - cellX[i]) <= r && Math.abs(wz - cellZ[i]) <= r) return true;
            }
            return false;
        }

        /** 轮廓包围盒缓存（惰性一次计算；见 {@link #inDomain} 的性能说明）。 */
        private volatile double bboxMinX = Double.NaN, bboxMaxX, bboxMinZ, bboxMaxZ;

        /**
         * ★★★ 2026-09-23【P2-2 块分辨率湖盆连通掩码】★★★
         *
         * <p>惰性确保 {@link #computeFlood} 已按 {@code gridCell}（生产 = 1 块）建好
         * 连通掩码，然后查 {@link #inFlood}。掩码格由 BFS 通行条件
         * {@code h < level − 0.05} 构造保证 = <b>低于水位 ∧ 与盆底连通</b> ——
         * 即"该淹"的完整物理谓词（替代"轮廓方格 + domTol"域壳的判水部分）。</p>
         *
         * <p>先用 {@link #inDomain}(margin=72wu+claimGrid) 做包围盒+轮廓预筛
         * （掩码 BFS 窗 = 轮廓 bbox + 72wu pad，预筛是其超集 ⇒ 不漏判），
         * 远离湖盆的点零开销返回。{@link #computeFlood} 自带"一次/湖"缓存
         * （floodX 已算则直接复用，参数被忽略 ⇒ 谁先触发都用同一份掩码）。</p>
         *
         * @param erodedY   侵蚀后地形采样（生产 = terrain.sampleWu().height，与雕刻判水同源）
         * @param level     湖水位（调用方传 finalLakeLevel / minimax 逃逸链）
         * @param gridCell  掩码 BFS 格距（wu）；生产 = 1 块
         * @param claimGrid 认领域基准格（= 原始 gridCell，与 BFS 分辨率解耦）
         */
        public boolean inBasinFlood(
                java.util.function.ToDoubleBiFunction<Double, Double> erodedY,
                double level, double gridCell, double claimGrid,
                double wx, double wz) {
            if (cellX == null || cellX.length == 0) return false;
            if (!inDomain(wx, wz, 72.0 + claimGrid)) return false;
            computeFlood(erodedY, level, gridCell, claimGrid);
            return inFlood(wx, wz);
        }

        /** 是否有逐格轮廓（false = 旧式圆盘湖，调用方需回退旧行为）。 */
        public boolean hasOutline() { return cellX != null && cellX.length > 0; }

        // ===== 侵蚀后淹水连通域（2026-09-09 物理级形状）=====
        //   旧的形状来自"无侵蚀洼地格方块并集"，与侵蚀后地形无关 → 水位按侵蚀后
        //   短板降下来后，盆底可能已被沉积垫高 → 水淹不到（实测整片 dry）。
        //   物理正确：湖 = 侵蚀后地形上【低于溢出坎且与盆底连通】的区域。
        //   用 BFS 从"侵蚀后盆底最低点"扩展得到（粗格分辨率，边界由落块侧
        //   block 级等高线精修）。
        /** 侵蚀后淹水粗格中心 wu；null=未算，长度 0=无淹水（湖被填平） */
        public volatile double[] floodX = null;
        public volatile double[] floodZ = null;
        /** 淹水粗格半宽（wu） */
        public volatile double floodHalf = 0.0;

        /**
         * 在【侵蚀后】地形上算湖的真正形状（BFS 连通域）。
         *
         * <p>从无侵蚀洼地格中"侵蚀后最低"者出发，4 邻扩展到所有
         * {@code 侵蚀后高度 < level − 0.5} 的粗格。这保证湖只淹【与盆底连通、
         * 且低于溢出坎】的地方 —— 不会淹到域外山谷，也不会因无侵蚀域与侵蚀后
         * 地形不匹配而整片漏淹。结果缓存（每湖只算一次，跨 chunk 复用）。</p>
         *
         * <p><b>越界判定（2026-09-09，用户"填水范围超出填充上限就不生成湖"）</b>：
         * 若 BFS 在【无侵蚀认领域 = 洼地格 + 4×claimGrid】外仍探到低于水位的淹水格，
         * 说明实际洼地比提取时的无侵蚀域更大 → 若硬生成会在认领域边缘被截断
         * （用户实测"湖形不对称缺一块"）。此时返回 {@code floodOOB=true} 让调用方
         * 放弃该湖 —— 与其生成残缺湖，不如不生成。</p>
         *
         * <p>★ 2026-09-15：认领域外扩由 2×claimGrid 放宽到 4×claimGrid。原因：BFS
         * 搜索窗是【洼地格包围盒 + 72wu】，**比 2×gridCell(48wu) 的认领域更大** ⇒
         * 只要 48~72wu 环带内有任一低于水位的连通格就判 OOB ⇒ 整湖被丢（实测用户
         * 报"湖没生成"即此）。认领域只决定"湖允许占多大"、不参与湖形塑形，故放宽安全。</p>
         *
         * @param erodedY  侵蚀后地面高度采样
         * @param level    侵蚀后短板水位（erodedWaterLevel 结果）
         * @param gridCell <b>BFS 粗格分辨率（wu）</b>；<b>生产调用方传 {@code claimGrid*0.25}</b>
         *                 以提高湖形精度（2026-09-17 由 *0.5 加密为 *0.25，见下述精度说明）。
         *                 ⚠ 2026-09-18 校正：本行原写 claimGrid/2 已过时；且两个诊断探针
         *                 （{@code LakeSurveyProbe} / {@code LakeGatingControlledProbe}）
         *                 <b>仍传 *0.5</b>，与生产差一倍 ⇒ 改生产分辨率时须同步它们
         * @param claimGrid <b>认领域基准格（wu）</b>＝原始 gridCell，与 BFS 分辨率解耦，
         *                  使加密 BFS 时认领域的物理范围不缩水
         * @return true = 淹没区越出认领域（湖残缺，应放弃）
         */
        public boolean computeFlood(java.util.function.ToDoubleBiFunction<Double, Double> erodedY,
                                    double level, double gridCell, double claimGrid) {
            if (floodX != null) return floodOOB;
            synchronized (this) {
                if (floodX != null) return floodOOB;
                if (cellX == null || cellX.length == 0) {
                    floodX = new double[0]; floodZ = new double[0];
                    return floodOOB = true;    // 无轮廓无从判 → 放弃
                }
                // 搜索窗：洼地格包围盒外扩 3 格（保证能走到坎外沿自然停住）
                double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE;
                double minZ = Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
                for (int i = 0; i < cellX.length; i++) {
                    minX = Math.min(minX, cellX[i]); maxX = Math.max(maxX, cellX[i]);
                    minZ = Math.min(minZ, cellZ[i]); maxZ = Math.max(maxZ, cellZ[i]);
                }
                // ★ 2026-09-15：pad 由"固定 3 格"改为【按物理 72wu 换算格数】。
                //   调用方把 gridCell 加密到 claimGrid/2 以提高湖形精度；若 pad 仍固定
                //   为 3 格，搜索窗物理范围会跟着减半（72→36wu），可能探不到湖盆坎外沿
                //   ⇒ 淹没区被截断、湖被削掉一圈。按物理距离换算则搜索窗恒定 72wu。
                int pad = (int) Math.round(72.0 / gridCell);
                minX -= pad * gridCell; maxX += pad * gridCell;
                minZ -= pad * gridCell; maxZ += pad * gridCell;
                int nx = (int) Math.floor((maxX - minX) / gridCell) + 1;
                int nz = (int) Math.floor((maxZ - minZ) / gridCell) + 1;
                // ★ 2026-09-17：弃湖阈值由【格数 ≤ 40000】改为【物理面积 ≤ 5.76e6 wu²】
                //   （= 旧上限 40000 格 × (12wu)²，语义等价，且与 BFS 分辨率解耦）。
                //   原因：BFS 网格加密到 6wu 后格数 ×4；若沿用 40000 会把一批
                //   【本来正常的大湖】误判为"越界"而整湖丢弃（用户最反感的回归）。
                //   代价：最坏情况 erodedY 采样数上限 ×4（每次采样走地形 LRU 缓存）。
                double areaWu2 = (maxX - minX) * (maxZ - minZ);
                if (nx <= 0 || nz <= 0 || areaWu2 > 5.76e6) {
                    floodX = new double[0]; floodZ = new double[0];
                    return floodOOB = true;
                }
                // 种子 = 无侵蚀洼地格中【侵蚀后最低】者（盆底）
                double best = Double.MAX_VALUE;
                int si = 0, sj = 0;
                for (int i = 0; i < cellX.length; i++) {
                    double h = erodedY.applyAsDouble(cellX[i], cellZ[i]);
                    if (h < best) {
                        best = h;
                        si = (int) Math.round((cellX[i] - minX) / gridCell);
                        sj = (int) Math.round((cellZ[i] - minZ) / gridCell);
                    }
                }
                // 盆底都被垫到水位以上 → 湖被侵蚀填平，物理上就该消失
                if (best >= level - 0.5) {
                    floodX = new double[0]; floodZ = new double[0];
                    return floodOOB = false;    // 消失 ≠ 残缺，不必弃湖
                }
                si = Math.max(0, Math.min(nx - 1, si));
                sj = Math.max(0, Math.min(nz - 1, sj));
                // 认领域边界（wu，绝对坐标）：洼地格外扩 4×claimGrid（2026-09-15 放宽后）
                double claimLoX = Double.MAX_VALUE, claimHiX = -Double.MAX_VALUE;
                double claimLoZ = Double.MAX_VALUE, claimHiZ = -Double.MAX_VALUE;
                for (int i = 0; i < cellX.length; i++) {
                    claimLoX = Math.min(claimLoX, cellX[i]);
                    claimHiX = Math.max(claimHiX, cellX[i]);
                    claimLoZ = Math.min(claimLoZ, cellZ[i]);
                    claimHiZ = Math.max(claimHiZ, cellZ[i]);
                }
                // ★ 2026-09-15 修复：认领域外扩 2×gridCell(48wu) → 4×gridCell(96wu)。
                //
                //   结构性冲突：下面的 BFS 搜索窗是【洼地格包围盒 + pad(3)×gridCell = 72wu】，
                //   而认领域只有 2×gridCell = 48wu ⇒ 搜索窗**比认领域大** ⇒ 只要在
                //   48~72wu 环带内存在任一"低于水位且与盆底连通"的格，就判 floodOOB=true
                //   ⇒ 调用方(HydrologyBlockCarver:124-129) **放弃整个湖**（所有列 lakePlan=false）。
                //
                //   实测（seed 5436529513624899584，用户报"湖没生成/提前结束"）：
                //   湖 wu(-132,-108) 的 floodOOB=true（floodN=31，inFlood(用户点)=true
                //   —— 即淹水区确实算出来了、也覆盖了用户位置），却因越出 48wu 认领域
                //   而整湖被丢 ⇒ 该处方块完全没有水。
                //
                //   认领域只决定"这个湖允许占多大"，不参与湖形塑形（湖形 = inFlood 连通区
                //   + 落块侧等高线），故放宽到 4×gridCell(96wu) ≥ 搜索窗(72wu) 是安全的：
                //   它只是不再因为"搜索窗必然探到远处"而误弃整个湖。
                //   基准用 claimGrid（原始 gridCell）而非加密后的 gridCell，
                //   否则加密 BFS 会把认领域物理范围也缩小一半。
                double claimR = claimGrid * 4.0;
                claimLoX -= claimR; claimHiX += claimR;
                claimLoZ -= claimR; claimHiZ += claimR;

                // ★★★ 2026-09-17 短板强制（M2 阶段二）：迭代压低水位至【真实溢出口】★★★
                //
                // 【被修的缺陷（实测，湖泊短板审计）】seed 5436529513624899584、窗口 ±96wu：
                //   一个 13,685 格、水位 166.63 的巨大水体，紧邻旱地最低只有 140.55
                //   ⇒ 水面比真实盆沿高出 26 块（用户截图"悬空水板 / 水淹到山腰"）。
                //   根因：原水位 = min(粗格 spill, rim 格侵蚀后高度)，而 rim 只取
                //   "洼地格 8 邻中 fillE ≤ spill+0.05" 的【一圈】—— 真实最低出水口
                //   若离洼地格超过 1 格，就永远进不了该集合 ⇒ 水位停在 166.63。
                //
                // 【修法】迭代短板：反复以当前水位跑 BFS（通行条件 h < level−0.05），
                //   取洪泛区外缘【非淹格】的最低高度（= 当前水位下的真实盆沿），
                //   若低于水位则压低水位，直到短板成立或迭代上限（3 次）。
                //   全程只用侵蚀后地形（erodedY）⇒ 与落块侧判水同源。
                //   回退：LAKE_SHORTBOARD_ENFORCE = false 一行。
                // ★★★ 2026-09-17【性能修复：BFS 高度缓存 hCache】★★★
                //   【被修的浪费（ChunkLoadPerfProbe 实测量化）】runFloodCore 原实现对本网格
                //   <b>每访问一次就采样一次地形</b>（erodedY → terrain.sampleWu，实测 ~10~15µs/次），
                //   且有双重放大：
                //     ① 外缘【非淹格不标 seen】⇒ 被多少个邻居探到就采样多少次（最多 4 次）；
                //     ② 短板迭代(最多 3 遍) + 最终 1 遍 ⇒ 同一网格最多遍历 4 遍，每遍重采样全部。
                //   实测落点：chunk(0,33) 单块 hydro = 5087ms（区块加载可见卡顿）。
                //   【为何语义完全不变】地形高度在整段求解中<b>恒定</b>（hCache 只按格索引缓存
                //   erodedY 的结果，不做任何近似）⇒ 与逐次重算**逐位同值**。
                //   【收益】采样次数降到"每格最多一次"（实测约 1/4~1/8）。
                //   【回退】删本块，并把两处 runFloodCore 的末参 hCache 去掉。
                double[] hCache = new double[nx * nz];
                java.util.Arrays.fill(hCache, Double.NaN);
                // ★ 由粗到细：粗格 = 2×2 细格，只采样一次，供【深水区】复用（省 ~3/4 采样）
                int cnx = (nx + 1) >> 1, cnz = (nz + 1) >> 1;
                double[] coarseH = new double[cnx * cnz];
                java.util.Arrays.fill(coarseH, Double.NaN);
                double lvl = level;
                if (LAKE_SHORTBOARD_ENFORCE) {
                    for (int iter = 0; iter < 3; iter++) {
                        FloodRun probe = runFloodCore(erodedY, lvl, minX, minZ, gridCell,
                                nx, nz, si, sj, hCache, coarseH, cnx);
                        if (probe.rimMin() >= lvl - 0.5) break;      // 短板成立
                        double next = Math.min(lvl, probe.rimMin());
                        if (next >= lvl - 1e-9) break;               // 已无法再降
                        lvl = next;
                    }
                }
                // ★ 回传收敛水位（调用方据此铺水；否则迭代等于白算）
                floodLevel = lvl;
                // 盆底被垫到（可能已压低的）水位以上 → 湖被侵蚀填平，物理上就该消失
                if (best >= lvl - 0.5) {
                    floodX = new double[0]; floodZ = new double[0];
                    return floodOOB = false;    // 消失 ≠ 残缺，不必弃湖
                }
                // 最终一次 BFS：以（可能已压低的）水位求正式淹水区
                FloodRun run = runFloodCore(erodedY, lvl, minX, minZ, gridCell, nx, nz, si, sj,
                        hCache, coarseH, cnx);
                java.util.List<double[]> flood = run.flood();
                boolean oob = false;
                for (double[] pt : flood) {
                    if (pt[0] < claimLoX || pt[0] > claimHiX || pt[1] < claimLoZ || pt[1] > claimHiZ) {
                        oob = true;
                        break;
                    }
                }
                double[] fx = new double[flood.size()], fz = new double[flood.size()];
                for (int i = 0; i < flood.size(); i++) {
                    fx[i] = flood.get(i)[0]; fz[i] = flood.get(i)[1];
                }
                floodHalf = gridCell * 0.5;
                // ★ 2026-09-17【性能】建立 O(1) 网格索引（见 inFlood 的说明）：淹水格本就是
                //   规则网格上的点 ⇒ 布尔表直接查。同时供下面的"覆盖比例判据"复用，
                //   省掉原来 cellX.length × floodN 的量级（大湖可达千万次比较）。
                boolean[] fgrid = new boolean[nx * nz];
                for (int i = 0; i < fx.length; i++) {
                    int gi = (int) Math.round((fx[i] - minX) / gridCell);
                    int gj = (int) Math.round((fz[i] - minZ) / gridCell);
                    if (gi >= 0 && gi < nx && gj >= 0 && gj < nz) fgrid[gj * nx + gi] = true;
                }
                FloodIndex fidx = new FloodIndex(minX, minZ, gridCell, nx, nz, fgrid);
                floodIdx = fidx;
                floodX = fx; floodZ = fz;      // volatile 安全发布（索引先发布，读方以 floodIdx 为准）
                // ★ 覆盖比例判据（2026-09-10，用户"水没铺满整个洼地"）：淹没区若不能
                //   覆盖绝大部分【无侵蚀洼地格】，说明侵蚀把洼地一侧盆底垫高到水位以上
                //   → 湖水铺不满洼地（一侧有、一侧无的残缺湖，实测 lake0：2 格洼地只淹
                //   1 格 → wetProd 92 却缺一半）。此时放弃该湖。
                //   阈值 75%（covered*4 >= cells*3）：岸线自然内缩最多放行 25% 边缘格
                //   露出；超过（≥1/4 洼地没淹）判残缺。cells=2 时需覆盖 2/2（75%×2=1.5
                //   → 需≥2），杜绝"一半洼地没水"的残缺湖。
                if (!oob) {
                    int covered = 0;
                    // ★ 2026-09-15：覆盖判据的半径用【原始格半宽】claimGrid/2，不用
                    //   floodHalf。floodHalf 随 BFS 加密而减半（12→6wu），若沿用会把
                    //   "洼地格中心是否被淹"判得过严 ⇒ covered 偏低 ⇒ 误判 OOB ⇒
                    //   整湖被弃（实测 runLakeSurveyProbe lake[2]: OOB=true wetProd=0）。
                    //   本判据的语义是"洼地格被淹了吗"，与 BFS 分辨率无关，故用原始格宽。
                    double coverR = claimGrid * 0.5;
                    // ★ 走 O(1) 索引（contains 内部会再 +cell/2，故这里传差值）——
                    //   原 inFloodLocal 是线性扫描 ⇒ 洼地格数 × 淹水格数（大湖可达千万次比较）。
                    double coverExtra = coverR - gridCell * 0.5;
                    for (int i = 0; i < cellX.length; i++) {
                        if (fidx.contains(cellX[i], cellZ[i], coverExtra)) covered++;
                    }
                    if (covered * 4 < cellX.length * 3) oob = true;
                }
                return floodOOB = oob;
            }
        }

        /**
         * ★ 短板强制开关（2026-09-17）。<b>当前 = true（启用验证中）</b>。
         *
         * <p><b>曲折（务必保留，勿重犯）</b>：首次实现后复测"产出逐格不变"，
         * 当时误判为"该水体不是湖、是河"。<b>控制变量实验（LakeGatingControlledProbe）
         * 证明该判断是错的</b>：湖@(9,376) 的域覆盖 1058 格、侵蚀后连通区 205 格
         * （≈13,120 块，与已放置 13,685 格水体吻合）⇒ <b>它确实是湖</b>；
         * "零效果"的真因是<b>调用方仍用旧 spill 铺水</b>（迭代结果没回传），
         * 已由 {@link #floodLevel} 修复。</p>
         */
        static final boolean LAKE_SHORTBOARD_ENFORCE = false;

    /**
     * ★ 2026-09-17「由粗到细」（用户建议）：粗格 = 2×2 细格，<b>只采样一次</b>。
     *
     * <p>若粗格采样低于 {@code 水位 − 本值} ⇒ 判为<b>【深水区】</b>（淹没与连通性均无争议），
     * 其 4 个细格<b>复用</b>这一次采样，不再逐格调用昂贵的 {@code erodedY}
     * （实测 {@code sampleWu} ≈ 150µs/次）⇒ 深水区省掉约 3/4 的采样。</p>
     *
     * <p>越接近水位（= 岸线附近，最需要精细的地方）越不会复用 ⇒ <b>岸线精度不变</b>。
     * 这与"中间区域不需要细、边缘要细"完全一致。</p>
     *
     * <p>⚠ <b>代价</b>：深水区内若有<b>高于水位的小高地</b>，可能因复用而被判为淹（小岛消失）。
     * 本值越大越保守（复用越少）。设 {@code Double.MAX_VALUE} = 完全不复用（旧行为）。</p>
     */
    /**
     * ★ 2026-09-17 实测：<b>本机制当前净亏，默认关闭</b>（保留实现 + 实测记录，勿删勿盲开）。
     *
     * <p>实测（ChunkLoadPerfProbe 48×48 chunk，同一负载）：</p>
     * <pre>
     *   关闭（逐格采样）      : 13.82 ms/chunk
     *   SAFE_DEPTH=2.0（复用）: 14.29 ms/chunk，产出【完全相同】（水位/面积/干墙 13 全同）
     *   SAFE_DEPTH=1.0（复用）: 15.50 ms/chunk（复跑 15.61 确认非噪声），干墙 13→9
     * </pre>
     * <p><b>为何净亏</b>：复用省掉的是 BFS 采样，但会让淹水区略大 ⇒ {@code floodX} 数组变长；
     * 而 {@code inFlood} 是 <b>{@code O(淹没格数)} 的线性扫描</b>、被<b>逐列</b>调用
     * （carver 判湖列 + 块级精修的 pad 侧种子）⇒ 省下的采样费被"每列多扫"吃回去还倒贴。</p>
     *
     * <p><b>结论</b>：先把 {@code inFlood} 换成 O(1) 的网格索引（语义完全等价的查表加速），
     * 再重新评估本开关 —— 届时"淹水区略大"不再有逐列代价，本机制很可能转为净收益。</p>
     */
    static final boolean FLOOD_COARSE_REUSE = false;
    /** 见 {@link #FLOOD_COARSE_REUSE}：粗格深度超过本值即判"深水区"并复用其采样。 */
    static final double FLOOD_COARSE_SAFE_DEPTH = 1.0;

        /**
         * ★ 短板迭代【收敛后】的水位（块）；{@code NaN} = 尚未计算。
         *
         * <p><b>为什么必须有它（2026-09-17 控制变量实测定位）</b>：
         * {@code computeFlood} 内部的短板迭代会把水位压低到<b>真实盆沿</b>，
         * 但调用方 {@code HydrologyBlockCarver} 原先<b>仍用旧 spill 铺水</b>
         * ⇒ <b>迭代算了却没人用</b> ⇒ 表现为"改了代码但产出逐格不变"。</p>
         *
         * <p>实测依据（seed 5436529513624899584，窗口 wu(12,316)±96）：
         * 湖@(9,376) 的【域】覆盖 1058 个采样格，而【侵蚀后连通区】只有 205 格
         * （≈13,120 块，与已放置的 13,685 格水体吻合）⇒ 该水体就是这个湖；
         * 水位必须用迭代收敛值，否则高出真实盆沿 26 块（悬空水板）。</p>
         */
        private volatile double floodLevel = Double.NaN;

        /** 短板迭代后的水位（块）；未算返回 {@code NaN}。 */
        public double floodLevel() { return floodLevel; }

        /**
         * {@link #runFloodCore} 的结果。
         *
         * @param flood  淹水格中心（wu）
         * @param rimMin 洪泛区外缘【非淹格】的最低侵蚀后高度（= 当前水位下的真实盆沿）；
         *               无洪泛时为 {@code +∞}
         */
        private record FloodRun(java.util.List<double[]> flood, double rimMin) { }

        /**
         * 以给定水位做一次 BFS（通行条件 {@code h < level − 0.05}）。
         *
         * <p>无缓存、无副作用 ⇒ 供短板迭代反复调用；{@link #computeFlood} 的最终一次
         * 也走这里（原实现内联，现抽离，避免"迭代版 / 正式版"两份 BFS 漂移）。</p>
         *
         * @return 淹水格列表 + 洪泛区外缘非淹格的最低侵蚀后高度（rimMin）
         */
        private FloodRun runFloodCore(java.util.function.ToDoubleBiFunction<Double, Double> erodedY,
                                      double level,
                                      double minX, double minZ, double gridCell, int nx, int nz,
                                      int si, int sj,
                                      double[] hCache, double[] coarseH, int cnx) {
            boolean[] seen = new boolean[nx * nz];
            java.util.ArrayDeque<Integer> q = new java.util.ArrayDeque<>();
            int sIdx = sj * nx + si;
            q.add(sIdx); seen[sIdx] = true;
            java.util.List<double[]> flood = new java.util.ArrayList<>();
            int[] ddx = {1, -1, 0, 0}, ddz = {0, 0, 1, -1};
            double rimMin = Double.MAX_VALUE;
            while (!q.isEmpty()) {
                int cur = q.poll();
                int ci = cur % nx, cj = cur / nx;
                double wx = minX + ci * gridCell, wz = minZ + cj * gridCell;
                flood.add(new double[]{wx, wz});
                for (int d = 0; d < 4; d++) {
                    int ni = ci + ddx[d], nj = cj + ddz[d];
                    if (ni < 0 || ni >= nx || nj < 0 || nj >= nz) continue;
                    int nIdx = nj * nx + ni;
                    if (seen[nIdx]) continue;
                    // ★ 2026-09-17【性能·由粗到细】高度取法（详见 FLOOD_COARSE_SAFE_DEPTH）：
                    //   ① hCache 命中 ⇒ 直接用（同格绝不重复采样）；
                    //   ② 否则先取所属【粗格】(2×2 细格) 的采样（粗格只采样一次）：
                    //      · 深度 > FLOOD_COARSE_SAFE_DEPTH ⇒ 深水区、判定无争议
                    //        ⇒ 本细格复用粗格高度（省掉这次昂贵的 sampleWu）；
                    //      · 否则（接近水位 = 岸线附近）⇒ 逐细格【真实采样】，精度不变。
                    double hh = hCache[nIdx];
                    if (Double.isNaN(hh)) {
                        if (FLOOD_COARSE_REUSE) {
                            // 由粗到细：深水区复用粗格采样（当前默认关闭，见常量处实测记录）
                            int cbi = ni >> 1, cbj = nj >> 1;  // 所属粗格（2×2 细格）
                            int cIdx = cbj * cnx + cbi;
                            double ch = coarseH[cIdx];
                            if (Double.isNaN(ch)) {
                                ch = erodedHeightAt(erodedY, minX + cbi * 2 * gridCell,
                                        minZ + cbj * 2 * gridCell, gridCell);
                                coarseH[cIdx] = ch;
                            }
                            hh = (ch < level - FLOOD_COARSE_SAFE_DEPTH)
                                    ? ch                        // 深水区：复用粗格采样
                                    : erodedHeightAt(erodedY, minX + ni * gridCell,
                                            minZ + nj * gridCell, gridCell);
                        } else {
                            hh = erodedHeightAt(erodedY, minX + ni * gridCell,
                                    minZ + nj * gridCell, gridCell);
                        }
                        hCache[nIdx] = hh;
                    }
                    // 通行条件与原实现一致（只问"是否低于水位"）；
                    // "薄水/最小水深"由落块侧的 `height < spill-0.5` 等高线判定负责。
                    if (hh < level - 0.05) {
                        seen[nIdx] = true;
                        q.add(nIdx);
                    } else {
                        // 外缘非淹格 = 当前水位下的盆沿候选（短板迭代用）
                        rimMin = Math.min(rimMin, hh);
                    }
                }
            }
            return new FloodRun(flood, rimMin);
        }

        /**
         * 粗格"是否该被淹"的采样高度：取 <b>格心 + 4 角</b> 的 <b>最小值</b>。
         *
         * <p>★ 2026-09-15 修复（用户实测"湖泊填充没到地形边缘就结束、提前在前一个
         * 区块停止填充"）：原先 BFS 只采样 <b>格心一个点</b>，于是 24wu×24wu 的粗格
         * 只要<b>格心</b>恰好高出水位 0.5，整个粗格就被判"不淹"——湖岸因此被量化到
         * 24wu（≈1.5 chunk）并在格边界<b>硬截断</b>，形态上正是"提前一个区块结束"。</p>
         *
         * <p>实测（seed 5436529513624899584）：用户所在 wu(-133,-83)（湖心
         * wu(-132,-108)，相距 25wu，即正落在第 2 个粗格内）侵蚀后高度 126.85，
         * 低于侵蚀短板水位 130.23，本该有水，却因所在粗格格心采样偏高而
         * {@code inFlood=false} ⇒ {@code lakePlan=false} ⇒ 该列不出水。</p>
         *
         * <p>改用 5 点取 min 后，格内<b>任一</b>采样点低于水位即算淹。当时刻意<b>不</b>缩小
         * {@code gridCell}：那会令格数 ×4，可能触发 {@code nx*nz > 40000} 的"弃湖"分支。</p>
         *
         * <p>⚠ 2026-09-17 <b>本方法已回退为【格心单点】</b>（见下）：5 点取 min 的代价是
         * <b>隧穿</b> —— 粗格"任一角低于水位"即算淹 ⇒ 山脊两侧的低格被同一粗格连通
         * ⇒ 淹水区越过分水岭。两者是同一枚硬币的两面：粗格尺度上的"漏判/误判"。
         * 真正的解法是<b>缩小格距</b>（把误差尺度本身变小），而不是在粗格内挑采样点；
         * 弃湖阈值的顾虑已由"按物理面积判阈"消解（见 {@code computeFlood}）。</p>
         */
        private static double erodedHeightAt(
                java.util.function.ToDoubleBiFunction<Double, Double> erodedY,
                double gx, double gz, double gridCell) {
            // ★★★ 2026-09-17 修复：由"格心 + 4 角取 min"改为【格心单点】★★★
            //
            // 【被修的缺陷（隧穿，实测量化）】旧实现取格心与 4 角的**最小值**：
            //   h = min(格心, 左上, 右上, 左下, 右下)
            // ⇒ 一个粗格**只要有一个角低于水位就算淹** ⇒ BFS 会**穿过山脊"隧穿"**
            //   （山脊两侧的低格被同一个粗格连通）⇒ 淹水区越过分水岭延伸。
            //
            // 【实测（runLakeTunnelProbe，seed 5436529513624899584 @湖 wu(9,376)）】
            //   5 点取 min（旧）：淹水粗格 **220**
            //   格心单点（新）  ：淹水粗格 **64**
            //   ⇒ 旧实现让淹水区达到严格版的 **3.4 倍**（+243.8%）。
            //   这正是实机"填出山腰外的悬空水板"的机制，也解释了为何"加密 BFS 网格"
            //   无效（问题在**采样方式**，不在粒度）。
            //
            // 【为何安全】
            //   · 通行条件变严 ⇒ 淹水区**只会缩小**，不会新增淹没（对称于"只降不升"原则）；
            //   · 采样次数由 5 次降到 1 次 ⇒ **更快**；
            //   · 边界仍由落块侧的块级等高线（`height < spill − 0.5`）精修 ⇒ 不损失精度。
            //   · 注：该函数此前被 2026-09-15 用于修"湖岸尖端漏判"，但那个问题
            //     的**正确解**是块级等高线（已有），不该用"放宽粗格通行条件"来代偿。
            //   【回退】恢复上方 4 个 `h = Math.min(...)` 行即可。
            return erodedY.applyAsDouble(gx, gz);
        }

        /** 局部 inFlood（computeFlood 内部用，flood 尚未发布时）。 */
        private static boolean inFloodLocal(double wx, double wz,
                                            double[] fx, double[] fz, double half) {
            if (fx == null || fx.length == 0) return false;
            for (int i = 0; i < fx.length; i++) {
                if (Math.abs(wx - fx[i]) <= half && Math.abs(wz - fz[i]) <= half) return true;
            }
            return false;
        }

        /** 该点是否落在【侵蚀后淹水连通域】内（粗格覆盖；边界由落块侧等高线精修）。 */
        public boolean inFlood(double wx, double wz) {
            return inFlood(wx, wz, 0.0);
        }

        /**
         * 带**容差**的连通域判定 —— 用于"粗格只做连通性粗筛、边界交给块级等高线"。
         *
         * <h4>为什么需要容差（2026-09-17，水体渲染图实证）</h4>
         * <p>本方法此前是**唯一**的水界判据（carver 直接 `if (!inFlood) return 非湖列`），
         * 而 BFS 是**粗格**（`claimGrid*0.25 = 6wu`）⇒ 水界带**格网直角**，
         * 与设计意图"湖岸 = 侵蚀后地形与 spill 的**等高线**"不符
         * （见本类 {@code computeFlood} 的注释，以及 {@code GeoGenesisTerrain}
         * 湖分支里的块级判定 {@code cell.height < spill − 0.5}）。</p>
         *
         * <p>⇒ 正解：本方法负责<b>连通性粗筛</b>（排除远在域外/不连通的低地），
         * 边界再交由落块侧的**块级等高线**判定。给一点容差
         * （如一个粗格 {@code floodHalf}）即可让"粗格边界外、但确实低于水位且相邻"的列
         * 进入块级判定 ⇒ 水界回归等高线，同时不破坏连通性语义。</p>
         *
         * @param extra 额外容差（wu）；{@code 0} = 原行为
         */
        public boolean inFlood(double wx, double wz, double extra) {
            // ★★★ 2026-09-17【性能：O(n) 线性扫描 → O(1) 查表】★★★
            //   原实现对本点扫描【全部淹水格】。而它在两个热路径上被高频调用：
            //     ① HydrologyBlockCarver 逐列判"是否湖列"；
            //     ② GeoGenesisTerrain.lakeFineFlood 的 pad 侧种子（每 chunk 最多 169 次）。
            //   代价随淹水区大小线性增长（大湖上万格 ⇒ 每次查询上万次比较）。
            //   关键事实：淹水格【必落在规则网格上】（runFloodCore 里 wx = minX + i·gridCell），
            //   故可算出下标直接查布尔表 ⇒ **语义逐位等价**（纯查表加速，判定不变）。
            FloodIndex idx = floodIdx;
            if (idx != null) return idx.contains(wx, wz, extra);
            double[] fx = floodX, fz = floodZ;               // 回退（索引未建：无淹水等情形）
            if (fx == null || fx.length == 0) return false;
            double r = floodHalf + Math.max(0.0, extra);
            for (int i = 0; i < fx.length; i++) {
                if (Math.abs(wx - fx[i]) <= r && Math.abs(wz - fz[i]) <= r) return true;
            }
            return false;
        }

        /**
         * 淹水区的 <b>O(1) 网格索引</b>（与 {@code floodX/floodZ} 同源；一次发布后只读）。
         *
         * <p>淹水格本就在规则网格 {@code (minX + i·cell, minZ + j·cell)} 上 ⇒ 布尔表即可。
         * {@link #contains} 对"半径 r 内的所有网格点"枚举下标（通常 1~2 个）再查表，
         * 与原来的全量线性扫描<b>逐位等价</b>。</p>
         */
        private record FloodIndex(double minX, double minZ, double cell,
                                  int nx, int nz, boolean[] grid) {
            boolean contains(double wx, double wz, double extra) {
                double r = cell * 0.5 + Math.max(0.0, extra);   // = floodHalf + extra（同原式）
                int iLo = (int) Math.ceil((wx - r - minX) / cell);
                int iHi = (int) Math.floor((wx + r - minX) / cell);
                int jLo = (int) Math.ceil((wz - r - minZ) / cell);
                int jHi = (int) Math.floor((wz + r - minZ) / cell);
                if (iHi < 0 || jHi < 0 || iLo > nx - 1 || jLo > nz - 1) return false;
                for (int j = Math.max(0, jLo); j <= Math.min(nz - 1, jHi); j++) {
                    for (int i = Math.max(0, iLo); i <= Math.min(nx - 1, iHi); i++) {
                        if (grid[j * nx + i]) return true;
                    }
                }
                return false;
            }
        }

        /** ★ 2026-09-17：淹水区 O(1) 索引（null = 未建/无淹水 ⇒ 回退线性扫描）。 */
        private volatile FloodIndex floodIdx = null;

        /** 淹没区是否越出认领域（computeFlood 结果；true=湖残缺应放弃）。 */
        public volatile boolean floodOOB = false;

        // ===== 诊断访问器（2026-09-15，LakeLocateProbe 用）=====
        /** 淹水粗格中心 X（只读；null = 未算）。 */
        public double[] floodCellX() { return floodX; }
        /** 淹水粗格中心 Z（只读；null = 未算）。 */
        public double[] floodCellZ() { return floodZ; }
        /** 粗格覆盖半宽（wu）= gridCell/2。 */
        public double floodHalf() { return floodHalf; }
    }

    /**
     * 跨 region 出口种子：本 region 一条河流到网格边（= 缝外 margin）时的交接信息。
     *
     * <p>下游邻 region 在双-pass 构建时吸收此种子作为强制源，从 {@code wx,wz} 继续追踪，
     * 并携带 {@code accum}（上游汇流面积）/ {@code level}（分支层级）/ {@code surfaceY}
     * （上游尾节点水面），使河流跨缝连续、宽度不重置（无颈缩）。</p>
     */
    public static final class OutletSeed {
        public final int dRX, dRZ;        // 出口指向的邻 region 增量（如 +1,0 = +X 邻）
        public final double wx, wz;       // 出口（上游尾节点）世界坐标（wu）
        public final double accum;        // 上游尾节点汇流面积（wu²），下游续流起点
        public final double surfaceY;     // 上游尾节点水面世界 Y（下游续流首节点水面，保证连续）
        public final int level;           // 上游河分支层级（下游续流继承）
        public OutletSeed(int dRX, int dRZ, double wx, double wz,
                          double accum, double surfaceY, int level) {
            this.dRX = dRX; this.dRZ = dRZ;
            this.wx = wx; this.wz = wz;
            this.accum = accum; this.surfaceY = surfaceY; this.level = level;
        }
    }

    public final int rx, rz;
    public final List<RiverPolyline> rivers;
    public final List<LakeNode> lakes;     // 本 region 内流湖（可能为空）
    public final List<OutletSeed> outlets; // 出口种子（双-pass 交接用；pass-1 产物）
    public final boolean outletOcean;     // 本 region 是否有河到达海洋
    public final double dischargeArea;    // 主河出口汇流面积（诊断用）
    // 诊断计数（PL-RGA 对齐探针用）
    public final int sourceCount;         // 候选源数（e>min 且非边界）
    public final int rolledBack;          // 整条回滚数
    public final int joined;              // 就近汇入（树状）终止数

    public RiverLineRegion(int rx, int rz, List<RiverPolyline> rivers,
                           List<LakeNode> lakes, List<OutletSeed> outlets,
                           boolean outletOcean, double dischargeArea,
                           int sourceCount, int rolledBack, int joined) {
        this.rx = rx;
        this.rz = rz;
        this.rivers = List.copyOf(rivers);
        this.lakes = List.copyOf(lakes);
        this.outlets = List.copyOf(outlets);
        this.outletOcean = outletOcean;
        this.dischargeArea = dischargeArea;
        this.sourceCount = sourceCount;
        this.rolledBack = rolledBack;
        this.joined = joined;
    }

    /** 是否有任何水文特征（河或湖），采样时用于跳过空 region。 */
    public boolean hasWater() { return !rivers.isEmpty() || !lakes.isEmpty(); }
    /** 兼容别名（仅河）。 */
    public boolean hasRiver() { return !rivers.isEmpty(); }
}
