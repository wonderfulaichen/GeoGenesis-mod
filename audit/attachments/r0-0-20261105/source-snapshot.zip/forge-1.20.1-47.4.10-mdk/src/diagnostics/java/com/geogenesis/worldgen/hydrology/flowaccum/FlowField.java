package com.geogenesis.worldgen.hydrology.flowaccum;

import com.geogenesis.worldgen.hydrology.riverline.MidpointDisplacement.ElevationSampler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

/**
 * D8 流向 + 汇流累积场（region 级纯函数，确定性）。
 *
 * <p><b>物理范式（2026-08-28 河流重构）</b>：河网不再由几何线"画"出来，
 * 而是从地形汇流场中"流"出来——每个格点流向 8 邻最低 e（严格更低才连边），
 * 按 e 降序拓扑序累加汇流面积。累积量即真实水文意义上的 drainage area。</p>
 *
 * <p><b>确定性</b>：e 全部来自 {@link ElevationSampler}（terrainEQuick 纯噪声场，
 * 无侵蚀 tile 依赖 → 无递归、无 8-14 卡死风险）；同 (范围, cellSize, sampler) 同结果。</p>
 *
 * <p><b>性能</b>：O(n) 三遍（采样 / 流向 / 累积）。region 对角 ~905wu、cellSize=16wu
 * → 约 61×61≈3.7k 格，亚毫秒级；结果随 region 缓存，跨 chunk 共享。</p>
 */
public final class FlowField {

    private final int nx, nz;
    private final double cellSize;
    /**
     * ★ 2026-09-18（水文 M2）：<b>沿程衰减系数（1/wu）</b> —— 蒸发 / 入渗。
     *
     * <p>语义：水量沿流向传递时按 {@code exp(−decayPerWu · dist)} 衰减。
     * <b>0.0 = 关闭 ⇒ 与旧行为逐位一致</b>（实测 `runWaterBalanceProbe` 判据1：
     * 不一致格 = 0、最大绝对差 = 0）。</p>
     */
    private final double decayPerWu;
    private final double originX, originZ;
    private final double[] e;
    private final int[] flowTo;      // 下游格索引；-1 = 洼地（无更低邻居）
    private final double[] accum;    // 汇流面积（wu²，含自身格）
    // ===== 填洼层（2026-09-07 湖泊）：基于【真实地形】而非选线用的 routingE =====
    //   eFill   = 真实地形高程（block）
    //   eFilled = priority-flood 后的"溢出高程"：eFilled > eFill 的格 = 洼地内被水填起的部分
    private double[] eFill;
    private double[] eFilled;
    // ===== ★★★ 2026-09-20「填洼优先」流向面（修"河流突然结束"的根治层）★★★
    //
    //   【被修的缺陷】flowTo / accum 一直建在【原始 e】上 ⇒ 每个洼地/平地都是终点
    //   （{@code lowestNeighbor} 要求"严格更低"）⇒ 河追到洼地就停。而该洼地若没被
    //   extractLakes 提取成湖，commitRiver 就落到最后 else（outletSurf = junctionGround）
    //   ⇒ **河流就地以地形高度结束**。用户判据："河流怎么可能突然结束"／
    //   "水流堆积后溢出会继续向下流动的，但你完全不符合物理现象"。
    //
    //   【参考实现】{@code 参考/sources/worldgen-master/src/hydrology.rs:105-181}：
    //   {@code priority_flood → flow_dir → accum}，并给填起区加【递增 epsilon】：
    //     // Add tiny epsilon so filled areas slope toward their outlet —
    //     // without this, D8 can't find a downhill direction on flat filled areas
    //     // and rivers dead-end inland.
    //     if elev.data[ni] < cell.elev { elev.data[ni] = cell.elev + 1e-5; }
    //   即：填洼后必须让填起区【朝出口单调微降】，否则 D8 在水平面上仍找不到下坡。
    //
    //   【为什么是 e 空间而不是块空间】eAt()/oceanE()/sourceMinE()/minDrop() 与各探针
    //   全部在 e 口径上标定；把整场换成块空间 Y（~60-200）会让 sourceMinE=0.05 判据
    //   全格命中 ⇒ 河网密度标定被静默破坏。而上面那层（块空间）继续只服务湖提取。
    //   两层在 mountainScale=1.0（生产默认 ⇒ routingE 恒等）下由 heightFromE 保序等价
    //   ⇒ 同一批盆地、同一溢出序（{@link #initializedFillFirst()} 由探针校验一致性）。
    private double[] eFilledR;

    /** 每格基础产流（面积 × 降水权重）：让 {@link #buildAccum()} 可幂等重算。 */
    private double[] baseAccum;

    /** 降水取样器（归一化相对降水，见 {@code CellGenerator.precipitationAt}）。 */
    @FunctionalInterface
    public interface PrecipSampler {
        double precipitationAt(double wx, double wz);
    }

    /**
     * 降水 → 汇流权重（★ 2026-09-11 Phase C）。
     *
     * <p><b>消费端归一化</b>（设计文档 §4.3.4 修正）：气候侧只产出"物理相对降水"
     * （实测全局均值 ≈ 0.27），本类用<b>显式参考值</b> {@code ref} 折算成权重原点。
     * 拆开的好处：改降水标定<b>不会</b>悄悄平移全部河宽（与 {@code widthAreaRef} 解耦同一条教训）。</p>
     *
     * <pre>
     * weight = clamp(precip / ref, floor, +inf) ^ exponent
     * </pre>
     *
     * @param ref      参考降水（取实测全局均值 → 权重均值 ≈ 1，河宽不整体平移）
     * @param floor    权重下限（防极端干旱把汇流压到 0 → 沙漠彻底断流）
     * @param exponent 软化指数（&lt;1 收敛差异；1.0 = 线性）
     */
    public record PrecipWeights(double ref, double floor, double exponent) {
        /**
         * 默认参数。<b>ref 经实测标定</b>（2026-09-11）：
         *
         * <p>指数 0.6 为凹函数（Jensen 效应）→ 直接取 {@code ref = 降水均值} 时权重均值会偏离 1，
         * 汇流被系统性放大/缩小 → 河网被门槛多裁或少裁。按
         * {@code ref' = ref · mean^(1/exp)} 反解，使<b>权重均值回到 ≈1.0</b>（河宽不整体平移）。</p>
         *
         * <p>标定历史（每次降水分布变化都需重标）：
         * <ul>
         *   <li>初期（降水均值 0.272）→ <b>0.17</b>（权重均值 0.951）；</li>
         *   <li>★ 纬度改余弦后（2026-09-11，降水均值升到 <b>0.347</b>，热带/温带增湿）
         *       → <b>0.212</b>。旧 0.17 会让权重均值漂到 <b>1.143</b>（探针 [7] 实测 FAIL），
         *       即所有河普遍偏粗。</li>
         * </ul>
         */
        public static PrecipWeights defaults() { return new PrecipWeights(0.212, 0.10, 0.60); }
        public static PrecipWeights disabled() { return new PrecipWeights(1.0, 1.0, 0.0); }

        /** 降水 → 累积权重（均值 ≈ 1）。 */
        public double weight(double precip) {
            double r = precip / ref;
            if (r < floor) r = floor;
            return Math.pow(r, exponent);
        }
    }

    /**
     * ★ 2026-09-18（水文 M2-C）：<b>气候驱动的沿程衰减</b> —— 兑现"水文是一个整体"。
     *
     * <p>与常量 {@code decayPerWu} 的区别：常量只能让<b>全局</b>河普遍变细；
     * 气候驱动才产生<b>空间上不同的水文行为</b> ——
     * 干旱区蒸发强 ⇒ 河流流着流着就消失（<b>内流河 / 时令河</b>）；
     * 湿润区 {@code decay ≈ 0} ⇒ 河流穿流到海。</p>
     *
     * <p>公式（降水是干旱度最直接的代理）：</p>
     * <pre>
     *   decay(precip) = maxDecay · max(0, 1 − precip/ref)^exponent
     * </pre>
     * <p>⇒ {@code precip ≥ ref}（湿润）时 <b>decay = 0（完全不变）</b>；
     * {@code precip → 0}（极旱）时 {@code decay → maxDecay}。</p>
     *
     * @param maxDecay 极旱区衰减系数（1/wu）
     * @param ref      参考降水：≥ 此值视为湿润（decay = 0）
     * @param exponent 软化指数（&lt;1 ⇒ 半干旱区也有明显衰减）
     */
    public record DecayClimate(double maxDecay, double ref, double exponent) {
        /** 关闭（= 旧行为）。 */
        public static DecayClimate disabled() { return new DecayClimate(0.0, 1.0, 1.0); }

        /** 该降水处的沿程衰减系数（1/wu）。 */
        public double decayAt(double precip) {
            double r = precip / ref;
            if (r >= 1.0) return 0.0;                       // 湿润 ⇒ 不衰减
            double d = 1.0 - Math.max(0.0, r);
            return maxDecay * Math.pow(d, exponent);
        }
    }

    /**
     * 降水粗格点间距（<b>wu</b>，非 flow 格数）。
     *
     * <p><b>为什么必须粗采</b>（★ 2026-09-11 实测教训）：{@code PrecipSampler} 走
     * {@code CellGenerator.sample()}，实测单次约 <b>0.5 ms</b>（远贵于 flow 自身的
     * {@code terrainEQuick}）。若逐 flow 格采样（实测 region 内上万格），单 region 涨
     * <b>~215 ms</b>，{@code runFlowAccumProbe} 的 coldMs 从基线 1849 ms 飙到 17355 ms（9.4×）。</p>
     *
     * <p><b>为什么间距用固定 wu 且全球对齐</b>：格点取 {@code k·PRECIP_STEP_WU}（世界坐标），
     * 与 region 无关 → 同一点在任何 region 都取到<b>同一个值</b>，杜绝"region 相关伪影"；
     * 且相邻 region 的格点集合大量重叠 → 天然可复用。</p>
     *
     * <p>代价（如实说明）：跨度 1280wu 的 region 只有 ~6×6 格点 → 水文只吃到降水的
     * <b>大尺度分量</b>（气候带/大陆尺度），<b>地形雨的谷坡尺度细节不进入汇流加权</b>
     * （它仍完整存在于气候层：预览图层 / Cell.precipitation）。这是性能与保真度的取舍。</p>
     */
    private static final double PRECIP_STEP_WU = 320.0;

    /** 本次构建用到的降水格点值（局部缓存，避免同一格点重复调 sample()）。 */
    private java.util.HashMap<Long, Double> precipNodes;
    /** 降水取样器（构造时注入；null = 不启用降水加权）。 */
    private PrecipSampler precipSampler;
    /** 降水权重参数。 */
    private PrecipWeights precipWeights;
    /** ★ 2026-09-18 M2-C：气候驱动衰减参数（{@code null} = 不用气候驱动）。 */
    private DecayClimate decayClimate;
    /** ★ 2026-09-18 M2-C：逐格预计算的衰减系数（1/wu）；{@code null} = 改用常量 {@link #decayPerWu}。 */
    private double[] decayCell;

    // ===== ★ 2026-09-19（P1）连续流向场：给 D8 加【动量】=====

    /**
     * ★ 2026-09-19 <b>动量混合权重</b>（0.0 = 纯 D8 ⇒ 与旧行为【逐位一致】）。
     *
     * <h4>它修的是什么</h4>
     * <p>纯 D8 的流向只有 <b>8 个方向</b> ⇒ 河线每格必须转向 45° 的整数倍
     * ⇒ 实机表现为"**河网太直、太规则、分叉生硬**"（用户实机验收判据）。</p>
     *
     * <h4>依据（用户指定的参考，逐字）</h4>
     * <p>{@code SimpleHydrology/README.md:70-78}（2023-01 更新）：</p>
     * <pre>
     * The flooding system has been removed for now, because of buggyness and slowness. …
     * Momentum and discharge maps are now explicit and interact physically with the water
     * particles, giving river meandering behavior.
     * </pre>
     * <p>{@code SimpleHydrology/source/water.h:97-117} 的实体：</p>
     * <pre>
     *   vec2 fspeed = vec2(cell->momentumx, cell->momentumy);
     *   speed += lodsize*momentumTransfer*dot(normalize(fspeed), normalize(speed))
     *            /(volume + cell->discharge)*fspeed;      // ★ 动量传递
     *   cell->discharge_track += volume;
     *   cell->momentumx_track += volume*speed.x;          // ★ 累积动量图
     *   cell->momentumy_track += volume*speed.y;
     * </pre>
     * <p>参数 {@code water.h:50 momentumTransfer = 1.0f}。</p>
     *
     * <h4>本实现怎么落地</h4>
     * <pre>
     *   mom[cur]  = Σ_上游(accum[上游] · dir[上游])        // 累积动量（与 accum 同一次拓扑序推送）
     *   dir[cur]  = normalize( (1−w)·最陡下降单位向量 + w·normalize(mom[cur]) )
     * </pre>
     * <p>无上游（源头格）时 {@code mom = 0} ⇒ 自动退化为最陡下降（无惯性），
     * 与 SimpleHydrology 的 {@code /(volume + discharge)} 同义。</p>
     *
     * <h4>为什么安全</h4>
     * <ul>
     *   <li><b>不改 D8 有向无环图</b>：{@code flowTo} 与 {@code accum} 一字不动
     *       ⇒ 汇流量、河宽、干谷剔除全部不受影响；本场只用于<b>河线几何</b>（P2 追踪）。</li>
     *   <li><b>无环</b>：按 e 降序拓扑序计算，上游必先于下游（与 {@link #buildAccum} 同序）。</li>
     *   <li><b>确定性</b>：只依赖本网格内的 e / flowTo / accum，与 chunk 访问顺序无关。</li>
     *   <li><b>偏角有界</b>：混合方向相对最陡下降的偏角被 {@link #MOMENTUM_MAX_ANGLE_DEG} 夹住
     *       ⇒ 河线不会脱离开 D8 流向图。</li>
     * </ul>
     * <p><b>回退</b>：置 0.0（默认）即逐位回到纯 D8。</p>
     */
    public static double MOMENTUM_WEIGHT = 0.0;

    /**
     * ★ 2026-09-19 动量方向相对【最陡下降】的最大偏角（度）。
     *
     * <p>取 60° 的理由：D8 相邻方向的夹角本身就是 45°（正交→对角），
     * 若允许偏到 60°，河线可自由落在两格之间而仍朝下游；再大则可能横向漂移、
     * 使 P2 的追踪脱离 D8 流向图。</p>
     */
    public static double MOMENTUM_MAX_ANGLE_DEG = 60.0;

    /** 连续流向（单位向量，wu 坐标系）。{@code flowTo < 0} 的洼地格为 (0,0)。 */
    private double[] dirX;
    private double[] dirZ;

    public FlowField(double minWuX, double minWuZ, double maxWuX, double maxWuZ,
                     double cellSize, ElevationSampler sampler) {
        this(minWuX, minWuZ, maxWuX, maxWuZ, cellSize, sampler, null, PrecipWeights.disabled());
    }

    /**
     * @param precip  降水取样器；{@code null} = 纯面积累积（与旧路径逐位一致）
     * @param weights 降水权重参数（仅 {@code precip != null} 时生效）
     */
    public FlowField(double minWuX, double minWuZ, double maxWuX, double maxWuZ,
                     double cellSize, ElevationSampler sampler,
                     PrecipSampler precip, PrecipWeights weights) {
        this(minWuX, minWuZ, maxWuX, maxWuZ, cellSize, sampler, precip, weights, 0.0);
    }

    /**
     * ★ 2026-09-18（水文 M2）：<b>带沿程衰减</b>的构造器 —— 把"水量沿程只增不减"
     * 改为"沿途蒸发/入渗"，使【内流河 / 时令河】成为可能
     * （现实中干旱区河流流着流着就消失，这是最直观的水文现象之一）。
     *
     * <p>参考 geotransport 的 {@code solve_uniform}：沿流线乘 {@code exp(−∫decay dt)}。
     * 落到 D8 图上即 {@code accum[down] += accum[cur] · exp(−decay · dist)}。</p>
     *
     * <p>⚠ <b>默认 {@code decayPerWu = 0.0} ⇒ 与旧行为【逐位一致】</b>。</p>
     *
     * @param decayPerWu 沿程衰减系数（1/wu）。实测参考（`runWaterBalanceProbe`，grid 64）：
     *                   {@code 1e-4} ⇒ 成河格 −23%、河宽 ×0.99；{@code 1e-3} ⇒ 河宽 ×0.97；
     *                   {@code 2e-3} ⇒ 河宽 ×0.95、总水量 ×0.87
     */
    public FlowField(double minWuX, double minWuZ, double maxWuX, double maxWuZ,
                     double cellSize, ElevationSampler sampler,
                     PrecipSampler precip, PrecipWeights weights, double decayPerWu) {
        this(minWuX, minWuZ, maxWuX, maxWuZ, cellSize, sampler, precip, weights,
             decayPerWu, null);
    }

    /**
     * ★ 2026-09-18（水文 M2-C）：<b>气候驱动衰减</b>的完整构造器。
     *
     * <p>与常量 {@code decayPerWu} 的取舍：常量只能"全局变细"；
     * 气候驱动才能让<b>沙漠里的河消失、雨林里的河穿流</b>（见 {@link DecayClimate}）。</p>
     *
     * <p>⚠ {@code decayClimate} 仅在 {@code precip != null} 时生效
     * （气候驱动需要降水信息）⇒ 传了气候但没传降水 = 不衰减。</p>
     *
     * @param decayClimate 气候驱动参数；{@code null} 或 {@code maxDecay == 0} ⇒ 不用
     */
    public FlowField(double minWuX, double minWuZ, double maxWuX, double maxWuZ,
                     double cellSize, ElevationSampler sampler,
                     PrecipSampler precip, PrecipWeights weights, double decayPerWu,
                     DecayClimate decayClimate) {
        this.cellSize = Math.max(1.0, cellSize);
        this.decayPerWu = Math.max(0.0, decayPerWu);
        this.decayClimate = (decayClimate != null && decayClimate.maxDecay() > 0.0)
                ? decayClimate : null;
        this.originX = minWuX;
        this.originZ = minWuZ;
        this.nx = Math.max(2, (int) Math.ceil((maxWuX - minWuX) / this.cellSize) + 1);
        this.nz = Math.max(2, (int) Math.ceil((maxWuZ - minWuZ) / this.cellSize) + 1);
        int n = nx * nz;
        this.e = new double[n];
        this.flowTo = new int[n];
        this.accum = new double[n];
        // ★ 2026-09-20：基础产流单列一份 ⇒ buildAccum 可幂等重算（填洼优先要重跑一遍）。
        this.baseAccum = new double[n];
        Arrays.fill(this.baseAccum, this.cellSize * this.cellSize);
        System.arraycopy(this.baseAccum, 0, this.accum, 0, n);
        for (int j = 0; j < nz; j++) {
            for (int i = 0; i < nx; i++) {
                e[j * nx + i] = sampler.eAt(originX + i * this.cellSize,
                                           originZ + j * this.cellSize);
            }
        }
        // ★ Phase C：降水加权初始累积（每格产流量 = 面积 × 降水权重）
        if (precip != null && weights != null) {
            this.precipSampler = precip;
            this.precipWeights = weights;
            this.precipNodes = new java.util.HashMap<>();
            // ★ 2026-09-18 M2-C：气候驱动衰减 —— 与降水加权【共用同一次】precipAtWu 采样
            if (this.decayClimate != null) this.decayCell = new double[n];
            for (int j = 0; j < nz; j++) {
                double wz = originZ + j * this.cellSize;
                for (int i = 0; i < nx; i++) {
                    double wx = originX + i * this.cellSize;
                    double p = precipAtWu(wx, wz);
                    double base = this.cellSize * this.cellSize * weights.weight(p);
                    baseAccum[j * nx + i] = base;
                    accum[j * nx + i] = base;
                    if (this.decayCell != null) {
                        this.decayCell[j * nx + i] = this.decayClimate.decayAt(p);
                    }
                }
            }
        }
        buildFlow();
        buildAccum();
        // ★ 2026-09-19（P1）：连续流向场（D8 ⊕ 上游累积动量）。MOMENTUM_WEIGHT = 0 时逐位退化。
        buildDirections();
    }

    /** 世界坐标处的降水（由全球对齐的粗格点双线性插值）。 */
    private double precipAtWu(double wx, double wz) {
        double gx = wx / PRECIP_STEP_WU, gz = wz / PRECIP_STEP_WU;
        int i0 = (int) Math.floor(gx), j0 = (int) Math.floor(gz);
        double fi = gx - i0, fj = gz - j0;
        double a0 = precipNode(i0, j0),     a1 = precipNode(i0 + 1, j0);
        double b0 = precipNode(i0, j0 + 1), b1 = precipNode(i0 + 1, j0 + 1);
        double a = a0 + (a1 - a0) * fi;
        double b = b0 + (b1 - b0) * fi;
        return a + (b - a) * fj;
    }

    /** 降水格点值（<b>全球对齐</b>：坐标 = k·PRECIP_STEP_WU，与 region 无关 → 跨 region 一致）。 */
    private double precipNode(int ix, int iz) {
        long k = ((long) ix << 32) | (iz & 0xFFFFFFFFL);
        Double v = precipNodes.get(k);
        if (v != null) return v;
        double val = precipSampler.precipitationAt(ix * PRECIP_STEP_WU, iz * PRECIP_STEP_WU);
        precipNodes.put(k, val);
        return val;
    }

    /**
     * 建流向用的高程面（★ 2026-09-20）：填洼优先已初始化时用【填洼面】，
     * 否则用原始 e（构造器路径，向后兼容 17+ 处既有调用）。
     */
    private double flowE(int idx) {
        return eFilledR != null ? eFilledR[idx] : e[idx];
    }

    /** D8 流向：8 邻最低，严格更低才连边。高程面见 {@link #flowE}（填洼优先 ⇒ 无内流终点）。 */
    private void buildFlow() {
        for (int j = 0; j < nz; j++) {
            for (int i = 0; i < nx; i++) {
                int idx = j * nx + i;
                flowTo[idx] = lowestNeighbor(i, j);
            }
        }
    }

    /** 8 邻中高程最低者（须严格低于自身）；返回 -1 表示无下坡。固定扫描序保证确定性。 */
    private int lowestNeighbor(int ci, int cj) {
        int best = -1;
        double bestE = flowE(cj * nx + ci);
        for (int dj = -1; dj <= 1; dj++) {
            for (int di = -1; di <= 1; di++) {
                if (di == 0 && dj == 0) continue;
                int ni = ci + di, nj = cj + dj;
                if (ni < 0 || ni >= nx || nj < 0 || nj >= nz) continue;
                double ne = flowE(nj * nx + ni);
                if (ne < bestE) { bestE = ne; best = nj * nx + ni; }
            }
        }
        return best;
    }

    // ===== 填洼（2026-09-07 湖泊功能）=====

    /** priority-flood 判为"被水填起"的最小水深（block）：滤掉浮点噪声。 */
    private static final double FILL_EPS = 0.05;

    /**
     * 用【真实地形】采样器建填洼层：湖泊必须按真实高程判定，不能按选线用的
     * routingE（山压低后的 e）——否则"湖"会落在被人为压低的坡面上。
     *
     * <p>算法（Barnes 2014 priority-flood）：每次取当前最低格向外扩，
     * 邻格溢出高程 = max(自身高程, 当前格溢出高程)。
     * 结果 {@code eFilled} 即"若在此蓄水、水位涨到多少才会溢出"。</p>
     *
     * <p><b>同时覆盖闭合洼地与开口洼地</b>：真湖多是有出口、但出口坎（sill）高于
     * 盆地的【开口洼地】——D8 的 flowTo=-1 只认闭合洼地，漏掉这一类（实测
     * 本地形闭合洼地极少 → 湖数 0）。</p>
     *
     * <h3>★ 2026-09-15 修复：种子由"全部边界格"改为"网格最低格"</h3>
     *
     * <p><b>原实现</b>把<b>所有边界格</b>当作种子（{@code eFilled = eFill}），
     * 语义是"水可从任意边界自由流出网格"。这对<b>全球网格</b>是对的（边界=海洋），
     * 但本类的网格是<b>局部的</b>（每个 region 各建一份，见
     * {@code RiverLineNetwork.build}），于是带来两个实测缺陷：</p>
     * <ol>
     *   <li><b>边界格永远不是洼地</b>：边界格 {@code eFilled == eFill} ⇒ 水深恒 0
     *       ⇒ {@link #isBasinCell} 恒 false。实测（{@code LakeEdgeProbe}）：
     *       边界圈 216 格水深 <b>100% 为 0</b>，而内部洼地占 13.31%
     *       ⇒ 触及网格边界的湖被"泄水"掉。</li>
     *   <li><b>相邻 region 结果不一致</b>：每个 region 网格不同 ⇒ 泄水点不同
     *       ⇒ 整个 {@code eFilled} 场不同。实测重叠区 <b>99.8%</b> 水位不一致、
     *       最大差 <b>13.86 block</b> ⇒ 湖跨 region 接缝时被硬截断
     *       （对应用户反馈"湖没到边缘就结束"）。</li>
     * </ol>
     *
     * <h3>★ 2026-09-15 修复：种子由"全部边界格"改为"真实海洋格"</h3>
     *
     * <p>演化过程（两版都实测过，务必保留以免重犯）：</p>
     * <ol>
     *   <li><b>原实现</b>：所有边界格都是种子（语义"水可从任意边界流出"）。
     *       对全球网格正确，但本类网格是<b>局部的</b>（每 region 各建一份）
     *       ⇒ 边界格 {@code eFilled == eFill} ⇒ 水深恒 0 ⇒ 永不成湖。
     *       实测：边界圈 <b>100%</b> 水深为 0，而内部洼地占 13.31%。</li>
     *   <li><b>第二版（已放弃）</b>：改为"网格最低格"作唯一种子。边界格确实能成湖了
     *       （边界圈水深 0 的比例降到 54.6%），<b>但引入巨型湖</b> —— 实测
     *       {@code runLakeBasinProbe} 出现 {@code cells=772、最深 28.30} 的湖
     *       （半径约 376wu）。原因：单一出口会让大片连通区域被填成湖。</li>
     *   <li><b>现版本</b>：种子 = <b>{@code eFill <= outletE} 的真实海洋格</b>。
     *       物理上正确（海洋才是最终出水口），且边界格若是陆地则不再是出口
     *       ⇒ 可成湖；又因出口是整片海洋而非单一点，不会过度填充。
     *       纯内陆网格（无海洋格）兜底用最低格。</li>
     * </ol>
     *
     * @param outletE 出水口高程（真实海平面）；低于等于它的格视为海洋/出口
     */
    public void computeFill(ElevationSampler fillSampler, double outletE) {
        int n = nx * nz;
        this.eFill = new double[n];
        this.eFilled = new double[n];
        Arrays.fill(eFilled, Double.NaN);
        for (int j = 0; j < nz; j++) {
            for (int i = 0; i < nx; i++) {
                eFill[j * nx + i] = fillSampler.eAt(originX + i * cellSize,
                                                   originZ + j * cellSize);
            }
        }
        PriorityQueue<double[]> pq =
                new PriorityQueue<>(Comparator.comparingDouble(a -> a[0]));
        // ★ 种子 = 真实海洋格（最终出水口）
        int seeds = 0;
        for (int i = 0; i < n; i++) {
            if (eFill[i] <= outletE) {
                eFilled[i] = eFill[i];
                pq.add(new double[]{eFill[i], i});
                seeds++;
            }
        }
        // 兜底：纯内陆网格（无海洋格）→ 用最低格作唯一出口，保证扩散能启动
        if (seeds == 0) {
            int minIdx = 0;
            for (int i = 1; i < n; i++) {
                if (eFill[i] < eFill[minIdx]) minIdx = i;
            }
            eFilled[minIdx] = eFill[minIdx];
            pq.add(new double[]{eFill[minIdx], minIdx});
        }
        while (!pq.isEmpty()) {
            double[] cur = pq.poll();
            double h = cur[0];
            int idx = (int) cur[1];
            if (h > eFilled[idx]) continue;         // 过期条目（已被更低的溢出高程覆盖）
            int ci = idx % nx, cj = idx / nx;
            for (int dj = -1; dj <= 1; dj++) {
                for (int di = -1; di <= 1; di++) {
                    if (di == 0 && dj == 0) continue;
                    int ni = ci + di, nj = cj + dj;
                    if (ni < 0 || ni >= nx || nj < 0 || nj >= nz) continue;
                    int nIdx = nj * nx + ni;
                    if (!Double.isNaN(eFilled[nIdx])) continue;
                    double f = Math.max(eFill[nIdx], h);
                    eFilled[nIdx] = f;
                    pq.add(new double[]{f, nIdx});
                }
            }
        }
    }

    /** 是否已建填洼层。 */
    public boolean hasFill() { return eFilled != null; }

    // ===== ★★★ 2026-09-20「填洼优先」初始化（生产路径唯一入口）★★★

    /**
     * 填洼面每步递增的微坡（e 单位）。
     *
     * <p>参考 {@code worldgen-master/src/hydrology.rs:175-181} 取 {@code 1e-5}：</p>
     * <pre>
     *   // Add tiny epsilon so filled areas slope toward their outlet —
     *   // without this, D8 can't find a downhill direction on flat filled areas
     *   // and rivers dead-end inland.
     * </pre>
     * <p>量级说明：填起的洼地宽 ~50 格 ⇒ 累计抬高 ~5e-4（e 单位），
     * 远小于湖深判据 {@link #FILL_EPS}=0.05，也远小于任何可视高程分辨率
     * ⇒ 只影响 D8 能否找到下坡，不影响任何几何。</p>
     */
    private static final double FILL_SLOPE_EPS = 1e-5;

    /**
     * <b>填洼优先</b>：把【流向/累积/方向场】重建在 e 空间填洼面上 —— 修的正是
     * 用户判据「河流怎么可能突然结束」「水流堆积后溢出会继续向下流动」。
     *
     * <p>顺序（与参考 {@code priority_flood → flow_dir → accum} 一致）：</p>
     * <ol>
     *   <li>{@code priority-flood} 在 {@code e[]}（= routingE 口径）上填洼，种子 =
     *       海洋格（{@code e <= oceanE}），纯内陆网格兜底用最低格；</li>
     *   <li>填起区每步加 {@link #FILL_SLOPE_EPS} ⇒ <b>朝出口单调微降</b>
     *       ⇒ 每个格都有下坡，洼地不再是终点；</li>
     *   <li>在填洼面上重建 {@code flowTo}（严格最陡下降）与 {@code accum}
     *       （按填洼面降序 = 拓扑序），并重建连续方向场。</li>
     * </ol>
     *
     * <p><b>物理意义</b>：洼地里的水涨到 spill 高程后必然从最低缺口溢出继续下行 ——
     * 「堆积 → 溢出 → 继续向下流」由构造保证，不再需要任何"续流补丁"。</p>
     *
     * <p><b>确定性</b>：priority-flood 用 {@link PriorityQueue}，同高程按插入序稳定；
     * 方向扫描序固定 ⇒ 与旧路径同样可复现（{@code runHydrologyDeterminismProbe} 守）。</p>
     *
     * @param oceanE 海洋/最终出水口在 <b>e 空间</b>的阈值（{@code RiverLineParams.oceanE()}，
     *               生产默认 −0.02）
     */
    public void initializeFillFirstRouting(double oceanE) {
        fillRoutingSurface(oceanE);
        buildFlow();
        buildAccum();
        buildDirections();
    }

    /** 是否已启用填洼优先流向面。 */
    public boolean initializedFillFirst() { return eFilledR != null; }

    /**
     * ★★★ 建流向所用的高程面（追踪器<b>必须</b>用它）★★★
     *
     * <p>填洼优先已初始化时返回【填洼面】（洼地已填平并带 epsilon 微坡 ⇒ 处处有下坡），
     * 否则返回原始 e。{@code RiverLineNetwork.downhillNeighbor} 等追踪判据若仍读
     * {@code eAt}（原始 e），就会继续看见原始洼地并在此终止 —— 实测该漏点会让
     * "填洼优先"完全失效（河尾无水 5→6、内陆终止 5→5，一字未改善）。</p>
     *
     * <p><b>不要</b>把它用于 e 口径的标定判据（{@code sourceMinE} / {@code oceanE}）：
     * 那些阈值是与原始 e 一起标定的。</p>
     */
    public double flowElevAt(int idx) {
        return flowE(idx);
    }

    /** 填洼优先的溢出高程（e 单位）；未启用返回 NaN。 */
    public double routingFillAt(int idx) { return eFilledR == null ? Double.NaN : eFilledR[idx]; }

    /**
     * 在 {@code e[]} 上做 priority-flood，结果写入 {@link #eFilledR}（含 epsilon 微坡）。
     *
     * <p>与 {@link #computeFill}（块空间、供湖提取）同算法、不同高程面与用途 ——
     * 本方法专门服务流向。种子同取"海洋格"，使水朝最近海岸/区域外排。</p>
     */
    private void fillRoutingSurface(double oceanE) {
        int n = nx * nz;
        this.eFilledR = new double[n];
        Arrays.fill(eFilledR, Double.NaN);
        PriorityQueue<double[]> pq = new PriorityQueue<>(Comparator.comparingDouble(a -> a[0]));
        int seeds = 0;
        for (int i = 0; i < n; i++) {
            if (e[i] <= oceanE) {
                eFilledR[i] = e[i];
                pq.add(new double[]{e[i], i});
                seeds++;
            }
        }
        if (seeds == 0) {
            // 纯内陆网格（无海洋格）：兜底用最低格作唯一出口，保证水有去处
            int minIdx = 0;
            for (int i = 1; i < n; i++) {
                if (e[i] < e[minIdx]) minIdx = i;
            }
            eFilledR[minIdx] = e[minIdx];
            pq.add(new double[]{e[minIdx], minIdx});
        }
        final int cap = Math.min(n, BASIN_FILL_MAX);
        int visited = 0;
        while (!pq.isEmpty() && visited < cap) {
            double[] cur = pq.poll();
            double h = cur[0];
            int idx = (int) cur[1];
            if (h > eFilledR[idx]) continue;              // 过期条目
            visited++;
            int ci = idx % nx, cj = idx / nx;
            for (int dj = -1; dj <= 1; dj++) {
                for (int di = -1; di <= 1; di++) {
                    if (di == 0 && dj == 0) continue;
                    int ni = ci + di, nj = cj + dj;
                    if (ni < 0 || ni >= nx || nj < 0 || nj >= nz) continue;
                    int nIdx = nj * nx + ni;
                    if (!Double.isNaN(eFilledR[nIdx])) continue;
                    // ★ epsilon 微坡：抬到"当前格 + ε" ⇒ 填起区朝种子（出口）单调微降
                    double f = Math.max(e[nIdx], h + FILL_SLOPE_EPS);
                    eFilledR[nIdx] = f;
                    pq.add(new double[]{f, nIdx});
                }
            }
        }
    }

    /** 填洼扩散的访问上限（格）：防病态地形上的长循环（正常 region 网格 ~3k 格）。 */
    private static final int BASIN_FILL_MAX = 1 << 20;

    /** 真实地形高程（block）；未建填洼层返回 {@link Double#NaN}。 */
    public double fillEAt(int idx) { return eFill == null ? Double.NaN : eFill[idx]; }

    /** 溢出高程（block）：该格蓄水后涨到多少才溢出。 */
    public double filledAt(int idx) { return eFilled == null ? Double.NaN : eFilled[idx]; }

    /** 该格的水深（= 溢出高程 − 真实地形）；非洼地格为 0。 */
    public double basinDepthAt(int idx) {
        if (eFilled == null) return 0.0;
        double d = eFilled[idx] - eFill[idx];
        return d > FILL_EPS ? d : 0.0;
    }

    /** 该格是否在洼地内（会被水填起）。 */
    public boolean isBasinCell(int idx) { return basinDepthAt(idx) > 0.0; }

    /**
     * 汇流累积：按 e 降序处理（上游必先于下游），{@code accum[down] += accum[cur]}。
     *
     * <p>★ 2026-09-18（水文 M2）：加入<b>沿程衰减</b>
     * {@code accum[down] += accum[cur] · exp(−decayPerWu · dist)}，
     * 使水量不再"只增不减" ⇒ 支持<b>内流河 / 时令河</b>。</p>
     *
     * <p>⚠ <b>{@code decayPerWu == 0.0} 时走【原路径】（不加乘法）⇒ 与旧行为逐位一致</b>。
     * （虽 {@code x * 1.0} 在 IEEE754 下亦精确，但仍显式分支 ——
     * 本项目已多次因"看似等价的浮点改写"产生逐位差异，零风险优先。）</p>
     */
    private void buildAccum() {
        int n = nx * nz;
        // ★ 2026-09-20：从【基础产流】重算 ⇒ 本方法可幂等重跑（填洼优先要重建一遍）。
        //   不清零直接再跑会把汇流面积翻倍（accum[down] += 是累加）。
        if (baseAccum != null) System.arraycopy(baseAccum, 0, accum, 0, n);
        Integer[] order = new Integer[n];
        for (int i = 0; i < n; i++) order[i] = i;
        // 拓扑序必须与 flowTo 用的【同一高程面】一致（填洼面上严格单调 ⇒ 排序即拓扑序）。
        Arrays.sort(order, (a, b) -> Double.compare(flowE(b), flowE(a)));
        final boolean attenuate = decayPerWu > 0.0 || decayCell != null;
        final double diag = Math.sqrt(2.0) * cellSize;
        for (int k = 0; k < n; k++) {
            int cur = order[k];
            int down = flowTo[cur];
            if (down < 0) continue;                       // 洼地/平地 ⇒ 终止
            if (!attenuate) {
                accum[down] += accum[cur];                // ★ 原路径（逐位一致）
                continue;
            }
            // 8 邻：行列都变 ⇒ 对角（cellSize·√2）；否则正交（cellSize）
            int dx = Math.abs((cur % nx) - (down % nx));
            int dz = Math.abs((cur / nx) - (down / nx));
            double dist = (dx == 1 && dz == 1) ? diag : cellSize;
            // 衰减系数：气候驱动优先（逐格）；否则用常量
            double d = (decayCell != null) ? decayCell[cur] : decayPerWu;
            if (d <= 0.0) {
                accum[down] += accum[cur];                // 湿润区 ⇒ 与旧路径逐位一致
            } else {
                accum[down] += accum[cur] * Math.exp(-d * dist);
            }
        }
    }

    // ===== ★ 2026-09-19（P1）连续流向场 =====

    /**
     * 建立连续流向场（D8 最陡下降 ⊕ 上游累积动量）。见 {@link #MOMENTUM_WEIGHT} 的完整依据。
     *
     * <p>⚠ 本场<b>只用于河线几何</b>（P2 沿它追踪）；{@code flowTo} / {@code accum}
     * 一字不动 ⇒ 汇流量、河宽、干谷剔除不受影响。</p>
     */
    private void buildDirections() {
        int n = nx * nz;
        dirX = new double[n];
        dirZ = new double[n];
        final double w = MOMENTUM_WEIGHT;
        if (w <= 0.0) {
            // 纯 D8（默认）：不看动量 ⇒ 与旧行为逐位一致
            for (int j = 0; j < nz; j++) {
                for (int i = 0; i < nx; i++) {
                    int idx = j * nx + i;
                    int down = flowTo[idx];
                    if (down < 0) continue;                       // 洼地 ⇒ (0,0)
                    double dx = (down % nx) - i, dz = (down / nx) - j;
                    double len = Math.sqrt(dx * dx + dz * dz);
                    dirX[idx] = dx / len;
                    dirZ[idx] = dz / len;
                }
            }
            return;
        }
        // 有动量：与 buildAccum 同一次拓扑序（e 降序 ⇒ 上游必先于下游），把动量推给下游
        double[] momX = new double[n], momZ = new double[n];
        Integer[] order = new Integer[n];
        for (int i = 0; i < n; i++) order[i] = i;
        Arrays.sort(order, (a, b) -> Double.compare(flowE(b), flowE(a)));
        final double cosMax = Math.cos(Math.toRadians(MOMENTUM_MAX_ANGLE_DEG));
        for (int k = 0; k < n; k++) {
            int cur = order[k];
            int down = flowTo[cur];
            // ① 本格最陡下降单位向量（洼地无方向）
            double sx = 0.0, sz = 0.0;
            if (down >= 0) {
                double dx = (down % nx) - (cur % nx), dz = (down / nx) - (cur / nx);
                double len = Math.sqrt(dx * dx + dz * dz);
                sx = dx / len;
                sz = dz / len;
            }
            // ② 上游累积动量的单位向量（无上游 ⇒ 退化）
            double mx = momX[cur], mz = momZ[cur];
            double mlen = Math.sqrt(mx * mx + mz * mz);
            double ux, uz;
            if (mlen > 1e-12) {
                ux = mx / mlen;
                uz = mz / mlen;
            } else {
                ux = sx;
                uz = sz;
            }
            // ③ 混合；并把权重夹到"偏角不超过 MOMENTUM_MAX_ANGLE_DEG"
            double dx1, dz1;
            if (down < 0) {
                dx1 = 0.0; dz1 = 0.0;                             // 洼地：无下游方向
            } else {
                double dot = ux * sx + uz * sz;
                double ang = Math.acos(Math.max(-1.0, Math.min(1.0, dot)));
                double maxRad = Math.acos(cosMax);
                double wEff = (ang > 1e-6) ? Math.min(w, maxRad / ang) : w;
                double bx = (1.0 - wEff) * sx + wEff * ux;
                double bz = (1.0 - wEff) * sz + wEff * uz;
                double blen = Math.sqrt(bx * bx + bz * bz);
                if (blen < 1e-9) {                                // 反向抵消 ⇒ 退化为最陡下降
                    dx1 = sx; dz1 = sz;
                } else {
                    dx1 = bx / blen; dz1 = bz / blen;
                }
            }
            dirX[cur] = dx1;
            dirZ[cur] = dz1;
            // ④ 把本格动量推给下游（权重 = 本格累积量，与 accum 同结构）
            if (down >= 0 && (dx1 != 0.0 || dz1 != 0.0)) {
                momX[down] += accum[cur] * dx1;
                momZ[down] += accum[cur] * dz1;
            }
        }
    }

    /** 指定格的连续流向 X 分量（单位向量，wu 坐标系）。 */
    public double dirXAt(int idx) { return dirX[idx]; }

    /** 指定格的连续流向 Z 分量（单位向量，wu 坐标系）。 */
    public double dirZAt(int idx) { return dirZ[idx]; }

    /**
     * 世界坐标处的连续流向（双线性插值，单位向量）。
     *
     * <p>供 P2 的河线追踪使用 —— 沿本场推进即得"水的运动路线"的自然曲线，
     * 而不是 D8 的 8 邻折线。</p>
     *
     * @return 长度 2 的数组 {ux, uz}；无有效方向时返回 {@code {0,0}}
     */
    public double[] dirAtWu(double wx, double wz) {
        double fx = (wx - originX) / cellSize, fz = (wz - originZ) / cellSize;
        int i0 = (int) Math.floor(fx), j0 = (int) Math.floor(fz);
        double tx = fx - i0, tz = fz - j0;
        double sx = 0.0, sz = 0.0, wt = 0.0;
        for (int dj = 0; dj <= 1; dj++) {
            for (int di = 0; di <= 1; di++) {
                int i = i0 + di, j = j0 + dj;
                if (i < 0 || i >= nx || j < 0 || j >= nz) continue;
                double bw = (di == 0 ? 1.0 - tx : tx) * (dj == 0 ? 1.0 - tz : tz);
                if (bw <= 0.0) continue;
                int idx = j * nx + i;
                sx += bw * dirX[idx];
                sz += bw * dirZ[idx];
                wt += bw;
            }
        }
        if (wt <= 0.0) return new double[]{0.0, 0.0};
        double len = Math.sqrt(sx * sx + sz * sz);
        if (len < 1e-12) return new double[]{0.0, 0.0};
        return new double[]{sx / len, sz / len};
    }

    /** 世界坐标 → 格索引（钳制到网格内）。 */
    public int indexOf(double wx, double wz) {
        int i = (int) Math.round((wx - originX) / cellSize);
        int j = (int) Math.round((wz - originZ) / cellSize);
        i = Math.max(0, Math.min(nx - 1, i));
        j = Math.max(0, Math.min(nz - 1, j));
        return j * nx + i;
    }

    /**
     * ★ 2026-09-18 M2-C：指定格【实际使用】的沿程衰减系数（1/wu）。
     *
     * <p>供诊断探针与实现【同口径】比对 —— 本项目已多次因探针自算降水
     * （如用格中心 {@code precipitationAt}）而实现走粗格点插值 {@code precipAtWu}
     * 产生口径差异，得出假结论（见门禁清单 §D-1）。</p>
     *
     * @return 气候驱动时为该格预计算值；否则为常量 {@code decayPerWu}
     */
    public double decayAt(int idx) {
        return (decayCell != null) ? decayCell[idx] : decayPerWu;
    }

    /** 指定格的汇流面积（wu²）。 */
    public double accumAt(int idx) {
        return accum[idx];
    }

    public int cols() { return nx; }
    public int rows() { return nz; }
    public double eAt(int idx) { return e[idx]; }
    public int flowTo(int idx) { return flowTo[idx]; }
    public boolean inBounds(int i, int j) { return i >= 0 && i < nx && j >= 0 && j < nz; }

    /**
     * 是否存在"网格内"的更低邻居（严格低于 curE − minDrop）。
     * 用于终止判定：有则安全下坡（继续追踪），无则需进一步判断是湖还是越界回滚。
     */
    /**
     * {@code idx} 的【上游】邻格：8 邻中 D8 流向恰为 {@code idx} 的格，即直接汇水入该格的格。
     *
     * <p>flowTo 是"每格 → 下游"的正向映射，本方法做局部反向查询（扫 8 邻即可，无需
     * 建全局逆邻接表）。用于河源扇形散流：找补给河头的细流分支。</p>
     *
     * <p>固定扫描序（与 {@link #lowestNeighbor} 一致）保证跨版本确定性。</p>
     */
    public List<Integer> upstreamOf(int idx) {
        List<Integer> ups = new ArrayList<>(4);
        int ci = idx % nx, cj = idx / nx;
        for (int dj = -1; dj <= 1; dj++) {
            for (int di = -1; di <= 1; di++) {
                if (di == 0 && dj == 0) continue;
                int ni = ci + di, nj = cj + dj;
                if (ni < 0 || ni >= nx || nj < 0 || nj >= nz) continue;
                int n = nj * nx + ni;
                if (flowTo[n] == idx) ups.add(n);
            }
        }
        return ups;
    }

    public boolean hasInBoundsDownhill(int idx, double minDrop) {
        int ci = idx % nx, cj = idx / nx;
        double curE = e[idx];
        for (int dj = -1; dj <= 1; dj++) {
            for (int di = -1; di <= 1; di++) {
                if (di == 0 && dj == 0) continue;
                int ni = ci + di, nj = cj + dj;
                if (ni < 0 || ni >= nx || nj < 0 || nj >= nz) continue;
                if (e[nj * nx + ni] < curE - minDrop) return true;
            }
        }
        return false;
    }

    /**
     * 该格是否紧邻网格边界（8 邻存在越界位置）。
     * 无网格内更低邻居却紧邻边界 → 河流想"流出网格"但不可见 → 不安全（应回滚，对齐 PL-RGA _hasUnsafeDownhillNeighbor）。
     */
    public boolean touchesGridEdge(int idx) {
        int ci = idx % nx, cj = idx / nx;
        for (int dj = -1; dj <= 1; dj++) {
            for (int di = -1; di <= 1; di++) {
                if (di == 0 && dj == 0) continue;
                int ni = ci + di, nj = cj + dj;
                if (ni < 0 || ni >= nx || nj < 0 || nj >= nz) return true;
            }
        }
        return false;
    }
    public double cellCenterX(int idx) { return originX + (idx % nx) * cellSize; }
    public double cellCenterZ(int idx) { return originZ + (idx / nx) * cellSize; }

}
