package com.geogenesis.worldgen.terrain.morph;

import com.electronwill.nightconfig.core.file.CommentedFileConfig;
import com.electronwill.nightconfig.toml.TomlFormat;
import com.geogenesis.config.*;
import java.nio.file.*;
import java.util.*;

public final class CoverageChecks {
    static void same(double x,double y,String msg){CoverageProbe.require(Double.doubleToRawLongBits(x)==Double.doubleToRawLongBits(y),msg);}
    static void checks(CoverageProbe p,Path out)throws Exception {
        StringBuilder text=new StringBuilder();
        double[][] points={{-3072,-3072},{3840,1024},{3328,-3328},{4096,-3584},{-1280,-2816}};
        float strength=p.cfg.strength;p.cfg.strength=0;
        for(double[] q:points){
            double x=q[0],z=q[1];
            same(p.land.oldCoverageHeight(x,z),p.coverage.height(x,z),"coverage zero node graph");
            double[] v=p.values(x,z);same(v[0],v[1],"whole A zero");same(v[0],v[2],"whole B zero");
        }
        p.cfg.strength=strength;text.append("zero strength: coverage original graph + covered A/B bitwise, 5 representatives PASS\n");
        for(double[] q:points){
            double x=q[0],z=q[1],r=p.land.regionHeight(x,z),c=p.coverage.height(x,z);
            same(r,p.land.overlay(r,0,Double.NaN),"alpha0 ignores NaN");
            same(c,p.land.overlay(Double.NaN,1,c),"alpha1 ignores region");
            double v=p.coverage.height(x,z);p.coverage.height(z,x);same(v,p.coverage.height(x,z),"coverage order");
            double[] all=p.values(x,z);p.values(z,x);CoverageProbe.require(Arrays.equals(all,p.values(x,z)),"all query order");
            double independentRaw=MorphNoiseEval.eval(p.coverage.raw,x,z)+p.delta(p.coverage::shell,x,z)/(MorphScale.E_SPAN*.475f);
            same(independentRaw,p.coverage.alter(x,z),"coverage raw independent difference");
            double independent=(MorphNoiseEval.eval(new MorphNoise.Terrace(new MorphNoise.ScalarIdentity(),.9f,.15f,.35f,.4f,4,0,1.05f,false),independentRaw,0)+MorphNoiseEval.eval(p.coverage.surface,x,z))*.475f;
            CoverageProbe.require(Math.abs(independent-c)<1e-12,"coverage raw then original 1.05 terrace surface shell");
        }
        text.append("alpha0 ignores NaN coverage; alpha1 ignores NaN region; coverage raw independent difference and 1.05 terrace/surface/shell; query order PASS\n");
        double r=.21,c=.43,lo=MorphAssembly.MTN_BLEND_LOW,hi=MorphAssembly.MTN_BLEND_HIGH;
        for(double eps:new double[]{1e-3,1e-5,1e-7,1e-9}){
            CoverageProbe.require(Math.abs(p.land.overlay(r,lo+eps,c)-r)<eps*2,"alpha low retreat");
            CoverageProbe.require(Math.abs(p.land.overlay(r,hi-eps,c)-c)<eps*2,"alpha high retreat");
        }
        text.append("coverage alpha low/high retreat 1e-3..1e-9 PASS\n");
        // Real assembly formulas, synthetic constant edge source isolates exact assembly joins.
        double shore=(double)(.268f*(.5f/.302f));
        for(double[] q:points){
            double x=q[0],z=q[1],landB=p.values(x,z)[1]*236;
            double end=shore+.085*(1+.45*Math.min(1,Math.max(0,landB)/110));
            for(double join:new double[]{shore,end}){
                double[] errors=new double[4];int i=0;
                for(double eps:new double[]{1e-3,1e-5,1e-7,1e-9}){
                    var left=new MorphOceanAssembler((u,v)->p.values(u,v)[1],(u,v)->2*(join-eps)-1,CoverageProbe.SEED+3).enableCoastalDetail(CoverageProbe.SEED);
                    var right=new MorphOceanAssembler((u,v)->p.values(u,v)[1],(u,v)->2*(join+eps)-1,CoverageProbe.SEED+3).enableCoastalDetail(CoverageProbe.SEED);
                    errors[i++]=Math.abs(left.heightBlocks(x,z)-right.heightBlocks(x,z));
                }
                CoverageProbe.require(errors[3]<1e-4 && errors[3]<=errors[0],"assembly join retreat");
                text.append(String.format(Locale.ROOT,"assembly seam x=%.0f z=%.0f edge=%.10f |H+-|=%s\n",x,z,join,Arrays.toString(errors)));
            }
        }
        // A deliberate missing-coverage negative control must detect a change at alpha=1.
        double x=4096,z=-3584;var s=p.land.sample(x,z);CoverageProbe.require(s.alpha()==1,"alpha1 fixture");
        double missing=CoverageProbe.toE(p.land.overlay(p.a.sampleLand(x,z,s.weight()),s.mask(),p.land.oldCoverageHeight(x,z)));
        same(missing,s.e(),"missing coverage negative control unchanged");
        CoverageProbe.require(p.values(x,z)[1]!=missing,"full coverage is actually executing");
        text.append("negative control: missing coverage falsely unchanged at actual alpha1; full raw candidate changes it PASS\n");
        Files.writeString(out.resolve("coverage-checks.txt"),text);System.out.println(text);
    }
    public static void main(String[] args)throws Exception {
        try(var f=CommentedFileConfig.of(Path.of(args[0]),TomlFormat.instance())){
            f.load();CoverageProbe.require(GeoGenesisConfig.SPEC.isCorrect(f),"config");GeoGenesisConfig.SPEC.setConfig(f);
            var params=GeoGenesisConfig.INSTANCE.buildParams();var c=RidgeConfigAdapter.fromConfig(GeoGenesisConfig.INSTANCE);c.horizontalScale=(float)params.horizontalScale();
            checks(new CoverageProbe(params,c),Path.of(args[1]));
        }
    }
}
