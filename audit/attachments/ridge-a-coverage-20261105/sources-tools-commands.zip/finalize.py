from pathlib import Path
import hashlib,json,subprocess,shutil,zipfile
out=Path(__file__).resolve().parent;root=out.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((out/'before.json').read_text())
allowed=['audit/README.md','audit/GeoGenesis-R0-core-boundary-20261105.md','audit/GeoGenesis-ridge-true-ab-20261105.md']
changed=[p for p,v in b['files'].items() if not (root/p).is_file() or sha(root/p)!=v]
assert set(changed)<=set(allowed),changed
assert sha(root/'.git/index')==b['index']
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==b['head']
v=json.loads((out/'current-main-verification.json').read_text());mdk=root/'forge-1.20.1-47.4.10-mdk';current=out.parent/'ridge-ab-small-20261105'
assert all(sha(mdk/p)==h for p,h in v['sources'].items());assert all(sha(current/p)==h for p,h in v['classes'].items())
result={'pass':True,'startingFileCount':len(b['files']),'onlyChangedStartingFiles':changed,'srcMainRunConfigStartingTrackedAndUntrackedUnchanged':True,'existingVersionableBaselineAttachmentsUnchanged':True,'currentMainSourceAndClassHashesRechecked':True,'HEADAndIndexUnchanged':True,'head':b['head'],'indexSHA256':b['index'],'scope':'No writes outside fresh build and authorized audit files. Frozen baseline attachments hashed before; old build-only baselines neither read as main nor rewritten.'}
(out/'boundary-check.json').write_text(json.dumps(result,indent=2))
provenance={'seed':'9139912035078620160','jvmProperties':{'file.encoding':'UTF-8'},'JVMOther':['-Xmx2G'],'noGeogenesisOrHydroProperties':True,'HS':2,'noParticleNoRuneNoHydrology':True,'A':'unchanged DiagnosticRidgeKernel region raw + coverage raw before its original 1.05 terrace','B':'unchanged old operator on covered e','configSHA256':sha(out/'config-input.toml'),'sourcesAndTools':{p.name:sha(p) for p in out.iterdir() if p.suffix in ['.java','.py']},'classes':{str(p.relative_to(out)):sha(p) for d in ['classes','check-classes'] for p in (out/d).rglob('*.class')},'compileAndRunCommands':'*-command.json; strict javac release17 -Xlint:all -Werror; main reuse has all212 source hash and class manifest verification','controlAndB':'same current production MorphLandField and MorphOceanAssembler stages as previous true A run; no production change','light':[-.5,-.35,1],'normal':'(-gx,-gz,1)','horizontalDistanceBlocks':'stepWu*HS','colorScaleY':[-64,320],'rawFormat':'f64 big endian, row z then x; pre-* are e, assembled are MC Y'}
(out/'provenance.json').write_text(json.dumps(provenance,indent=2))
attachment=root/'audit/attachments/ridge-a-coverage-20261105';attachment.mkdir(exist_ok=True)
for name in ['mountains','badlands','coverage','coast','coverage-full']:
 target=attachment/name;target.mkdir(exist_ok=True)
 for file in ['comparison.png','pre-coast-comparison.png','profiles-detail.png','profiles.csv','metrics.json','window.json','coverage-evidence.png']:shutil.copy2(out/name/file,target/file)
for name in ['provenance.json','boundary-check.json','current-main-verification.json','selection.csv','checks.txt','coverage-checks.txt','summary-metrics.json']:shutil.copy2(out/name,attachment/name)
with zipfile.ZipFile(attachment/'sources-tools-commands.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.suffix in ['.java','.py','.toml','.log'] or p.name.endswith('-command.json') or p.name=='classpath.txt':z.write(p,p.name)
manifest={str(p.relative_to(attachment)):sha(p) for p in attachment.rglob('*') if p.is_file() and p.name!='SHA256SUMS.json'}
(attachment/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(result,indent=2));print('attachment bytes',sum(p.stat().st_size for p in attachment.rglob('*') if p.is_file()))
