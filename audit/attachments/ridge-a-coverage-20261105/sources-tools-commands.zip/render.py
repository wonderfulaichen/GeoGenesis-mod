from pathlib import Path
import importlib.util,json,re,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path(__file__).resolve().parent;root=out.parents[2]
s=importlib.util.spec_from_file_location('r',root/'forge-1.20.1-47.4.10-mdk/tools/render-ridge-placement.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
r.LABELS=['Control','A: raw both layers','B: post covered e']
cfg=(out/'config-input.toml').read_text();value=lambda key:float(re.search(r'^\s*'+key+r'\s*=\s*([0-9.]+)',cfg,re.M).group(1))
summary={}
for folder in sorted(out.iterdir()):
 if not (folder/'window.json').exists() or not (folder/'weights.csv').exists():continue
 arr,_=r.render(folder);w=json.loads((folder/'window.json').read_text());n=w['size'];step=w['stepWu'];ox,oz=w['originWu']
 read=lambda name:np.fromfile(folder/(name+'.f64be'),dtype='>f8').reshape(n,n)
 pre=[read('pre-'+a) for a in r.NAMES]
 mapped=[63+np.clip(e*value('verticalScale'),0,1)*257*value('peakHeightFraction') for e in pre]
 rows=[n//4,n//2,3*n//4]
 # Same native sample window; no smoothing, pixel enlargement, per-arm autoscale or relighting.
 r.palette.panel([r.palette.shade(h) for h in mapped],['Pre-coast control','Pre-coast A: both raw layers','Pre-coast B'],folder/'pre-coast-comparison.png')
 fig,axes=plt.subplots(3,2,figsize=(12,8),constrained_layout=True)
 for axesrow,row in zip(axes,rows):
  for stage,arrays,ax in zip(['Assembled','Pre-coast mapped for display'],[arr,mapped],axesrow):
   for h,c,label in zip(arrays,['black','red','blue'],r.LABELS):ax.plot(ox+np.arange(n)*step,h[row],color=c,label=label,lw=.9)
   ax.set_title('%s row%d z=%.1f wu'%(stage,row,oz+row*step));ax.set_xlabel('world x (wu); HS=2');ax.set_ylabel('MC Y');ax.grid(alpha=.25);ax.legend(fontsize=7)
 fig.savefig(folder/'profiles-detail.png',dpi=130);plt.close(fig)
 np.savetxt(folder/'profiles.csv',np.array([[row,ox+i*step,oz+row*step,*[h[row,i] for h in arr],*[h[row,i] for h in pre]] for row in rows for i in range(n)]),delimiter=',',header='row,xWu,zWu,controlY,AY,BY,preControlE,preAE,preBE',comments='')
 alpha=read('alpha');edge=read('edge');weights=np.genfromtxt(folder/'weights.csv',delimiter=',',names=True)
 stats=json.loads((folder/'metrics.json').read_text())
 stats['purity']={'allPixels':n*n,'dominantCounts':{str(int(k)):int((weights['dominant']==k).sum()) for k in np.unique(weights['dominant'])},'singleActiveFraction':float((weights['active']==1).mean()),'minimumWeightPerEntry':{str(k):float(weights['w%d'%k].min()) for k in range(18)},'alphaMin':float(alpha.min()),'alphaMax':float(alpha.max()),'alphaZeroFraction':float((alpha==0).mean()),'alphaOneFraction':float((alpha==1).mean()),'alphaTransitionFraction':float(((alpha>0)&(alpha<1)).mean()),'edgeRange':[float(edge.min()),float(edge.max())]}
 stats['shape']={}
 for label,h in zip(r.LABELS,arr):
  gz,gx=np.gradient(h,step*2);grad=np.hypot(gx,gz);jump=np.concatenate([np.abs(np.diff(h,axis=0)).ravel(),np.abs(np.diff(h,axis=1)).ravel()])
  stats['shape'][label]={'nonfinite':int((~np.isfinite(h)).sum()),'reliefY':float(h.max()-h.min()),'slopeP50P99Max':np.quantile(grad,[.5,.99,1]).tolist(),'adjacentJumpP99MaxY':np.quantile(jump,[.99,1]).tolist(),'landFraction':float((h>=63).mean())}
 missing=read('region-only-A');full=pre[1];coverOld=read('coverage-control');coverA=read('coverage-A')
 stats['coverageNegativeControl']={'description':'region-only A is prior wiring with unfiltered coverage; not the retained candidate at active alpha','maxAbsFullMinusMissingE':float(np.abs(full-missing).max()),'alpha1MissingEqualsControl':bool(np.array_equal(missing[alpha==1],pre[0][alpha==1])) if np.any(alpha==1) else None,'alpha1FullChangedPixels':int((full[alpha==1]!=pre[0][alpha==1]).sum()),'coverageChangedPixels':int((coverA!=coverOld).sum()),'alpha0FullEqualsMissing':bool(np.array_equal(full[alpha==0],missing[alpha==0])) if np.any(alpha==0) else None}
 fig,axes=plt.subplots(1,3,figsize=(11,3.5),constrained_layout=True)
 for ax,h,title in zip(axes,[alpha,edge,(full-missing)],["Actual coverage alpha","Actual continent edge","Full A - region-only A (e)"]):
  im=ax.imshow(h,origin='upper');ax.set_title(title);fig.colorbar(im,ax=ax,shrink=.7)
 fig.savefig(folder/'coverage-evidence.png',dpi=120);plt.close(fig)
 stats['rawSHA256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.f64be')}
 (folder/'metrics.json').write_text(json.dumps(stats,indent=2));summary[folder.name]=stats
(out/'summary-metrics.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:{'purity':v['purity'],'coverageNegativeControl':v['coverageNegativeControl']} for k,v in summary.items()},indent=2))
