from pathlib import Path
import subprocess,json,sys
out=Path(__file__).resolve().parent
cp=(out/'classpath.txt').read_text()
def run(name,cmd):
 (out/(name+'-command.json')).write_text(json.dumps(cmd,indent=2))
 with (out/(name+'.log')).open('wb') as f:p=subprocess.run(cmd,cwd=out,stdout=f,stderr=subprocess.STDOUT)
 print(name,p.returncode,flush=True);p.check_returncode()
if sys.argv[1]=='compile':
 run('compile',['javac','--release','17','-encoding','UTF-8','-proc:none','-Xlint:all','-Werror','-cp',cp,'-d',str(out/'classes'),str(out/'DiagnosticRidgeKernel.java'),str(out/'CoverageProbe.java')])
else:
 run(sys.argv[1],['java','-Dfile.encoding=UTF-8','-Xmx2G','-cp',str(out/'classes')+';'+cp,'com.geogenesis.worldgen.terrain.morph.CoverageProbe',str(out/'config-input.toml'),str(out)]+sys.argv[1:])
