from pathlib import Path
import json,hashlib,shutil,subprocess
out=Path(__file__).resolve().parent;root=out.parents[2];mdk=root/'forge-1.20.1-47.4.10-mdk';old=out.parent/'ridge-ab-true-20261105';current=out.parent/'ridge-ab-small-20261105'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((current/'source-hashes.json').read_text());c=json.loads((current/'class-hashes.json').read_text())
assert all(sha(mdk/p)==v for p,v in m.items())
assert all(sha(current/p)==v for p,v in c.items())
cp=str(current/'main-classes')+';'+(out.parent/'r0b-20261105/compile-classpath.txt').read_text().strip()
cp=';'.join(p for p in cp.split(';') if 'build/classes/java/main' not in p.replace('\\','/'))
(out/'classpath.txt').write_text(cp)
(out/'current-main-verification.json').write_text(json.dumps({'sources':m,'classes':c,'allHashesMatch':True,'mainClassRoot':str(current/'main-classes'),'noOldBuildMainFallback':True},indent=2))
shutil.copy2(old/'DiagnosticRidgeKernel.java',out/'DiagnosticRidgeKernel.java');shutil.copy2(old/'config-input.toml',out/'config-input.toml')
s=(old/'TrueRidgeProbe.java').read_text().replace('TrueRidgeProbe','CoverageProbe')
s=s.replace('final HeightCurve curve;','final HeightCurve curve;\n    final CoverageRaw coverage = new CoverageRaw();\n    ContinentField continent;')
s=s.replace('ContinentField continent = new ContinentField(p); continent.seed(SEED);','continent = new ContinentField(p); continent.seed(SEED);')
s=s.replace('double ae=toE(land.overlay(a.sampleLand(x,z,s.weight()),s.mask(),covered));','double ae=toE(land.overlay(a.sampleLand(x,z,s.weight()),s.mask(),s.alpha()==0?Double.NaN:coverage.height(x,z)));')
start=s.index('    void render(')
s=s[:start]+'''    // Coverage is a distinct 1.05 terrace graph, not region entry15 (0.9).
    final class CoverageRaw {
        final MorphNoise.Node raw, surface, amp, originalNode;
        final MorphNoise.Terrace terrace;
        final MorphNoise.Node filtered;
        long calls;
        CoverageRaw() {
            PlateauRecipe p=new PlateauRecipe(PlateauRecipe.Variant.REF);
            p.seed(SEED+MorphCatalog.OFF_PLATEAU);
            originalNode=p.heightNode();raw=p.baseNode();
            var mul=(MorphNoise.Mul)originalNode;var add=(MorphNoise.Add)mul.a();
            terrace=(MorphNoise.Terrace)add.a();surface=add.b();amp=mul.b();
            MorphNoise.Node input=new MorphNoise.DualNode((u,v)->(float)alter(u,v),(u,v)->alter(u,v));
            var t=new MorphNoise.Terrace(input,terrace.ramp(),terrace.cliff(),terrace.rampHeight(),
                    terrace.blendRange(),terrace.steps(),terrace.inMin(),terrace.inMax(),terrace.indexBySpacing());
            filtered=new MorphNoise.Mul(new MorphNoise.Add(t,surface),amp);
        }
        double shell(double x,double z){return toE(MorphNoiseEval.eval(raw,x,z)*.475f);}
        double alter(double x,double z){
            calls++;
            double r=MorphNoiseEval.eval(raw,x,z);
            return !cfg.enabled || cfg.strength==0?r:r+delta(this::shell,x,z)/(MorphScale.E_SPAN*.475f);
        }
        double height(double x,double z){return MorphNoiseEval.eval(filtered,x,z);}
    }
    void select(Path out)throws Exception {
        var assembly=MorphAssembly.of(SEED);
        StringBuilder csv=new StringBuilder("x,z,approxType,alpha,edge,realType,active,realAlpha\\n");
        int[] counts=new int[4];
        for(int z=-4096;z<=4096;z+=256)for(int x=-4096;x<=4096;x+=256){
            double mask=land.mask(x,z),alpha=land.alphaOf(mask),edge=(continent.sample(x,z)+1)*.5;
            int slot=Math.min(44,(int)(assembly.partition().sample(x,z).regionId()*45));
            int type=assembly.slotEntry(slot);
            boolean mountain=type==17 && alpha==0 && edge>.64 && counts[0]<12;
            boolean bad=type==16 && alpha==0 && edge>.64 && counts[1]<12;
            boolean cover=alpha>.2 && alpha<.8 && edge>.64 && counts[2]<20;
            boolean coast=Math.abs(edge-.4437086)<.035 && counts[3]<20;
            if(!mountain&&!bad&&!cover&&!coast)continue;
            var s=land.sample(x,z);
            csv.append(String.format(Locale.ROOT,"%d,%d,%d,%.9f,%.9f,%d,%d,%.9f%n",x,z,type,alpha,edge,s.dominantEntry(),s.activeEntries(),s.alpha()));
            if(mountain)counts[0]++;if(bad)counts[1]++;if(cover)counts[2]++;if(coast)counts[3]++;
        }
        Files.writeString(out.resolve("selection.csv"),csv);System.out.println(Arrays.toString(counts));
    }
    void render(Path out,String name,int n,double step,double ox,double oz)throws Exception {
        Path dir=out.resolve(name);Files.createDirectories(dir);
        String[] names={"control","recipe","post","pre-control","pre-recipe","pre-post","alpha","edge","region-only-A","coverage-control","coverage-A"};
        DataOutputStream[] streams=new DataOutputStream[names.length];
        StringBuilder weights=new StringBuilder("x,z,alpha,active,dominant");
        for(int id=0;id<18;id++)weights.append(",w"+id);weights.append('\\n');
        try {
            for(int k=0;k<names.length;k++)streams[k]=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(dir.resolve(names[k]+".f64be"),StandardOpenOption.CREATE_NEW)));
            for(int j=0;j<n;j++)for(int i=0;i<n;i++) {
                double x=ox+i*step,z=oz+j*step;double[] v=values(x,z);var s=land.sample(x,z);
                for(int k=0;k<3;k++){streams[k+3].writeDouble(v[k]);double y=curve.heightFromE(ocean[k].e(x,z));require(Double.isFinite(y),"finite");streams[k].writeDouble(y);}
                streams[6].writeDouble(s.alpha());streams[7].writeDouble((continent.sample(x,z)+1)*.5);
                double old=s.alpha()==0?Double.NaN:land.oldCoverageHeight(x,z);
                streams[8].writeDouble(toE(land.overlay(a.sampleLand(x,z,s.weight()),s.mask(),old)));
                streams[9].writeDouble(land.oldCoverageHeight(x,z));streams[10].writeDouble(coverage.height(x,z));
                weights.append(String.format(Locale.ROOT,"%.4f,%.4f,%.10f,%d,%d",x,z,s.alpha(),s.activeEntries(),s.dominantEntry()));
                for(double w:s.weight())weights.append(',').append(w);weights.append('\\n');
            }
        }finally{for(var stream:streams)if(stream!=null)stream.close();}
        Files.writeString(dir.resolve("weights.csv"),weights);
        Files.writeString(dir.resolve("window.json"),String.format(Locale.ROOT,"{\\"size\\":%d,\\"stepWu\\":%f,\\"originWu\\":[%f,%f],\\"hs\\":2}",n,step,ox,oz));
        System.out.println(name+" rendered; coverage raw calls="+coverage.calls);
    }
    public static void main(String[] args)throws Exception {
        Path out=Path.of(args[1]);
        try(var f=CommentedFileConfig.of(Path.of(args[0]),TomlFormat.instance())) {
            f.load();require(GeoGenesisConfig.SPEC.isCorrect(f),"config");GeoGenesisConfig.SPEC.setConfig(f);
            var params=GeoGenesisConfig.INSTANCE.buildParams();var c=RidgeConfigAdapter.fromConfig(GeoGenesisConfig.INSTANCE);c.horizontalScale=(float)params.horizontalScale();
            var probe=new CoverageProbe(params,c);
            if(args[2].equals("select"))probe.select(out);
            else if(args[2].equals("checks"))probe.checks(out);
            else probe.render(out,args[2],Integer.parseInt(args[3]),Double.parseDouble(args[4]),Double.parseDouble(args[5]),Double.parseDouble(args[6]));
        }
    }
}
'''
(out/'CoverageProbe.java').write_text(s)
print('setup verified current main hashes; prepared isolated source')
