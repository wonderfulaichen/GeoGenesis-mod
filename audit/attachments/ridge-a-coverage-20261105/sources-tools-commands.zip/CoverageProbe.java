package com.geogenesis.worldgen.terrain.morph;

import com.electronwill.nightconfig.core.file.CommentedFileConfig;
import com.electronwill.nightconfig.toml.TomlFormat;
import com.geogenesis.config.*;
import com.geogenesis.worldgen.erosion.RidgeValleyErosion;
import com.geogenesis.worldgen.terrain.*;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.function.DoubleBinaryOperator;

public final class CoverageProbe {
    static final long SEED = 9139912035078620160L;
    final MorphCatalog catalog = new MorphCatalog(SEED);
    final MorphLandField land = new MorphLandField(catalog, MorphAssembly.of(SEED), 1200f);
    final MorphKernel original = new MorphKernel(MorphLandRecipe.all(catalog), SEED);
    final DiagnosticRidgeKernel a = new DiagnosticRidgeKernel(MorphLandRecipe.all(catalog), SEED);
    final RidgeValleyErosion.RidgeConfig cfg;
    final HeightCurve curve;
    final CoverageRaw coverage = new CoverageRaw();
    ContinentField continent;
    final MorphOceanAssembler[] ocean = new MorphOceanAssembler[3];

    CoverageProbe(TerrainParams p, RidgeValleyErosion.RidgeConfig c) {
        cfg = c; curve = new HeightCurve(p, -64, 320);
        a.ridge(c, (x,z) -> land.weights(x,z));
        continent = new ContinentField(p); continent.seed(SEED);
        for (int k=0;k<3;k++) {
            final int arm=k;
            ocean[k] = new MorphOceanAssembler((x,z)->values(x,z)[arm],continent::sample,SEED+3)
                    .enableCoastalDetail(SEED);
        }
    }
    static double toE(double h) { return Math.max(MorphScale.GROUND_E+h*MorphScale.E_SPAN,0); }
    float delta(DoubleBinaryOperator f,double x,double z) {
        float h=(float)f.applyAsDouble(x,z), l=(float)f.applyAsDouble(x-2,z),r=(float)f.applyAsDouble(x+2,z);
        float b=(float)f.applyAsDouble(x,z-2),t=(float)f.applyAsDouble(x,z+2);
        float denominator=4f;
        if(cfg.horizontalScale>.01f && cfg.horizontalScale!=1f)denominator*=cfg.horizontalScale;
        return RidgeValleyErosion.evaluatePoint((float)x,(float)z,h,(r-l)/denominator,(t-b)/denominator,0,cfg);
    }
    double[] values(double x,double z) {
        var s=land.sample(x,z); double covered=s.alpha()==0?Double.NaN:land.oldCoverageHeight(x,z);
        double ae=toE(land.overlay(a.sampleLand(x,z,s.weight()),s.mask(),s.alpha()==0?Double.NaN:coverage.height(x,z)));
        return new double[]{s.e(),ae,s.e()+delta(land::e,x,z)};
    }
    static void require(boolean yes,String msg) {if(!yes)throw new AssertionError(msg);}
    void checks(Path out) throws Exception {
        StringBuilder report=new StringBuilder();
        double x=-2687.5,z=3328.5; double[] w=land.weights(x,z);
        float strength=cfg.strength;cfg.strength=0;
        for(int id=0;id<18;id++) {
            double[] one=new double[18];one[id]=1;
            require(Double.doubleToRawLongBits(original.sampleLand(x,z,one))==Double.doubleToRawLongBits(a.sampleLand(x,z,one)),"zero-original "+id);
        }
        require(Double.doubleToRawLongBits(original.sampleLand(x,z,w))==Double.doubleToRawLongBits(a.sampleLand(x,z,w)),"zero mixed");
        cfg.strength=strength;report.append("zero-strength all18 and mixed original bitwise PASS\n");
        a.ridge(cfg,null);
        for(int id=0;id<18;id++) {
            double[] one=new double[18];one[id]=1;
            MorphRecipe[] recipes=MorphLandRecipe.all(catalog);
            final MorphRecipe base=recipes[id];final double[] endpoint=one;
            // Independent per-recipe raw-node wrapper, evaluated in WORLD coordinates.
            // Constant endpoint weights ensure no neighbouring weight interpolation in this check.
            final DiagnosticRidgeKernel reference=new DiagnosticRidgeKernel(MorphLandRecipe.all(catalog),SEED);
            reference.ridge(cfg,null);
            recipes[id]=new MorphRecipe(){
                public double raw(double u,double v){return base.raw(u,v)+reference.rawDelta(u,v,endpoint)/(MorphScale.E_SPAN*base.amplitude(u,v));}
                public double amplitude(double u,double v){return base.amplitude(u,v);}
                public double bias(double u,double v){return base.bias(u,v);}
                public Role role(){return base.role();}
                public boolean clamped(){return base.clamped();}
            };
            // Non-mountain recipes: independent node wrapper matches exactly (no domain relocation).
            if(base.role()!=MorphRecipe.Role.MOUNTAIN) {
                double expected=new MorphKernel(recipes,SEED).sampleLand(x,z,one);
                require(Math.abs(expected-a.sampleLand(x,z,one))<1e-12,"node endpoint "+id);
            }
            float d=delta((u,v)->a.rawShell(u,v,endpoint),x,z);
            require(Float.floatToRawIntBits(d)==Float.floatToRawIntBits(a.rawDelta(x,z,one)),"raw difference "+id);
            double direct=a.sampleLand(x,z,one);
            a.sampleLand(x+20,z-40,w);
            require(Double.doubleToRawLongBits(direct)==Double.doubleToRawLongBits(a.sampleLand(x,z,one)),"repeat "+id);
        }
        report.append("raw-node endpoints non-mountain independent wrapper PASS; all18 raw finite-difference bitwise PASS; repeat/order PASS\n");
        double[] one=new double[18];one[17]=1;
        double end=a.sampleLand(x,z,one);
        var directionField=MorphKernel.class.getDeclaredField("direction");directionField.setAccessible(true);
        var erosionField=MorphKernel.class.getDeclaredField("erosion");erosionField.setAccessible(true);
        double angle=MorphNoiseEval.eval((MorphNoise.Node)directionField.get(original),x,z)*6.2831855f;
        double u=x+Math.sin(angle)*2,v=z+Math.cos(angle)*2;
        MorphRecipe mountain=MorphLandRecipe.all(catalog)[17];
        double raw=mountain.raw(u,v)+a.rawDelta(x,z,one)/(MorphScale.E_SPAN*mountain.amplitude(u,v));
        double texture=MorphNoiseEval.eval((MorphNoise.Node)erosionField.get(original),u,v);
        double expected=(texture+(raw-texture)*(1-.65))*mountain.amplitude(u,v)+mountain.bias(u,v);
        require(Math.abs(expected-end)<1e-12,"mountain one-domain independent endpoint");
        report.append("mountain endpoint independent one-domain + unchanged texture + shell formula PASS\n");
        double prev=Double.POSITIVE_INFINITY;
        for(double eps:new double[]{1e-3,1e-5,1e-7,1e-9}) {
            double[] q=one.clone();q[17]=1-eps;q[15]=eps;
            double error=Math.abs(a.sampleLand(x,z,q)-end);
            require(error<prev,"endpoint retreat convergence");prev=error;
        }
        require(prev<1e-6,"endpoint retreat residual");
        report.append("mountain endpoint retreat 15->17 eps=1e-3..1e-9 convergence PASS (world-coordinate raw node)\n");
        a.ridge(cfg,(wx,wz)->land.weights(wx,wz));
        double[] before=values(x,z);values(x+33,z+44);
        require(Arrays.equals(before,values(x,z)),"world query order");
        report.append("real-weight query order PASS\n");Files.writeString(out.resolve("checks.txt"),report);
    }
    // Coverage is a distinct 1.05 terrace graph, not region entry15 (0.9).
    final class CoverageRaw {
        final MorphNoise.Node raw, surface, amp, originalNode;
        final MorphNoise.Terrace terrace;
        final MorphNoise.Node filtered;
        long calls;
        CoverageRaw() {
            PlateauRecipe p=new PlateauRecipe(PlateauRecipe.Variant.REF);
            p.seed(SEED+MorphCatalog.OFF_PLATEAU);
            originalNode=p.heightNode();raw=p.baseNode();
            var mul=(MorphNoise.Mul)originalNode;var add=(MorphNoise.Add)mul.a();
            terrace=(MorphNoise.Terrace)add.a();surface=add.b();amp=mul.b();
            MorphNoise.Node input=new MorphNoise.DualNode((u,v)->(float)alter(u,v),(u,v)->alter(u,v));
            var t=new MorphNoise.Terrace(input,terrace.ramp(),terrace.cliff(),terrace.rampHeight(),
                    terrace.blendRange(),terrace.steps(),terrace.inMin(),terrace.inMax(),terrace.indexBySpacing());
            filtered=new MorphNoise.Mul(new MorphNoise.Add(t,surface),amp);
        }
        double shell(double x,double z){return toE(MorphNoiseEval.eval(raw,x,z)*.475f);}
        double alter(double x,double z){
            calls++;
            double r=MorphNoiseEval.eval(raw,x,z);
            return !cfg.enabled || cfg.strength==0?r:r+delta(this::shell,x,z)/(MorphScale.E_SPAN*.475f);
        }
        double height(double x,double z){return MorphNoiseEval.eval(filtered,x,z);}
    }
    void select(Path out)throws Exception {
        var assembly=MorphAssembly.of(SEED);
        StringBuilder csv=new StringBuilder("x,z,approxType,alpha,edge,realType,active,realAlpha\n");
        int[] counts=new int[4];
        for(int z=-4096;z<=4096;z+=256)for(int x=-4096;x<=4096;x+=256){
            double mask=land.mask(x,z),alpha=land.alphaOf(mask),edge=(continent.sample(x,z)+1)*.5;
            int slot=Math.min(44,(int)(assembly.partition().sample(x,z).regionId()*45));
            int type=assembly.slotEntry(slot);
            boolean mountain=type==17 && alpha==0 && edge>.64 && counts[0]<12;
            boolean bad=type==16 && alpha==0 && edge>.64 && counts[1]<12;
            boolean cover=alpha>.2 && alpha<.8 && edge>.64 && counts[2]<20;
            boolean coast=Math.abs(edge-.4437086)<.035 && counts[3]<20;
            if(!mountain&&!bad&&!cover&&!coast)continue;
            var s=land.sample(x,z);
            csv.append(String.format(Locale.ROOT,"%d,%d,%d,%.9f,%.9f,%d,%d,%.9f%n",x,z,type,alpha,edge,s.dominantEntry(),s.activeEntries(),s.alpha()));
            if(mountain)counts[0]++;if(bad)counts[1]++;if(cover)counts[2]++;if(coast)counts[3]++;
        }
        Files.writeString(out.resolve("selection.csv"),csv);System.out.println(Arrays.toString(counts));
    }
    void render(Path out,String name,int n,double step,double ox,double oz)throws Exception {
        Path dir=out.resolve(name);Files.createDirectories(dir);
        String[] names={"control","recipe","post","pre-control","pre-recipe","pre-post","alpha","edge","region-only-A","coverage-control","coverage-A"};
        DataOutputStream[] streams=new DataOutputStream[names.length];
        StringBuilder weights=new StringBuilder("x,z,alpha,active,dominant");
        for(int id=0;id<18;id++)weights.append(",w"+id);weights.append('\n');
        try {
            for(int k=0;k<names.length;k++)streams[k]=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(dir.resolve(names[k]+".f64be"),StandardOpenOption.CREATE_NEW)));
            for(int j=0;j<n;j++)for(int i=0;i<n;i++) {
                double x=ox+i*step,z=oz+j*step;double[] v=values(x,z);var s=land.sample(x,z);
                for(int k=0;k<3;k++){streams[k+3].writeDouble(v[k]);double y=curve.heightFromE(ocean[k].e(x,z));require(Double.isFinite(y),"finite");streams[k].writeDouble(y);}
                streams[6].writeDouble(s.alpha());streams[7].writeDouble((continent.sample(x,z)+1)*.5);
                double old=s.alpha()==0?Double.NaN:land.oldCoverageHeight(x,z);
                streams[8].writeDouble(toE(land.overlay(a.sampleLand(x,z,s.weight()),s.mask(),old)));
                streams[9].writeDouble(land.oldCoverageHeight(x,z));streams[10].writeDouble(coverage.height(x,z));
                weights.append(String.format(Locale.ROOT,"%.4f,%.4f,%.10f,%d,%d",x,z,s.alpha(),s.activeEntries(),s.dominantEntry()));
                for(double w:s.weight())weights.append(',').append(w);weights.append('\n');
            }
        }finally{for(var stream:streams)if(stream!=null)stream.close();}
        Files.writeString(dir.resolve("weights.csv"),weights);
        Files.writeString(dir.resolve("window.json"),String.format(Locale.ROOT,"{\"size\":%d,\"stepWu\":%f,\"originWu\":[%f,%f],\"hs\":2}",n,step,ox,oz));
        System.out.println(name+" rendered; coverage raw calls="+coverage.calls);
    }
    public static void main(String[] args)throws Exception {
        Path out=Path.of(args[1]);
        try(var f=CommentedFileConfig.of(Path.of(args[0]),TomlFormat.instance())) {
            f.load();require(GeoGenesisConfig.SPEC.isCorrect(f),"config");GeoGenesisConfig.SPEC.setConfig(f);
            var params=GeoGenesisConfig.INSTANCE.buildParams();var c=RidgeConfigAdapter.fromConfig(GeoGenesisConfig.INSTANCE);c.horizontalScale=(float)params.horizontalScale();
            var probe=new CoverageProbe(params,c);
            if(args[2].equals("select"))probe.select(out);
            else if(args[2].equals("checks"))probe.checks(out);
            else probe.render(out,args[2],Integer.parseInt(args[3]),Double.parseDouble(args[4]),Double.parseDouble(args[5]),Double.parseDouble(args[6]));
        }
    }
}
