import com.geogenesis.worldgen.erosion.RidgeValleyErosion;
import java.nio.file.*;
import java.nio.*;
import java.util.*;
public final class RidgeCoreCheck {
    public static void main(String[] args) throws Exception {
        Path input = Path.of(args[0]);
        float[][] g = new float[121][121];
        ByteBuffer b = ByteBuffer.wrap(Files.readAllBytes(input)).order(ByteOrder.BIG_ENDIAN);
        for (float[] row : g) for (int x = 0; x < row.length; x++) row[x] = b.getFloat();
        var c = new RidgeValleyErosion.RidgeConfig();
        c.rounding[0] = .11f; c.gullyWeight = .65f; c.horizontalScale = 1;
        float[][] delta = RidgeValleyErosion.computeCoarseDelta(g,121,2,-1016,3784,0,c);
        b = ByteBuffer.allocate(121*121*4).order(ByteOrder.BIG_ENDIAN);
        for (float[] row : delta) for (float f : row) b.putInt(Float.floatToRawIntBits(f));
        if (!Arrays.equals(b.array(),Files.readAllBytes(Path.of(args[1])))) throw new AssertionError("delta drift");
        c.strength = 0;
        for (float[] row : RidgeValleyErosion.computeCoarseDelta(g,121,2,-1016,3784,0,c))
            for (float f : row) if (f != 0) throw new AssertionError("negative control");
        System.out.println("RIDGE CORE PASS: no Forge/MC jars; real baseline input/delta byte equal; zero-strength control");
    }
}
