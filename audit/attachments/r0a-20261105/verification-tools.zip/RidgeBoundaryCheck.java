import com.geogenesis.config.GeoGenesisConfig;
import com.geogenesis.config.RidgeConfigAdapter;
import com.geogenesis.worldgen.erosion.RidgeValleyErosion.RidgeConfig;
import com.electronwill.nightconfig.core.file.CommentedFileConfig;
import com.electronwill.nightconfig.toml.TomlFormat;
import java.nio.file.Path;
import java.lang.reflect.Method;
import java.util.Arrays;

public final class RidgeBoundaryCheck {
    static void check(boolean ok) { if (!ok) throw new AssertionError(); }
    static void values(RidgeConfig c, float gully, float round, float hs) {
        check(c.gullyWeight == gully && c.rounding[0] == round && c.rounding[1] == .12f && c.horizontalScale == hs);
    }
    public static void main(String[] args) throws Exception {
        check(!GeoGenesisConfig.SPEC.isLoaded());
        values(new RidgeConfig(), .7f, .1f, 1f);
        values(RidgeConfigAdapter.fromConfig(null), .7f, .1f, 1f);
        values(RidgeConfigAdapter.fromConfig(GeoGenesisConfig.INSTANCE), .7f, .11f, 1f);
        for (String name : new String[]{"cfgBool", "cfgDbl", "cfgInt"}) {
            Method m = Arrays.stream(RidgeConfigAdapter.class.getDeclaredMethods()).filter(x -> x.getName().equals(name)).findFirst().orElseThrow();
            m.setAccessible(true);
            Object fallback;
            if (name.equals("cfgBool")) fallback = Boolean.TRUE;
            else if (name.equals("cfgDbl")) fallback = Double.valueOf(7.25);
            else fallback = Integer.valueOf(7);
            Object v = m.invoke(null, null, fallback);
            check(v.equals(name.equals("cfgBool") ? Boolean.FALSE : fallback));
        }
        try (var cfg = CommentedFileConfig.of(Path.of(args[0]), TomlFormat.instance())) {
            cfg.load(); GeoGenesisConfig.SPEC.setConfig(cfg);
            RidgeConfig a = RidgeConfigAdapter.fromConfig(GeoGenesisConfig.INSTANCE);
            RidgeConfig b = RidgeConfigAdapter.fromConfig(GeoGenesisConfig.INSTANCE);
            values(a, .65f, .11f, 2f);
            check(a.rounding != b.rounding && a.onset != b.onset && a.assumedSlope != b.assumedSlope);
            a.rounding[0] = 99; check(b.rounding[0] == .11f);
            boolean saved = GeoGenesisConfig.INSTANCE.erosionRidgeEnabled.get();
            GeoGenesisConfig.INSTANCE.erosionRidgeEnabled.set(false);
            check(!RidgeConfigAdapter.fromConfig(GeoGenesisConfig.INSTANCE).enabled);
            GeoGenesisConfig.INSTANCE.erosionRidgeEnabled.set(saved);
        }
        System.out.println("RIDGE BOUNDARY PASS: direct/null/unloaded/loaded; null helpers; fresh arrays; enabled negative control");
    }
}
