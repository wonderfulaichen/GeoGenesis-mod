from pathlib import Path
import json,subprocess
r=Path.cwd();o=r/'build/r0b-20261105';a=r/'build/r0a-20261105';old=r/'build/r0-0-20261105'
def run(n,cmd):
 (o/(n+'-command.json')).write_text(json.dumps(cmd,indent=2),encoding='utf-8')
 with (o/(n+'.log')).open('w',encoding='utf-8') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 (o/(n+'-exit.json')).write_text(json.dumps({'exitCode':p.returncode}),encoding='utf-8');print(n,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
cp=str(o/'main-classes')+';'+(o/'compile-classpath.txt').read_text().strip()
opts=['javac','--release','17','-encoding','UTF-8','-proc:none','-Xlint:all','-Werror']
run('trusted-compile',opts+['-cp',cp,'-d',str(o/'probe-classes')]+[str(r/'src/diagnostics/java/com/geogenesis/worldgen/erosion'/n) for n in ['ErosionScratchProbe.java','GuideErosionBench.java']])
run('boundary-compile',opts+['-cp',cp,'-d',str(o/'probe-classes'),str(o/'ParticleBoundaryCheck.java'),str(o/'ConfigBoundaryCheck.java')])
cmd=json.loads((a/'config-check-final-command.json').read_text());cmd=[s.replace('r0a-20261105','r0b-20261105') for s in cmd]
run('config-check',cmd)
assert (o/'config-boundary.txt').read_bytes()==(old/'config-boundary.txt').read_bytes()
runtime=cmd[cmd.index('-cp')+1]
run('boundary',['java','-Dfile.encoding=UTF-8','-cp',runtime,'ParticleBoundaryCheck',str(old/'configs/input-user.toml'),str(old/'loaded-final/hs2_-960_3840-particle-input.f32be')])
run('particle-core-compile',opts+['-cp',str(o/'core-classes'),'-d',str(o/'core-classes'),str(o/'ParticleCoreCheck.java')])
run('particle-core',['java','-Dfile.encoding=UTF-8','-cp',str(o/'core-classes'),'ParticleCoreCheck',str(old)])
print('ALL TARGETED CHECKS PASS',flush=True)
