package com.geogenesis.worldgen.erosion;
import com.geogenesis.config.GeoGenesisConfig;
import com.electronwill.nightconfig.core.file.CommentedFileConfig;
import com.electronwill.nightconfig.toml.TomlFormat;
import java.nio.file.*;
import java.nio.*;
import java.util.*;
public class ReflectiveCallerCheck {
 public static void main(String[] args)throws Exception{
  try(var cfg=CommentedFileConfig.of(Path.of(args[0]),TomlFormat.instance())){
   cfg.load();GeoGenesisConfig.SPEC.setConfig(cfg);
   var scratch=ErosionScratchProbe.EngineRef.load(Path.of(args[1]));
   var guide=new GuideErosionBench.Engine(Path.of(args[1]),ErosionScratchProbe.ENGINE_CLASS);
   var bytes=ByteBuffer.wrap(Files.readAllBytes(Path.of(args[2])));float[] input=new float[bytes.remaining()/4];for(int i=0;i<input.length;i++)input[i]=bytes.getFloat();
   float[] a=input.clone(),b=input.clone();float[] da=new float[a.length],db=new float[a.length];
   scratch.pub10.invoke(scratch.newEngine(false),a,input.clone(),146,128,-1000,3800,0f,1f,da,2f);
   guide.run.invoke(guide.instance(),b,input.clone(),146,128,-1000,3800,0f,1f,db,2f);
   if(!Arrays.equals(a,b)||!Arrays.equals(da,db))throw new AssertionError("reflective adapters disagree");
   byte[] expected=Files.readAllBytes(Path.of(args[3]));ByteBuffer actual=ByteBuffer.allocate(a.length*4);for(float f:a)actual.putInt(Float.floatToRawIntBits(f));
   if(!Arrays.equals(expected,actual.array()))throw new AssertionError("loaded behavior fell back");
   System.out.println("REFLECTIVE CALLERS PASS loaded baseline; public8/9/10 private11 resolved");
  }
 }
}
