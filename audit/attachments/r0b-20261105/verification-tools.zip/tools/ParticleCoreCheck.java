import com.geogenesis.worldgen.erosion.*;
import java.nio.file.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
public class ParticleCoreCheck {
 static void require(boolean b,String s){if(!b)throw new AssertionError(s);}
 static float[] read(Path p)throws Exception{var b=ByteBuffer.wrap(Files.readAllBytes(p));float[] a=new float[b.remaining()/4];for(int i=0;i<a.length;i++)a[i]=Float.intBitsToFloat(b.getInt());return a;}
 static float[][] run(ErosionEngine e,float[] input,int ox,int oz,float hs){float[] a=input.clone(),d=new float[a.length];e.runErosionOnFlat(a,input.clone(),146,128,ox,oz,0f,1f,d,hs);return new float[][]{a,d};}
 public static void main(String[] args)throws Exception{
  Path base=Path.of(args[0]);int cases=0;
  for(String arm:new String[]{"loaded-final","fallback-final"})for(int hs:new int[]{1,2})for(int[] tile:new int[][]{{-960,3840},{960,4320}}){
   String id="hs"+hs+"_"+tile[0]+"_"+tile[1]+"-particle-";Path dir=base.resolve(arm);
   float[] input=read(dir.resolve(id+"input.f32be"));
   var p=new ParticleErosionParams(1,1,arm.equals("loaded-final")?.5:.8,1,2,.1);
   var e=new ErosionEngine(false,()->p,8);var out=run(e,input,tile[0]-40,tile[1]-40,hs);
   require(Arrays.equals(out[0],read(dir.resolve(id+"hardnessfalse-flat.f32be"))),"flat "+id+arm);
   require(Arrays.equals(out[1],read(dir.resolve(id+"hardnessfalse-discharge.f32be"))),"dis "+id+arm);cases++;
  }
  Path dir=base.resolve("fallback-final");float[] input=read(dir.resolve("hs2_-960_3840-particle-input.f32be"));
  AtomicInteger reads=new AtomicInteger();AtomicReference<ParticleErosionParams> ref=new AtomicReference<>(ParticleErosionParams.unloadedDefaults());
  var e=new ErosionEngine(false,()->{reads.incrementAndGet();return ref.get();},8);
  e.runErosionOnFlat(input.clone(),input.clone(),146,128,-1000,3800,0,0);require(reads.get()==0,"early reads");
  var a=run(e,input,-1000,3800,2);require(reads.get()==1,"one snapshot");
  ref.set(new ParticleErosionParams(1,1,0,1,2,.1));var b=run(e,input,-1000,3800,2);require(reads.get()==2&&!Arrays.equals(a[0],b[0]),"per-run switch");
  var legacy=run(new ErosionEngine(999,42),input,-1000,3800,2);require(Arrays.equals(a[0],legacy[0]),"unused legacy inputs/fallback");
  var independent=new ErosionEngine(false,ParticleErosionParams::unloadedDefaults,8);
  var pool=Executors.newFixedThreadPool(2);
  try{var x=pool.submit(()->run(e,input,-1000,3800,2));var y=pool.submit(()->run(independent,input,-1000,3800,2));require(Arrays.equals(b[0],x.get()[0])&&Arrays.equals(a[0],y.get()[0]),"concurrent instances");}finally{pool.shutdown();}
  System.out.println("PARTICLE CORE PASS baselineCases="+cases+" early/per-run/legacy/concurrent/negative-control");
 }
}
