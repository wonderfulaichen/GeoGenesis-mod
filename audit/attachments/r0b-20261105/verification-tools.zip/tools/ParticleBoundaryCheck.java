import com.geogenesis.config.*;
import com.geogenesis.worldgen.erosion.*;
import com.geogenesis.worldgen.terrain.CellGenerator;
import com.electronwill.nightconfig.core.file.CommentedFileConfig;
import com.electronwill.nightconfig.toml.TomlFormat;
import com.electronwill.nightconfig.core.CommentedConfig;
import java.nio.file.*;
import java.nio.*;
import java.util.*;
public class ParticleBoundaryCheck {
 static void require(boolean b,String s){if(!b)throw new AssertionError(s);}
 static float[] run(ErosionEngine e,float[] input){float[] a=input.clone();e.runErosionOnFlat(a,input.clone(),146,128,-1000,3800,0,1,null,2);return a;}
 static float[] input(Path p)throws Exception{var b=ByteBuffer.wrap(Files.readAllBytes(p));float[] a=new float[b.remaining()/4];for(int i=0;i<a.length;i++)a[i]=b.getFloat();return a;}
 public static void main(String[] args)throws Exception{
  require(!GeoGenesisConfig.SPEC.isLoaded(),"fresh");
  require(ParticleErosionConfigAdapter.snapshot().equals(ParticleErosionParams.unloadedDefaults()),"unloaded six");
  GeoGenesisConfig.SPEC.setConfig(CommentedConfig.inMemory());
  require(ParticleErosionConfigAdapter.snapshot().equals(new ParticleErosionParams(1,1,.5,1,2,.1)),"spec defaults");
  try(var cfg=CommentedFileConfig.of(Path.of(args[0]),TomlFormat.instance())){
   cfg.load();GeoGenesisConfig.SPEC.setConfig(cfg);
   require(ParticleErosionConfigAdapter.snapshot().equals(new ParticleErosionParams(1,1,.5,1,2,.1)),"loaded six");
   float[] in=input(Path.of(args[1]));var e=ParticleErosionConfigAdapter.create(false,CellGenerator.TILE_PARALLELISM);
   var a=run(e,in);var c=GeoGenesisConfig.INSTANCE;
   c.erosionCascadeStrength.set(0d);var b=run(e,in);require(!Arrays.equals(a,b),"loaded same-engine per-run switch");
   c.erosionCascadeStrength.set(.5);require(Arrays.equals(a,run(e,in)),"loaded restore");
   c.erosionXSEnabled.set(false);var x=ParticleErosionConfigAdapter.createForCell(8);var before=run(x,in);
   c.erosionXSEnabled.set(true);require(Arrays.equals(before,run(x,in)),"XS must remain constructor input");
   require(!Arrays.equals(before,run(ParticleErosionConfigAdapter.createForCell(8),in)),"new XS input control");
   c.erosionXSEnabled.set(false);
  }
  System.out.println("PARTICLE BOUNDARY PASS unloaded/spec/loaded six; per-run switch/restore; XS constructor timing");
 }
}
