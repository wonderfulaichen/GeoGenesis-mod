package com.geogenesis.worldgen.terrain;

import com.geogenesis.config.GeoGenesisConfig;
import com.geogenesis.diagnostics.HydrologyMetrics;
import com.geogenesis.diagnostics.HydrologyMetrics.Cache;
import com.geogenesis.diagnostics.HydrologyMetrics.Outcome;
import com.geogenesis.worldgen.climate.ClimateRegion;
import com.geogenesis.worldgen.climate.ClimateSpline;
import com.geogenesis.worldgen.climate.Latitude;
import com.geogenesis.worldgen.climate.LatPrecipProfile;
import com.geogenesis.worldgen.climate.PrecipField;
import com.geogenesis.worldgen.climate.WhittakerType;
import com.geogenesis.worldgen.climate.WindField;
import com.geogenesis.worldgen.erosion.ErosionEngine;
import com.geogenesis.worldgen.erosion.RidgeValleyErosion;
import com.geogenesis.worldgen.noise.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.stream.IntStream;

/**
 * 单格地形装配中枢 —— 统一连续场 e(x,z)。
 *
 * 流程（v8.4 海陆类型化，2026-08-06 用户铁律："海陆就是 2 个大地形类型"）：
 *   ContinentField.sample → c ∈ [-1,1]
 *   ├─ 类型场 TerrainCharacterField：OCEAN/DEEP_OCEAN 与 5 陆地类型共同参与 Voronoi 细胞竞争，
 *   │    细胞类型概率由 c 调制（c 低→海洋细胞多，c 高→陆地细胞多；过渡带概率对半）
 *   ├─ TypeLandShape.sample → e = Σw·lo + Σw·(hi-lo)·modulated（全类型混合）：
 *   │    陆地类型 lo/hi = 类型样条区间；海洋类型 lo=hi=深度样条+seabed
 *   ├─ e 自然连续穿过 0 → 海陆边界 = Voronoi 类型竞争（400 块折线），
 *   │    与地形类型过渡（PLAIN↔MOUNTAINS）完全同构——海岸线由地形场自然决定
 *   └─ 大陆性 c 只做：细胞概率偏置 + 海洋深度样条 + 气候（湿度/温度），不直接决定海陆边界
 *
 * 气候（v3 增强模型，2026-09-10）：
 *   温度 = 纬度基值（赤道热 → 两极冷，单调递减）× 海洋性修正 − 海拔递减率 + 噪声
 *   湿度 = 大陆性距海 + 山地雨影 + 噪声
 */
public final class CellGenerator {

    /**
     * 安全并行行循环（2026-08-14 恢复并行）：ForkJoinPool.commonPool（work-stealing）——
     * 调用线程可参与执行子任务 → 不会"等自己"死锁。曾用 TILE_SAMPLER 有界池 + latch.await
     * （池被占满 + CallerRunsPolicy 自己跑 = 池饥饿死锁，27 轮）。body 不得嵌套 parallelRows。
     */
    private static void parallelRows(int size, java.util.function.IntConsumer body) {
        if (size <= 4) {
            for (int i = 0; i < size; i++) body.accept(i);
            return;
        }
        IntStream.range(0, size).parallel().forEach(body);
    }

    private final ContinentField continent;
    private final HeightCurve heightCurve;
    private final TypeLandShape typeLandShape;
    private final SeaBedDetail seaBed;
    private final OceanFeatures oceanFeatures;
    private final LandFeatures landFeatures;
    private final CoastlineField coastline;
    /**
     * ★ 2026-09-12 地质系统 Phase T1 总开关：构造骨架是否参与高程合成。
     * {@code false} → 完全不调用 TectonicField，输出<b>逐位退回</b>接入前（可回滚）。
     * 接 Forge 配置推迟到验证有效后（避免产生死配置，见体检报告 C8）。
     */
    private static final boolean TECTONIC_ENABLED = true;

    /**
     * ★ 2026-09-13 Phase T7(P0.5)：<b>海床护栏</b> —— 海床特征累计抬升与海平面的最小余量
     * （e 单位，≈3.8 块）。
     */
    private static final double SEABED_MARGIN = 0.02;
    /** 海床护栏软饱和的过渡宽度（e 单位）；见 {@link TectonicField#smoothMin}。 */
    private static final double SEABED_SOFT_SAT = 0.03;

    /** 构造骨架场（见 {@link #TECTONIC_ENABLED}）。 */
    private final TectonicField tectonic;

    /**
     * ★ 2026-09-12 地质 Phase T4 开关：地层/岩性是否计算。
     * {@code false} → 不调用 {@link StratumField}，{@code Cell} 的岩性字段保持默认。
     */
    private static final boolean STRATA_ENABLED = true;

    /** 地层场（构造环境 → 地层序列 → 出露岩性）。 */
    private final StratumField strata;

    /**
     * ★ 2026-09-12 地质 Phase T5 开关：褶皱/断层形变是否参与高程合成。
     * {@code false} → 不调用 {@link TectonicDeformation}，输出<b>逐位退回</b>（可回滚）。
     */
    private static final boolean DEFORM_ENABLED = true;

    /** 构造形变场（褶皱 / 断层）。 */
    private final TectonicDeformation deform;
    private final double continentBias;
    private final double seabedAmp;
    private final double oceanDepthFactor;
    /** 极寒阈值：温度低于此值即常年积雪（与 WhittakerType.T_TUNDRA=0.24 对齐：tempE < -0.52） */
    private static final double POLAR_SNOW_TEMP = -0.52;
    /** 海洋淡出起点（cBiased），在此以上海洋深度开始衰减到 0 */
    private final double oceanFadeStart;
    /** 陆地高度终点（cBiased），在此达到全量陆地高度 */
    private final double landRampEnd;
    /** coastLoc 保留为过渡带中心概念（配置/向后兼容），v8.3 已不再硬锚 e=0 */
    private final double coastLoc;
    private final TerrainParams params;

    // ===== 侵蚀（物理液滴侵蚀，恢复自「物理侵蚀-基本无断裂」基线） =====
    /** 物理侵蚀引擎（在 80×80 tile 上跑确定性侵蚀，仅提取中心 16×16，border 作上下文） */
    private final ErosionEngine erosion;
    /** 世界种子（区域确定性侵蚀，保证缓存一致、无闪烁） */
    private long worldSeed = 12345L;
    /** 全 tile 版本号计数器（滑窗收敛用：每生成一次 tile 递增） */
    private int erosionRoundCounter = 0;

    // ===== 侵蚀 tile 采样并行（2026-08-09 无伤优化） =====
    // 线程安全依据：terrainEQuick 只读 final noise 实例 + 局部变量，无共享可变状态
    // （预览 TerrainPool 已多线程跑同一 CellGenerator，验证无竞态）。
    // ★ 池演进：fixed(4) → cached(无界) → ThreadPoolExecutor(有界, 2026-08-09 OOM 修复)。
    //   cached 无限线程 + 每线程 1MB 原生栈 + L3 递归提交 → 世界创建高峰期线程爆炸 → 
    //   原生内存 mmap 失败崩溃（hs_err_pid48068: "Native memory allocation (mmap) failed"）。
    //   有界池 + CallerRunsPolicy：队满时提交者自己跑（等价串行，天然反压，绝不排队饿死），
    //   线程数硬顶 16 → 内存可控。
    // 外层 tile 采样并发度。2026-08-09 由 4 提到 8（20 核机器冷启动 tile 排队吞吐 ×1.5-2；
    // daemon 池不阻塞主线程）。8 曾因"tile 线程 × 内部 parallelRows(commonPool) 嵌套并行"
    // 导致线程超订风暴，已在 5e7b8dd 根治，现 8 可安全使用。
    public static final int TILE_PARALLELISM = 8;
    public static final ExecutorService TILE_SAMPLER = new ThreadPoolExecutor(
        TILE_PARALLELISM, 16, 60L, TimeUnit.SECONDS,
        new LinkedBlockingQueue<>(64),
        r -> { Thread t = new Thread(r, "GeoGenesis-TileSampler"); t.setDaemon(true); return t; },
        new ThreadPoolExecutor.CallerRunsPolicy());

    // 可选预热有独立预算；饱和拒绝，不能把后台工作压回渲染/区块请求线程。
    private static final ThreadPoolExecutor TILE_PREHEATER = new ThreadPoolExecutor(
        2, 2, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(32),
        r -> { Thread t = new Thread(r, "GeoGenesis-TilePreheater"); t.setDaemon(true); return t; },
        new ThreadPoolExecutor.AbortPolicy());
    private final java.util.Set<Long> queuedTilePreheats = ConcurrentHashMap.newKeySet();

    // 温度参数（v6 纬度梯度，2026-09-10 取代旧正弦锚点模型）
    private final double tempFreq;    // 温度纬度角频率 = 1/latitudeScale（由 TerrainParams 注入，可配置）
    private final Noise tempWarp;     // 温度噪声扰动
    private final Noise humidityNoise; // 独立湿度噪声
    /** 气候区（抖动 Voronoi）：区内温湿恒定，消除群系椒盐碎斑 */
    private final ClimateRegion climateRegion;
    /** 降水的地形调制场（★ 2026-09-11 Phase B）：地形雨 / 雨影 / 焚风 */
    private final PrecipField precipField;
    /**
     * 温度 e 单位的"每单位多少 °C"换算（焚风用）。
     * {@code Climate.temperature ∈ [-1,1]} 对应约 −40…+40 °C → 1 e 单位 ≈ 40 °C。
     */
    private static final double DEG_C_PER_E_UNIT = 40.0;

    /**
     * 纬度降水廓线参考值（★ Phase D）：把 {@link LatPrecipProfile} 折算到均值 ≈1，
     * 使"区域层降水"与旧"区域层湿度"量级可比，避免切换后全图群系整体漂移。
     * 0.70 ≈ 廓线在 lat01∈[0,1] 上的平均（控制点 1.40 / 0.30 / 1.00 / 0.35 / 0.25）。
     */
    private static final double LAT_PRECIP_REF = 0.70;
    /** 气候区尺寸（wu），区界扰动幅度按它取 */
    private final double regionSize;
    /** 区界扰动噪声：让 Voronoi 边界蜿蜒（否则边界是直线/大块多边形） */
    private final Noise regionWarp;
    /** 绿洲斑块噪声（大尺度）：河流绿洲的断续门控（RTG SurfaceRiverOasis 范式） */
    private final Noise oasisNoise;

    private final boolean morphBase;
    private final double minWorldY, maxWorldY;
    private com.geogenesis.worldgen.core.BaseWorldSampler baseWorld;

    public CellGenerator(TerrainParams p, double minWorldY, double maxWorldY) {
        this(p, minWorldY, maxWorldY, false);
    }

    /** P1 is selected by the world's persisted algorithm, not by the erosion/river TOML flags. */
    public CellGenerator(TerrainParams p, double minWorldY, double maxWorldY, boolean morphBase) {
        this.morphBase = morphBase;
        this.minWorldY = minWorldY;
        this.maxWorldY = maxWorldY;
        this.continent = new ContinentField(p);
        this.heightCurve = new HeightCurve(p, minWorldY, maxWorldY);
        this.typeLandShape = new TypeLandShape(p);
        this.seaBed = new SeaBedDetail(p);
        this.oceanFeatures = new OceanFeatures();
        this.landFeatures = new LandFeatures();
        this.coastline = new CoastlineField(p);
        this.tectonic = new TectonicField(0L);   // 种子在 seed() 注入
        this.strata = new StratumField(0L);      // ★ T4：地层场（种子在 seed() 注入）
        this.deform = new TectonicDeformation(0L); // ★ T5：褶皱/断层形变场
        this.continentBias = p.continentBias();
        this.seabedAmp = p.seabedDetail();
        this.oceanDepthFactor = p.oceanDepthFactor();
        this.oceanFadeStart = p.oceanFadeStart();
        this.landRampEnd = p.landRampEnd();
        this.coastLoc = p.coastLoc(); // 复用已有 coastLoc 作为两段分界
        this.params = p;

        // 侵蚀：物理液滴侵蚀引擎（恢复自好基线）。配置在游戏内已 load；
        // 独立预览（config 未 load）时回退默认值。
        this.erosion = com.geogenesis.config.ParticleErosionConfigAdapter.createForCell(TILE_PARALLELISM);

        this.tempFreq = 1.0 / p.latitudeScale();   // 纬度缩放可配置

        // 气候噪声（xz 缩放可配置）
        this.tempWarp = new Frequency(new Simplex(501), 1.0 / p.tempWarpScale());
        this.humidityNoise = new Frequency(new Simplex(502), 1.0 / p.humidityScale());
        this.climateRegion = new ClimateRegion(p.climateRegionSize());
        this.regionSize = p.climateRegionSize();

        // 降水地形调制场（★ Phase B）：高度取用走"廉价 + 绝不触发侵蚀 tile"铁律 ——
        // heightFromE(terrainEQuick(·)) 是纯噪声场，与 FlowAccumProbe 的 baseGround 同源。
        // 种子在 seed() 里注入（此处先给 0）。
        this.precipField = new PrecipField(0L,
            (x, z) -> heightCurve.heightFromE(terrainEQuick(x, z)),
            p.latitudeScale(), PrecipField.Params.defaults(), WindField.Params.defaults(),
            heightCurve.seaLevelY());   // ★ Phase E：注入海平面 → 上风向海域回灌湿度
        clearEqCache();   // terrainEQuick 缓存哨兵初始化
        // 波长 ≈1.5 个气候区：边界以该尺度蜿蜒，观感自然
        this.regionWarp = new Frequency(new Simplex(503), 1.0 / (p.climateRegionSize() * 1.5));
        // 波长 ≈0.75 个气候区：绿洲斑块与气候区同尺度，是"断续的绿洲群"而非细碎噪点
        this.oasisNoise = new Frequency(new Simplex(504), 1.0 / (p.climateRegionSize() * 0.75));
    }

    /** 一次性播种所有噪声节点 + 设置海山中心水深检查器 */
    public void seed(long worldSeed) {
        if (morphBase) {
            baseWorld = new com.geogenesis.worldgen.core.BaseWorldSampler(
                    worldSeed, params, (int) minWorldY, (int) maxWorldY,
                    com.geogenesis.config.BaseWorldConfigAdapter.snapshot());
        }
        continent.seed(worldSeed);
        typeLandShape.seed(worldSeed);
        seaBed.seed(worldSeed);
        precipField.setSeed(worldSeed);   // ★ Phase B：降水场随世界种子重置
        tectonic.setSeed(worldSeed);      // ★ 地质 Phase T1：构造格局随世界种子重置
        strata.setSeed(worldSeed);        // ★ 地质 Phase T4：地层分布随世界种子重置
        deform.setSeed(worldSeed);        // ★ 地质 Phase T5：褶皱/断层相位随世界种子重置
        clearEqCache();                   // ★ D13：地形 e 缓存随世界种子失效
        // 海山中心水深检查：计算中心点的真实 eOcean（含 seabed，不含海山增量）
        // 仅在 eOcean_at_center < -0.20（足够深）时才允许生成海山
        oceanFeatures.setSeamountDepthChecker((wx, wz) -> {
            double c = continent.sample(wx, wz);
            double cBiased = c - continentBias;
            double eBase = heightCurve.eFromC(cBiased);
            // 2026-08-06 修复：depthMod 语义 = "深海加深 / 浅海不变"（x 越低值越大）→
            // 1-smoothstep(-0.6,-0.2,eBase)。原实现方向反（浅海 1.8/深海 0.6）。
            double depthMod = 0.6 + (1.0 - smoothstep(-0.6, -0.2, eBase)) * 1.2;
            double seabed = seabedAmp * depthMod * seaBed.sample(wx, wz);
            double eOcean = (eBase + seabed) * oceanDepthFactor;
            return Math.min(eOcean, 0.0);
        });
        coastline.seed(worldSeed);
        oceanFeatures.seed(worldSeed);
        landFeatures.seed(worldSeed);
        // ★ 2026-09-13 Phase T7(P4)：陆地火山布点改由【俯冲带火山活动强度】驱动
        //   （沿俯冲带富集，而非随机散布）。注入而非直接持有 —— 与 setSeamountDepthChecker
        //   同一模式（保持本类不感知构造场）。
        landFeatures.setArcVolcanismProvider(tectonic::arcVolcanism);
        // ★ 2026-09-14 P5：注入【中心点海陆判定】—— 火山按中心决定去留（整体生成），
        //   替代原先"逐点 × landFactor"的斜切（见 landFactorAt 注释）。
        landFeatures.setLandFactorProvider(this::landFactorAt);
        // ★ 2026-09-14 Phase T8(P3)：注入【岩性抗蚀性】—— 侵蚀按岩性调制
        //   （软岩成谷、硬岩成脊）。与上面两个注入同一模式：保持侵蚀引擎不依赖地质包。
        erosion.setHardnessProvider(this::rockResistanceAt);
        erosionTileCache.clear();
        this.worldSeed = worldSeed;
        Noises.seedAll(tempWarp, worldSeed, 0);
        Noises.seedAll(humidityNoise, worldSeed, 0);
        Noises.seedAll(regionWarp, worldSeed, 0);
        Noises.seedAll(oasisNoise, worldSeed, 0);
        climateRegion.seed(worldSeed);
    }

    /** 世界高度下界 */
    public double minY() { return heightCurve.heightFromE(-1.0); }

    /** 世界高度上界 */
    public double maxY() { return heightCurve.heightFromE(1.0); }

    /** 海平面 Y */
    public double seaLevel() {
        return heightCurve.heightFromE(heightCurve.seaE());
    }

    /** TerrainParams 访问器（门面做块→wu 换算需要）。 */
    public TerrainParams params() { return params; }

    /**
     * 采样单格地形场（不含气候与分类）。供 {@link #sample} 与 {@link #terrainE}/{@link #landE} 复用。
     * 返回已设置 e/eLand/eOcean/blendCont/coastCoord/typeWeights/height/shape 的 Cell。
     *
     * <p><b>2026-08-10 wu 化（尺度解耦）</b>：坐标语义 = <b>wu（world unit）</b>，不再感知 MC 块。
     * 块→wu 换算只在 MC 门面 {@code GeoGenesisTerrain}（/horizontalScale）。噪声频率常量
     * 数值不变（语义块→wu），HS=1 时与旧实现逐位等价。</p>
     */
    public boolean usesMorphBase() { return morphBase; }

    private Cell sampleMorphCore(double x, double z) {
        return com.geogenesis.worldgen.terrain.morph.MorphCellAdapter.from(baseWorld.sampleTerrain(x, z));
    }

    private Cell sampleCore(double wx, double wz) {
        if (morphBase) return sampleMorphCore(wx, wz);
        double sx = wx, sz = wz;

        Cell cell = new Cell();

        // 1. 大陆性 c
        double c = continent.sample(sx, sz);
        cell.continent = c;
        double cBiased = c - continentBias;

        // 2. 海洋基面 eOcean（不 clamp 到 0——陆地区域 eBase 为正，自然地增高）
        double eBase = heightCurve.eFromC(cBiased);
        // 2026-08-06 修复：depthMod = "深海加深/浅海不变" → 1-smoothstep(-0.6,-0.2,eBase)
        double depthMod = 0.6 + (1.0 - smoothstep(-0.6, -0.2, eBase)) * 1.2;
        double seabed = seabedAmp * depthMod * seaBed.sample(sx, sz);
        double eOcean = eBase + seabed;
        eOcean = eOcean * oceanDepthFactor;
        // ★ 2026-09-13 Phase T6：构造采样【提前】到海洋特征之前 —— 海洋特征的
        //   「洋中脊位置」（构造离散带门控）与「火山弧」（俯冲带离轴隆起）都依赖构造场。
        //   同一次采样随后供 T1 权重调制 / T4 岩性 / T5 形变复用 ⇒ 不增加采样次数。
        TectonicField.Sample tectSample = TECTONIC_ENABLED ? tectonic.sample(sx, sz) : null;

        // 海洋特征：计算洋中脊/海山/火山弧增量，叠加到 eOcean 使海床产生实际地形。
        double arcProf = tectSample != null ? tectonic.oceanProfile(tectSample) : 0.0;
        OceanFeatures.FeatureResult oceanFeat =
            oceanFeatures.compute(sx, sz, Math.min(eOcean, 0.0), cBiased, tectSample, arcProf);
        eOcean += oceanFeat.total; // 海山/洋中脊/弧抬升海床（仅海洋侧生效，陆地侧 blend 天然淡出）
        cell.oceanFeat = oceanFeat; // 缓存供 classify 使用，避免 sample() 重复 compute

        // 3. 连续类型混合结果
        TerrainCharacterField.BlendResult cellBlend = typeLandShape.sampleBlend(sx, sz);
        cell.typeWeights = cellBlend.typeWeights;
        // ★ 2026-09-12 地质 Phase T1：构造决定类型（汇聚→造山/海沟，离散→裂谷/洋脊）
        //   ★ 2026-09-13：复用上方已采样的 Sample（原先在本行重复采样一次构造场）
        if (tectSample != null) applyTectonicWeights(cell.typeWeights, tectSample, sx, sz, cBiased);

        // 4. 海岸线域扭曲（v8 CoastlineField）— 海洋深度/类型样条用的 c 空间位移（保留轻量扰动）。
        double cEdge = cBiased + coastline.warpDisplacement(sx, sz, cBiased);

        // 5. 全类型混合 e（2026-08-06 海陆类型化）：OCEAN/DEEP_OCEAN 已是类型场成员，
        //    e = Σw·lo + Σw·(hi-lo)·modulated → e 自然连续穿过 0，海陆边界 = Voronoi 类型竞争。
        double eLand = typeLandShape.sample(cellBlend, sx, sz, cEdge);

        // 6. 特征增量的海陆门控（★ 2026-09-13 修复：改用【与地形同源】的门控）
        //
        //   【修复的问题（用户反馈"平原上的火山特别矮：平原 68 格、火山才 78 格"）】
        //   原用 `landW = 1 − oceanW`（oceanW 来自**类型权重场**）作陆地特征权重。
        //   但类型权重场与地形海陆（由 eLand 定义）**可以不一致**：实测一座位于
        //   e=+0.6552（明显内陆高地）的火山，其 `oceanW=0.4207` ⇒ `landW=0.58`
        //   ⇒ 火山只按 58% 抬升（0.161 e ≈ 38 格，而非应有的 65 格）。
        //   这与本项目反复出现的"两个场互相矛盾"是同一类问题
        //   （参见 `shellFromC` / 大陆架判据的注释）。
        //
        //   【正解】门控直接由**特征前的地形** eLandBase 推出（与海岸线同源，定义上不可能矛盾）：
        //     landFactor = smoothstep(−ε, +ε, eLandBase)   // 连续 0→1，ε=0.01
        //     海洋特征 × (1 − landFactor)（陆侧自然淡出）
        //   海岸线上 eLandBase=0 → 各半，过渡连续（无硬边）。
        //   ★ 这也是用户在"大陆架"反馈中确认有效的同一思路。
        //
        //   ★★ 2026-09-14 P5：<b>陆地特征不再乘 landFactor(x,z)</b> ★★
        //     用户反馈"火山山体靠海就被海陆过渡机制影响，导致火山口被强行降低"。
        //     逐点缩放（total × landFactor(x,z)）会让山体<b>靠海一侧被压缩</b>（斜切），
        //     且火口下凹（0.02~0.07e）在 eLandBase≈0 处几乎被抹平。
        //     现改为在 {@link LandFeatures} 内按<b>火山中心</b>取一次 landFactor
        //     （{@code landFactorAt}，经 {@link LandFeatures#setLandFactorProvider} 注入），
        //     对整座火山<b>整体</b>缩放 ⇒ 形状与火口完整、中心在深海则整座不生成
        //     （杜绝陆地火山造陆，与 {@link OceanFeatures} 的海山中心判定同构）。
        double eLandBase = eLand;                                  // 特征前地形 = 海陆定义
        double landFactor = smoothstep(-0.01, 0.01, eLandBase);
        LandFeatures.FeatureResult landFeat = landFeatures.compute(sx, sz, tectSample);
        double oceanW = (cellBlend.typeWeights[TerrainClass.OCEAN.ordinal()]
            + cellBlend.typeWeights[TerrainClass.DEEP_OCEAN.ordinal()]);
        // ★ 2026-09-14 P5：海陆判定已下沉到 LandFeatures 的【火山中心】，
        //   按中心因子【整体】缩放（见 LandFeatures.centerFactorOf）⇒ 此处直接相加。
        //   【为何不再乘 landFactor(x,z)】那是逐点缩放 ⇒ 斜切山体 + 压浅火口
        //   （用户反馈"火山山体靠海就被海陆过渡机制影响，火山口被强行降低"）。
        eLand += landFeat.total;

        // ★ 2026-09-12 地质 Phase T4：地层/岩性（构造环境 → 地层序列 → 出露岩性）。
        //   纯数据层，不参与 e 合成（不影响地形/气候/水文）；
        //   为 ROCK_LAYER / ROCK_TYPE 预览图层提供此前完全缺失的数据源。
        //   ★ 2026-09-13 P0.5：海陆判据改用【壳属性 shellS】（= shellFromC(c)），
        //     与海陆同源 ⇒ 不会像 oceanW 那样给出"c 说海、类型场说陆"的矛盾答案。
        TectonicField.Sample tsAll = null;
        if (STRATA_ENABLED || DEFORM_ENABLED) {
            tsAll = tectSample != null ? tectSample : tectonic.sample(sx, sz);
        }
        if (STRATA_ENABLED) {
            cell.rockLayer = strata.layerAt(sx, sz);
            boolean isLandShell = TectonicField.shellFromC(cBiased) > 0.5;
            cell.rockTypeId = StratumField.rockTypeId(tsAll, isLandShell, cell.rockLayer);
            // ★ 2026-09-14 Phase T9/T9b：整条地层序列 + 各层厚度（打包）→ 供方块层铺垂直岩层
            cell.rockSeqPacked = strata.packSequence(tsAll, isLandShell, sx, sz);
            // ★ 2026-09-14 Phase T10：区域倾斜/褶皱偏移（水平地层的界面起伏）
            cell.rockTilt = strata.tiltAt(sx, sz);
        }

        // ★ 2026-09-12 地质 Phase T5：构造形变（褶皱 / 断层）。
        //   叠加到 eLand（形变本质是"地形被构造应力改造"）。
        //   设计为近零均值：褶皱用正弦（天然零均值），断层断块用中心化哈希
        //   → 不整体抬升/压低地形，避免 T1 那次"整体抬升连锁改变降水与河宽"的教训。
        if (DEFORM_ENABLED && tsAll != null) {
            eLand += deform.offset(tsAll, sx, sz);
        }

        // 2026-08-06 修复：移除整体 ×0.9 余量缩放。该设计为旧显式脊谷抬升（+0.17e）预留空间，
        // 显式抬升 2026-08-05 已全部移除 → ×0.9 只是无谓压低整个地形 10%
        // （用户反馈"有什么在限制着"；山脉 hi 0.95 实际仅 0.855）。softCapLandE（>0.9215 才压缩）
        // 仍是保险。样条/滑块设置的高度现在如实生效。
        cell.eLand = eLand;
        cell.landFeat = landFeat; // 缓存供 classify 使用，避免 sample() 重复 compute

        // ★★★ 2026-09-13 Phase T7(P0.5)：**海床护栏**（从构造上杜绝"海洋特征造陆"）★★★
        //
        //   【问题（实测）】海床特征（海山/洋中脊/火山弧）按 `× oceanW` 软加权叠加时，
        //   在【eLand ≈ 0 且 oceanW 仍较大】的点上会把地形推过 e=0 ⇒ 冒出一座"孤岛"。
        //   实测（OceanTypeProbe 差分归因，seed=12345）：
        //     洋中脊 22 例 / 3460 作用点  ·  火山弧 17 例 / 602  ·  海山 0 例
        //   逐点诊断定机制：`eOcean=−0.250`（c 场说深海，弧的深海门控通过）
        //   但 `eLand=−0.0033`（类型场说陆）——**两场不一致**是该现象的唯一成因。
        //
        //   【为何"× oceanW" 挡不住】`oceanW` 是类型场的海洋权重，在 eLand≈0 处仍可达 0.68
        //   （类型场在海陆过渡带本就是渐变）⇒ 弧贡献 0.10×0.68=0.068e ≫ 0.0033。
        //   （另注：`OceanFeatures` 内部**已有**基于 eOcean 的深海门控 `arcFade`，
        //     故这个 `× oceanW` 是**重复门控**，且引入了类型场的矛盾。）
        //
        //   【正解：护栏，而非调小特征】让海洋特征的<b>累计抬升</b>永不把地形推过海平面：
        //       oceanFeat.total·oceanW ≤ (−eLand) − MARGIN
        //   深海处 `eLand` 很负 ⇒ 上限远大于特征幅度 ⇒ **完全不生效**（特征形态不变）；
        //   只在 `eLand≈0`（矛盾点）才压缩 ⇒ 那些孤岛消失，且 MARGIN 保证被压缩点仍 <0
        //   ⇒ **不新增/移除海岸线**（既有标定不受影响）。用 C¹ 的 smoothMin 避免折痕。
        //
        //   ★ 必须放在此处（**T5 形变之后**）——初版放在第 6 步（形变前）时护栏算漏了
        //     `deform.offset`（可达 +0.045e）的抬升，实测仍有 14/13 例漏网（洋中脊 22→13、
        //     弧 17→14 只降不归零）。移到最终 `eLand` 之后才真正封住。
        //   ★ 权重同样改用同源门控 (1 − landFactor)：海侧 eLandBase<0 → ≈1（满值），
        //     陆侧 → 0（自然淡出），海岸线处各半（连续）。原用 oceanW（类型场）会
        //     在"类型场与地形不一致"处既可能放大也可能缩小海洋特征。
        double oceanFeatW = oceanFeat.total * (1.0 - landFactor);
        if (oceanFeatW > 0.0) {
            double cap = -eLand - SEABED_MARGIN;
            oceanFeatW = cap <= 0.0 ? 0.0 : TectonicField.smoothMin(oceanFeatW, cap, SEABED_SOFT_SAT);
        }
        // （诊断可用 `cell.e − cell.eLand` 反推本值：低处 softCapLandE 不介入 ⇒ 精确；
        //   故不新增 Cell 字段，避免扩大改动面。）

        // 7. 连续主导类型（可能为 OCEAN/DEEP_OCEAN）
        TerrainClass cellType = TypeLandShape.dominantFromWeights(cellBlend.typeWeights);

        // 8. 海陆统一 e = 类型混合 + 海洋特征增量（海山/洋中脊按海洋权重平滑淡入；
        //    上方已过"海床护栏"，保证这一项不会把地形推过海平面）
        double e = softCapLandE(eLand + oceanFeatW);
        cell.e = e;
        cell.eClimate = e;   // 侵蚀前 e：群系垂直带判定专用（applyTileDelta 不覆写）
        cell.variantTerrain = ditheredTerrain(cell.typeWeights, wx, wz);
        cell.eOcean = eOcean;      // 海洋基面（预特征，分类/诊断用）
        cell.blendCont = oceanW;   // 语义（2026-08-06）：海洋类型权重和（原 cont 已废除）
        cell.height = heightCurve.heightFromE(e);
        cell.coastCoord = cEdge;
        cell.shape = eLand * 2.0 - 1.0;
        return cell;
    }

    /**
     * 采样单格完整数据 — 统一连续场 e(x,z)，叠加气候与分类。
     * 坐标语义 = wu（2026-08-10 wu 化，见 {@link #sampleCore}）。
     */
    public Cell sample(double wx, double wz) {
        if (morphBase) return com.geogenesis.worldgen.terrain.morph.MorphCellAdapter.from(baseWorld.sample(wx, wz));
        Cell cell = sampleCore(wx, wz);
        double sx = wx, sz = wz;

        // 8. 气候（v5 双轨模型，对齐 RTF ClimateModule，2026-09-10）
        //    RTF 原文：cell.biome = BiomeType.get(regionTemperature, regionMoisture)
        //              cell.temperature/moisture = 在【查询位置】采样的连续值
        //    ① 区域层（区内恒定）→ 只决定 Whittaker 群区 → 群系成片、不椒盐
        //    ② 连续层（逐格平滑）→ 暴露到 Cell.climate → 预览/下游看到平滑渐变
        //    【教训】此前把暴露的温湿度也做成区域恒定 → 温度/湿度/群系三个图层全成
        //      平顶马赛克（用户实测"多边形"）。双轨后温湿是连续曲线，群系仍是成片。
        // 区界扰动（参考 RTF 的 biomeEdgeShape：多倍频噪声 + offsetX/offsetZ）。
        // 【教训】单频扰动只能把 Voronoi 的直线"弯一下"，长直段依然可见（用户实测仍有直边多边形）；
        // 多倍频在 1.5×/0.75×/0.375× 区尺度同时起伏 → 打断所有可见尺度的直线段。
        double rx = wx + regionWarpOffset(wx, wz);
        double rz = wz + regionWarpOffset(wz, wx);
        ClimateRegion.Sample reg = climateRegion.sample(rx, rz);

        // ① 区域层：只算群区
        // ★ 2026-09-11 Phase D：Whittaker 的"降水轴"由【区域层湿度】换成【区域层降水】——
        //   区域层湿度 × 纬度降水廓线（ITCZ 峰 / 副热带谷 / 西风带次峰 / 极地低）。
        //
        //   为什么必须用【区域层】而非逐格连续的 cell.precipitation：
        //   逐格值含 96wu 尺度的地形雨/雨影 → 群区会随之地形破碎，退化成"椒盐群系"
        //   （本项目在温湿度上踩过这个坑，见下方"双轨模型"注释）。
        //   区域层 → 区内恒定 → 群系仍成片；纬度结构则带来了真正的"行星级"分异。
        double regionMoist01 = clamp(regionMoisture(reg) * 0.5 + 0.5, 0.0, 1.0);
        double regionPrecip01 = clamp(
            regionMoist01 * LatPrecipProfile.at(Latitude.latitude01(wz, params.latitudeScale()))
                / LAT_PRECIP_REF, 0.0, 1.0);
        cell.biomeType = WhittakerType.classify(
            clamp(regionTemperature(reg) * 0.5 + 0.5, 0.0, 1.0), regionPrecip01);

        // ② 连续层：纬度 + 低频噪声，再叠加逐格地形修正
        double temp = temperatureAt(wx, wz);
        temp *= 0.85 + 0.15 * clamp(cell.continent * 1.5, 0.0, 1.0);    // 大陆性温差（逐格）
        temp -= elevationTempDrop(cell.e);                              // 海拔递减（逐格）

        // ★ 2026-09-11 Phase B：降水地形调制（地形雨 / 雨影 / 焚风）。
        //   一次"上风向回扫"同时得出三者；焚风为背风坡干绝热下沉增温，并入温度。
        PrecipField.Mod pm = precipField.at(wx, wz);
        temp += pm.foehnWarm() / DEG_C_PER_E_UNIT;
        temp = clamp(temp, -1.0, 1.0);

        double hum = humidityNoise.compute(wx, wz) * 0.75;               // 低频平滑湿度噪声
        hum = continentMoisture(hum, cell.continent);                     // 大陆性：沿海湿 / 内陆干（逐格）
        hum -= elevationMoistureDrop(cell.e);                             // 高海拔变干（逐格）
        // ★ 2026-09-11 Phase E：水文 → 气候反向耦合。
        //   上风向为海面时下风向增湿（水汽来源），完成"地形→气候→水文→气候"闭环。
        //   注：Whittaker 群区用的是【区域层】温/降水，故此处逐格增湿【不会】产生椒盐群系；
        //   但它会经 precipitationFrom 提高降水 → 进而加宽下游河宽（Phase C 链），
        //   水源为地形固定的海面 → 不存在"河越宽→越湿→河更宽"的正反馈发散。
        hum += pm.waterMoist();
        hum = clamp(hum, -1.0, 1.0);

        // 气候影响权重（tempInfluence / humidityInfluence / continentInfluence）
        GeoGenesisConfig cfg = GeoGenesisConfig.INSTANCE;
        double tempInf = cfg != null ? cfgDbl(cfg.tempInfluence, 1.0) : 1.0;
        double humInf = cfg != null ? cfgDbl(cfg.humidityInfluence, 1.0) : 1.0;
        double contInf = cfg != null ? cfgDbl(cfg.continentInfluence, 1.0) : 1.0;
        double tempE = clamp(temp * tempInf, -1.0, 1.0);
        double humE = clamp(hum * humInf, -1.0, 1.0);
        double contE = clamp(cell.continent * contInf, -1.0, 1.0);

        // ★ 2026-09-11 Phase B：降水 = 纬度廓线 × 湿度 × (1+地形雨) × (1−雨影) × 温度门控
        double precipE = precipitationFrom(humE, tempE,
            Latitude.latitude01(wz, params.latitudeScale()), pm);

        cell.climate = new com.geogenesis.worldgen.climate.Climate(tempE, humE, contE, precipE);
        cell.temperature = tempE;
        cell.humidity = humE;
        cell.precipitation = precipE;

        // 9. 雪线（单一来源）：配置基准 + 纬度（温度）耦合 + 湿度耦合。
        //    —— 干区雪线升高、湿区降低；暖区升高、寒区降低。
        //    —— isSnow 供 BiomeClassifier 与地表铺雪共用，取代此前散落的硬编码阈值。
        cell.snowLineE = params.snowLine()
            + params.snowLatitudeInfluence() * tempE
            - params.snowHumidityInfluence() * humE;
        // 两种情况要雪：① 海拔超过雪线；② 气候本身极寒（对应 ICE/TUNDRA 群的 SNOWY_PLAINS）。
        // ② 不可省：本模组 buildSurface 为空实现（原版 SurfaceSystem 的铺雪不会执行），
        //   若只按海拔判雪，极地平坦地带会顶着「雪原」群系却没有雪。
        cell.isSnow = cell.eClimate > 0.0
            && (cell.eClimate > cell.snowLineE || tempE < POLAR_SNOW_TEMP);

        // 9. 分类（使用 sampleCore 已缓存 FeatureResult，避免重复 compute）
        if (!morphBase) {
            cell.terrainType = classify(cell.continent, cell.e, cell.eLand,
                TypeLandShape.dominantFromWeights(cell.typeWeights), cell.typeWeights,
                tempE, humE, cell.oceanFeat, cell.landFeat, cell.coastCoord);
        }
        cell.continentNoise = cell.continent;
        cell.oasisNoise = oasisNoise.compute(wx, wz);

        return cell;
    }

    /** 排水高程（真实地表 e，含海陆混合）。河流节点场用它做下坡汇流，海洋侧 e<0 → 不接河。 */
    public double terrainE(double wx, double wz) { return sampleCore(wx, wz).e; }

    /**
     * 归一化降水采样（★ 2026-09-11 Phase C）—— 供水文汇流加权使用。
     *
     * <p>走 {@link #sample}（纯噪声 + 气候，<b>不含侵蚀</b>）→ 廉价且<b>不触发侵蚀 tile</b>。
     * 水文侧按粗格点调用（见 {@code FlowField.PRECIP_COARSE}）以避免过采样。</p>
     */
    public double precipitationAt(double wx, double wz) {
        return sample(wx, wz).precipitation;
    }

    /** 大陆性 c 采样（wu 语义，纯位置函数）。waterTable 水面推导用（RTF 范式河网）。 */
    public double continentAt(double wx, double wz) {
        return continent.sample(wx, wz);
    }

    // ===== terrainEQuick 直接映射缓存（★ 2026-09-11，D13 性能）=====
    // 纯函数 (wx,wz) → e（同 seed 恒定）。实测两个热点会【在同一批坐标】各采样一次：
    //   routingE（FlowField 选线场）与 computeFill（填洼层，走 groundYAt）
    //   → 天然 2× 冗余；跨 region 的 margin 重叠再放大。
    // 缓存命中 ~20ns vs 计算 ~6µs（runBench 实测 16384 次 = 97.61ms）。
    //
    // ★ 并发铁律：terrainEQuick 会被【侵蚀 tile 并行行】与【水文多线程】调用。
    //   两个不变量都必须成立：
    //   ① 【单条读取 key+value 原子】—— 键与值必须由【同一不可变 entry】承载，
    //      读者只取一次槽引用即同时拿到 key 与 value。旧实现用两个 AtomicLongArray
    //      （eqKeys/eqVals 各写一次）：读者命中 key 之后、读 value 之前，若有另一线程
    //      用【不同坐标】覆盖同一槽，则会读到【别人坐标的值】——这不是撕裂读，而是
    //      静默错值（无任何异常/NaN 提示），且液滴并行与水文多线程下真实可发生。
    //   ② 【槽只定位不当身份】—— 哈希槽只是哈希表定位，身份由 entry 内的完整
    //      key（EQ 为 wu 位模式混合键；HR 为 qx/qz 量化坐标）比较决定；碰撞只是
    //      增未命中，绝不返回异槽/异坐标的值。
    //   容量不变（EQ_CACHE_SIZE / LF_CACHE_SIZE / HR_CACHE_SIZE），产出与旧实现同分布。
    private static final int EQ_CACHE_BITS = 17;                 // 131072 槽 ≈ 2 MB
    private static final int EQ_CACHE_SIZE = 1 << EQ_CACHE_BITS;
    private static final int EQ_CACHE_MASK = EQ_CACHE_SIZE - 1;
    /** 空槽哨兵（构造/播种时填充；真实键恰为此值者会被重映射，概率 2^-64）。 */
    private static final long EQ_EMPTY = Long.MIN_VALUE;

    /** 键值对的不可变快照（entry 为 null = 空槽）。替换引用 = 单条 API 的原子发布。 */
    private record KeyedValue(long key, long bits) {}
    private final AtomicReferenceArray<KeyedValue> eqEntries =
            new AtomicReferenceArray<>(EQ_CACHE_SIZE);
    private final AtomicLong eqHits = new AtomicLong();
    private final AtomicLong eqMisses = new AtomicLong();

    /** 清空 terrainEQuick 缓存（换种子/构造时调用）。按引用置 null 清空（与 seed/配置变更同义）。 */
    private void clearEqCache() {
        for (int i = 0; i < EQ_CACHE_SIZE; i++) eqEntries.set(i, null);
        eqHits.set(0);
        eqMisses.set(0);
        for (int i = 0; i < LF_CACHE_SIZE; i++) lfEntries.set(i, null);
        clearRockResistanceCache();   // ★ P3：岩性硬度缓存（种子/配置变更时一并失效）
    }

    // ===== ★ 2026-09-14 P5：火山中心「海陆判定」缓存 =====
    //   火山中心是【哈希确定的离散点】（单体格 800wu，每格至多一座），
    //   其半径（最大 300wu）内的所有采样点都要反复查询"这个中心在陆上吗"
    //   ⇒ 空间局部性极强，命中率 > 99%。
    //   【为何必须缓存】不加缓存时每次查询要重算"半个 sampleCore"
    //   （continent + 类型场 Voronoi + 海岸线扭曲 + 构造权重），而调用频率约
    //   0.7 次/采样点（单体 8%×9 邻居格 + 火山区 12%×9×区域占比）
    //   ⇒ 实测开销约 +40%。同地形 e 缓存（不可变 entry 单条原子读），
    //   键域用 LF_SALT 隔离，避免与 e 缓存互相覆盖。
    private static final int LF_CACHE_BITS = 12;                 // 4096 槽 ≈ 64 KB
    private static final int LF_CACHE_SIZE = 1 << LF_CACHE_BITS;
    private final AtomicReferenceArray<KeyedValue> lfEntries =
            new AtomicReferenceArray<>(LF_CACHE_SIZE);
    private static final long LF_SALT = 0x5DEECE66DL;

    /** 缓存命中/未命中统计（诊断用）。 */
    public long eqCacheHits() { return eqHits.get(); }

    /** 缓存未命中数（诊断用）。 */
    public long eqCacheMisses() { return eqMisses.get(); }

    /**
     * 轻量地形 e（跳过气候/分类/height 映射/shape 赋值）—— <b>带直接映射缓存</b>。
     *
     * <p>缓存是<b>纯加速</b>：值为纯函数结果，命中与未命中等价（除 2^-64 的哨兵碰撞）。</p>
     */
    public double terrainEQuick(double wx, double wz) {
        if (morphBase) return baseWorld.sampleE(wx, wz);
        long kx = Double.doubleToRawLongBits(wx);
        long kz = Double.doubleToRawLongBits(wz);
        long key = kx ^ Long.rotateLeft(kz, 32);
        if (key == EQ_EMPTY) key = Long.MAX_VALUE;               // 避开哨兵
        int slot = (int) ((key * 0x9E3779B97F4A7C15L) >>> (64 - EQ_CACHE_BITS));
        KeyedValue entry = eqEntries.get(slot);                  // ★ 单条原子读取：key+value 同快照
        if (entry != null && entry.key() == key) {
            eqHits.incrementAndGet();
            return Double.longBitsToDouble(entry.bits());
        }
        eqMisses.incrementAndGet();
        double v = terrainEQuickCompute(wx, wz);
        eqEntries.set(slot, new KeyedValue(key, Double.doubleToRawLongBits(v)));
        return v;
    }

    /**
     * ★ 2026-09-14 P5：<b>特征前的基面「陆地门控」</b>（供 {@link LandFeatures} 按火山中心判定海陆）。
     *
     * <h3>为何需要（用户反馈"火山山体靠海就被海陆过渡机制影响，火山口被强行降低"）</h3>
     * <p>原实现把 {@code landFactor} 施加在<b>每个采样点</b>：
     * {@code eLand += landFeat.total * landFactor(x,z)}。而 {@code landFactor} 的过渡带
     * 仅 {@code ε=0.01e}（≈2.4 格）⇒ 对一座横跨海岸线的火山，山体的<b>靠海一侧被按比例压缩</b>
     * （= 斜切），且<b>火口下凹也被同比例压浅</b>（火口深度 0.02~0.07e 在 eLandBase≈0 处
     * 几乎被完全抹平）。地质上火山是<b>刚性离散体</b>：它不随基底的海陆过渡而"变软"。</p>
     *
     * <h3>正解：判定改到「中心点」，与海山完全同构</h3>
     * <p>{@link OceanFeatures} 早有正确先例（{@code seamountCenterDepthCheck}）：
     * 按<b>中心点</b>的水深决定这座海山生成与否，生成后整体叠加。本方法提供同样的
     * 「某点是否算陆地」，由 {@link LandFeatures} 在<b>火山中心</b>调用一次，
     * 决定整座火山的去留 ⇒ 山体不再被斜切、火口完整。</p>
     *
     * <p><b>为何是离散去留而非连续缩放</b>：中心距边界 &lt; 半径时，无论用哪种连续
     * 缩放，都必然使山体两侧不对称（= 斜切）。而"离散去留"只让海岸线上的火山
     * 要么完整、要么没有 —— 中心点哈希是<b>离散事件</b>，其判定边界不产生地形折痕
     * （对比：若用连续量做门控坐标，等值线会成为直线/折痕）。</p>
     *
     * <p><b>无自引用</b>：本方法算的是 {@code eLandBase}（<b>未叠加</b>任何特征的基面），
     * 与 {@link #sampleCore} 第 6 步一致 —— 绝不能调用 {@link #terrainEQuick}，
     * 那会经 {@code landFeatures.compute} 递归回本方法。</p>
     *
     * <p><b>非纯加速</b>：缓存只影响性能，命中与未命中等价（值为纯函数结果）。</p>
     *
     * @return 陆地门控 ∈ [0,1]：1 = 明确陆地（火山完整生成），0 = 明确海洋（不生成）
     */
    public double landFactorAt(double wx, double wz) {
        long kx = Double.doubleToRawLongBits(wx);
        long kz = Double.doubleToRawLongBits(wz);
        long key = (kx ^ Long.rotateLeft(kz, 29)) + LF_SALT;
        if (key == EQ_EMPTY) key = Long.MAX_VALUE;
        int slot = (int) ((key * 0x9E3779B97F4A7C15L) >>> (64 - LF_CACHE_BITS));
        KeyedValue entry = lfEntries.get(slot);                  // ★ 单条原子读取：key+value 同快照
        if (entry != null && entry.key() == key) {
            return Double.longBitsToDouble(entry.bits());
        }
        // ★★★ 2026-09-14 性能修复（用户"比几小时前慢"，卡在 0%）★★★
        //
        //   【原实现（性能回归根因，已删）】为精确复刻 eLandBase，本方法重采样了
        //   几乎整个 sampleCore：continent + typeLandShape.sampleBlend（7×7 Voronoi）
        //   + tectonic.sample + coastline.warpDisplacement + typeLandShape.sample。
        //   实测 <b>78,568 ns/次</b> —— 是 terrainEQuick 的 <b>8.75 倍</b>！
        //   而它被 terrainEQuick 链式触发（terrainEQuick → landFeatures.compute
        //   → centerFactorOf → 本方法）⇒ 河网构建（每 region 数万格）被拖慢近 9 倍。
        //
        //   【为何不需要精确】本方法唯一用途是回答"这个<b>火山中心</b>在陆上吗"，
        //   属【二值去留】判定（LandFeatures.centerFactorOf）。而
        //   {@link ContinentField} 正是本项目的<b>海陆场</b>（{@code shellFromC} 与它同源）
        //   ⇒ 直接用它判定即可，无需经过"类型场 Voronoi + 海岸线扭曲"那套形态学管线。
        //   两者在海岸带的细微差异，对"整座火山生成与否"无观感影响。
        double cBiased = continent.sample(wx, wz) - continentBias;
        double v = smoothstep(-0.01, 0.01, cBiased);
        lfEntries.set(slot, new KeyedValue(key, Double.doubleToRawLongBits(v)));
        return v;
    }

    // ===== ★ 2026-09-14 Phase T8(P3)：岩性抗蚀性（软岩成谷、硬岩成脊）=====
    //   侵蚀引擎按【抗蚀性】调制侵蚀量，故需按世界坐标查"该点什么岩性、多硬"。
    //   与 landFactorAt 同模式（不可变 entry 单条原子读 + 独立键域），
    //   因为 ErosionEngine 的硬度网格与液滴查表会反复命中同一批坐标。
    /**
     * ★ 岩性量化粒度（wu）：{@link #rockResistanceAt} 按此网格量化<b>缓存键与采样点</b>。
     *
     * <p>公开此常量以便诊断探针用<b>同一粒度</b>查询岩性 —— 若探针按真实坐标查、
     * 而引擎按网格中心取值，两者分组到的岩性会错位，判据会得出反向结论。</p>
     */
    public static final int ROCK_QUANT = 16;

    /** ★ 诊断用：侵蚀 tile 的有效输出边长（供探针按同口径取样）。 */
    public static int erodeTileSizeProbe() { return ERODE_TILE_SIZE; }

    private static final int HR_CACHE_BITS = 13;                 // 8192 槽 ≈ 128 KB
    private static final int HR_CACHE_SIZE = 1 << HR_CACHE_BITS;
    private static final long HR_SALT = 0x27BB2EE687B0B0FDL;
    /** ★ 键 = 完整 qx/qz 量化坐标（哈希混合只用于选槽，绝不作为身份）。 */
    private final AtomicReferenceArray<KeyedValue> hrEntries =
            new AtomicReferenceArray<>(HR_CACHE_SIZE);

    /**
     * ★ 2026-09-14 Phase T8(P3)：<b>岩性抗蚀性</b>（供 {@code ErosionEngine} 注入）。
     *
     * <p>走与 {@link #sampleCore} 岩性计算<b>完全同源</b>的推理链
     * （构造环境 → 地层序列 → 出露岩性 → {@link RockType#resistance()}），
     * 保证"预览图层显示的岩性"与"侵蚀实际使用的硬度"<b>永不矛盾</b>
     * （本项目反复强调的"两个场互相矛盾"教训）。</p>
     *
     * <p><b>无自引用</b>：不调用 {@code terrainEQuick}；只读构造场 + 地层场
     * （两者都是纯噪声场，不含侵蚀）。</p>
     *
     * @return 抗蚀性 ∈ [0,1]（越大越难蚀；±1 = 花岗岩 / 页岩）
     */
    public double rockResistanceAt(double wx, double wz) {
        // ★★★ 2026-09-14 性能修复（用户"速度没恢复"）：★ 缓存键改为【量化到 16wu 网格】★
        //
        //   【原缺陷】键 = 精确坐标位模式 ⇒ 每个不同坐标都是一次 miss。
        //   而硬度网格按 spacing 逐点采样（相邻点坐标必然不同）⇒ <b>命中率 ~0%</b>，
        //   每点都完整重算 continent + tectonic + layerAt（实测 ~22us/次）。
        //   同进程 A/B 实测：P3 耦合使 chunk 生成 <b>2084ms → 4049ms（+94%）</b>。
        //
        //   【为何可以量化】岩性由构造场（Voronoi 2000wu 级）+ 剥蚀噪声（900wu）决定，
        //   其空间变化尺度是<b>数百 wu</b> ⇒ 16wu 内取值几乎不变，量化误差
        //   （±8wu）远小于岩性单元尺寸，<b>视觉与地质语义均无损</b>。
        //   量化后同一网格单元只计算一次 ⇒ 命中率 >99%（相邻网格点多落在同一单元）。
        final int QUANT = ROCK_QUANT;
        long qx = Math.floorDiv((long) Math.floor(wx), QUANT);
        long qz = Math.floorDiv((long) Math.floor(wz), QUANT);
        // 完整 qx/qz 连成 key（量化单位已归一到 ROCK_QUANT 网格 ⇒ 不需再进键域）
        long key = ((qx << 32) ^ (qz & 0xFFFFFFFFL)) + HR_SALT;
        if (key == EQ_EMPTY) key = Long.MAX_VALUE;
        int slot = (int) ((key * 0x9E3779B97F4A7C15L) >>> (64 - HR_CACHE_BITS));
        KeyedValue entry = hrEntries.get(slot);                  // ★ 单条原子读取：key+value 同快照
        if (entry != null && entry.key() == key) {
            return Double.longBitsToDouble(entry.bits());
        }
        // ★ 量化点采样：用【网格中心】而非调用者坐标 ⇒ 同一单元内所有调用得到同一值
        //   （避免"同单元不同点算出不同值"导致缓存值与直接计算不一致）。
        double sx = (qx + 0.5) * QUANT, sz = (qz + 0.5) * QUANT;
        double cBiased = continent.sample(sx, sz) - continentBias;
        TectonicField.Sample ts = tectonic.sample(sx, sz);
        int layer = strata.layerAt(sx, sz);
        double v = StratumField.resistanceAt(ts, TectonicField.shellFromC(cBiased) > 0.5, layer);
        hrEntries.set(slot, new KeyedValue(key, Double.doubleToLongBits(v)));
        return v;
    }

    /** 清空岩性硬度缓存（由 {@code clearEqCache} 统一调用）。按引用置 null 清空。 */
    private void clearRockResistanceCache() {
        for (int i = 0; i < HR_CACHE_SIZE; i++) hrEntries.set(i, null);
    }

    /** 轻量地形 e 的【实际计算】（跳过气候/分类/height 映射/shape 赋值）。
     *  坐标语义 = wu（2026-08-10 wu 化，见 {@link #sampleCore}）。
     *  <p>★ 2026-09-11：外部请调用带缓存的 {@link #terrainEQuick}。</p> */
    private double terrainEQuickCompute(double wx, double wz) {
        double sx = wx, sz = wz;

        // 1. 大陆性 c
        double c = continent.sample(sx, sz);
        double cBiased = c - continentBias;

        // 2. 海洋基面
        double eBase = heightCurve.eFromC(cBiased);
        double depthMod = 0.6 + (1.0 - smoothstep(-0.6, -0.2, eBase)) * 1.2;
        double seabed = seabedAmp * depthMod * seaBed.sample(sx, sz);
        double eOcean = (eBase + seabed) * oceanDepthFactor;

        // ★ 2026-09-13 Phase T6：与 sampleCore 同序 —— 构造采样提前，供海洋特征
        //   （洋中脊门控 / 火山弧）与 T1 权重调制复用（保证 tile 与直接采样逐位一致）。
        TectonicField.Sample tsQ = TECTONIC_ENABLED ? tectonic.sample(sx, sz) : null;

        // 3. 海洋特征
        double arcProfQ = tsQ != null ? tectonic.oceanProfile(tsQ) : 0.0;
        OceanFeatures.FeatureResult oceanFeat =
            oceanFeatures.compute(sx, sz, Math.min(eOcean, 0.0), cBiased, tsQ, arcProfQ);
        eOcean += oceanFeat.total;

        // 4. 类型混合（Voronoi 场）
        TerrainCharacterField.BlendResult cellBlend = typeLandShape.sampleBlend(sx, sz);
        // ★ 地质 Phase T1：与 sampleCore 相同的构造调制（复用上方已采样的 tsQ）
        if (tsQ != null) applyTectonicWeights(cellBlend.typeWeights, tsQ, sx, sz, cBiased);

        // 5. 海岸线扭曲
        double cEdge = cBiased + coastline.warpDisplacement(sx, sz, cBiased);

        // 6. 全类型混合 e
        double eLand = typeLandShape.sample(cellBlend, sx, sz, cEdge);

        // 7. 特征增量（★ P4：传入构造采样，使陆地火山沿俯冲带弧轴成链）
        //    ★ 与 sampleCore 一致：海陆门控改用【与地形同源】的 landFactor（见 sampleCore 注释）
        double eLandBaseQ = eLand;
        double landFactorQ = smoothstep(-0.01, 0.01, eLandBaseQ);
        LandFeatures.FeatureResult landFeat = landFeatures.compute(sx, sz, tsQ);
        double oceanW = cellBlend.typeWeights[TerrainClass.OCEAN.ordinal()]
            + cellBlend.typeWeights[TerrainClass.DEEP_OCEAN.ordinal()];
        // ★ 2026-09-14 P5：与 sampleCore 同源 —— 中心因子已内建于 LandFeatures ⇒ 直接相加
        eLand += landFeat.total;

        // ★ 地质 Phase T5：与 sampleCore 相同的构造形变（保证 tile 与直接采样一致）
        if (DEFORM_ENABLED) {
            TectonicField.Sample tsD = tsQ != null ? tsQ : tectonic.sample(sx, sz);
            eLand += deform.offset(tsD, sx, sz);
        }

        // ★ P0.5 海床护栏：与 sampleCore 逐位一致（必须同样在 T5 形变【之后】）
        double oceanFeatWQ = oceanFeat.total * (1.0 - landFactorQ);
        if (oceanFeatWQ > 0.0) {
            double capQ = -eLand - SEABED_MARGIN;
            oceanFeatWQ = capQ <= 0.0 ? 0.0 : TectonicField.smoothMin(oceanFeatWQ, capQ, SEABED_SOFT_SAT);
        }

        // 8. 海陆统一 e（★ P0.5：用受海床护栏约束的 oceanFeatWQ，与 sampleCore 一致）
        return softCapLandE(eLand + oceanFeatWQ);
    }

    /**
     * ★ 2026-09-12 地质 Phase T1：<b>构造决定地形类型</b>（而非"构造推高地形"）。
     *
     * <p>按板块边界类型调制 {@code typeWeights}，让山脉/海沟/裂谷/洋脊沿<b>地质边界</b>分布：
     * <ul>
     *   <li><b>汇聚</b>：陆地→提升 MOUNTAINS（造山带）；海洋→提升 DEEP_OCEAN（俯冲海沟）</li>
     *   <li><b>离散</b>：陆地→提升 BASIN（裂谷）；海洋→提升 OCEAN（洋中脊，浅于深海）</li>
     *   <li><b>走滑 / 内部</b>：不调制（worldgen 亦无垂向贡献）</li>
     * </ul>
     *
     * <p><b>为何用权重调制而非直接加高程偏置</b>：直接抬升 {@code e} 会连锁增强地形雨
     * （PrecipField 的 orographicGain 基于高度差），推高全局降水并稀释 Phase C
     * 「干旱区河细」的区分度（实测 head 最干桶 0.922→0.959）。改为调制类型权重后，
     * 山脉由<b>既有 MOUNTAINS 配方</b>生成，不引入额外高度偏置 → 不干扰气候/水文标定。
     *
     * <p>调制后重新归一化，保证权重和为 1（{@code dominantFromWeights} 依赖此性质）。
     *
     * <p>★ 2026-09-13 Phase T6：改为<b>接收已采样的 {@code ts}</b>（调用方在海洋特征之前
     * 已采样一次并复用），避免同一位置重复采样构造场。</p>
     */
    private void applyTectonicWeights(double[] w, TectonicField.Sample ts, double sx, double sz,
                                      double cBiased) {
        // ★ Phase T2：汇聚造山带按走向串珠化（独立山峰），离散保持连续（真实裂谷是线状）
        double g = tectonic.boundaryStrengthChained(ts, sx, sz);
        // ★ 阈值必须低到不可见：任何提前 return 都是地形跳变源（环状细线/串珠虚线）。
        if (g <= 1e-6) return;

        // ★★ 2026-09-13 Phase T7（P0）：分支判据由【形态学 landW/oceanW】改为
        //    【地质学板块壳属性 shellS】★★
        //
        //   见 TectonicField.plateShell 的长注释。核心差异：
        //     · 旧：landW/oceanW 来自【类型权重场】（形态学）—— 与板块无关，
        //           且与 c 场可互相矛盾（实测"火山弧在 eLand≈0 处造陆"即源于此）。
        //     · 新：shellS 来自【该点所属板块的壳属性】（由 c 场在板块种子处取值推导）
        //           —— 这才是参考项目 worldgen 的 (陆,陆)/(陆,洋)/(洋,洋) 分支依据。
        //
        //   地质语义随之正确（对齐参考项目 boundary_profile）：
        //     陆-陆汇聚 → 两侧 shell≈1 → 都造山；陆-洋汇聚 → 陆侧造山 + 洋侧海沟；
        //     洋-洋汇聚 → 都海沟。离散同理（陆壳裂谷 / 洋壳洋中脊）。
        //   ★ 关键收益：陆-洋汇聚不再"两边都造山"，而是陆侧造山、洋侧海沟。
        //
        //   ★ 为何不会产生"直线网伪影"（实测已验证）：
        //     shellS 直接由【连续的 c 场】得出（多倍频 FBM，处处 C¹）——
        //     **与海陆同源**且**绝无阶跃**。
        //     ※ 曾尝试"壳属性 = 所属板块的常数"（更贴近参考项目的 is_continental[pid]），
        //       被 TectonicProbe[8] **实测否决**：本项目 PLATE_SPACING=2000wu 而 c 波长
        //       ≈4000wu ⇒ 一个大陆仅约 2 个板块（参考项目 ~10 个）⇒ 相邻板块壳属性差
        //       P50=0.41 / 48.4% 是"一陆一洋" ⇒ 等效阶跃 96 块 = 必然的 Voronoi 直线网。
        //       详见 TectonicField.shellFromC 的注释。
        //
        //   （旧注释保留以免后人误改回：用 landW/oceanW 分叉 = 让形态学冒充地质学。）
        double shellS = TectonicField.shellFromC(cBiased);   // 0=洋壳 1=陆壳（连续、与海陆同源）
        // ★ 2026-09-12 修复（伪影）：改用【连续应力】stress 加权，取代 switch(btype)。
        //   btype 在类型边界跳变 → 权重调制骤变 → eLand 骤变 → 线状疤痕。
        //   stress ∈[-1,1] 连续 → 过渡平滑。
        // ★ 2026-09-12 第五次伪影修复：Math.max(0,·) → 平滑正部，并**去掉 if 分支**。
        //   原写法沿 stress=0 等值线切换公式 → 一阶不连续 → 地形折痕（笔直断裂线）。
        //   改后两个分支恒执行（cw/dw 恒>0），公式处处一致 → 无折痕。
        double cw = TectonicField.smoothPos(ts.stress(), TectonicField.STRESS_POS_EPS);
        double dw = TectonicField.smoothPos(-ts.stress(), TectonicField.STRESS_POS_EPS);
        double addC = TectonicField.CONVERGENT_BOOST * g * cw;   // 汇聚 → 造山（陆壳）/ 海沟（洋壳）
        w[TerrainClass.MOUNTAINS.ordinal()] *= 1.0 + addC * shellS;
        w[TerrainClass.DEEP_OCEAN.ordinal()] *= 1.0 + addC * (1.0 - shellS);
        double addD = TectonicField.DIVERGENT_BOOST * g * dw;    // 离散 → 裂谷（陆壳）/ 洋中脊（洋壳）
        w[TerrainClass.BASIN.ordinal()] *= 1.0 + addD * shellS;
        w[TerrainClass.OCEAN.ordinal()] *= 1.0 + addD * (1.0 - shellS);
        double sum = 0.0;
        for (double v : w) sum += v;
        if (sum > 1e-15) {
            for (int i = 0; i < w.length; i++) w[i] /= sum;
        }
    }

    /** 纯陆地形态 eLand（侵蚀边际采样用，不含气候/分类）。 */
    public double landE(double wx, double wz) { return sampleCore(wx, wz).eLand; }

    /** 地形类型连续权重（诊断探针按类型分桶统计用）。 */
    public double[] typeWeightsAt(double wx, double wz) { return sampleCore(wx, wz).typeWeights; }

    // ===== 侵蚀 tile 缓存（超分辨率架构：spacing=4 粗采 + 双三次插值升采样，仿 6 月备份 70cd037） =====

    /** 每 tile 中心有效区边长（wu）。2026-08-10 wu 化：原 3×16 块（3 chunk 绑定）→ 48 wu 独立网格，
     *  chunk 覆盖数由 horizontalScale 决定（HS=1 → 3 chunk，HS=2 → 6 chunk），引擎不再感知块。 */
    private static final int ERODE_TILE_CENTER = 48;
    /** 边缘填充（wu，侵蚀 brush 上下文 + 接缝消除；数值保持 40 不变） */
    private static final int ERODE_TILE_BORDER = 40;
    /** tile 总边长（wu）：48 + 40×2 = 128（数值与 6 月备份一致） */
    private static final int ERODE_TILE_SIZE = ERODE_TILE_CENTER + ERODE_TILE_BORDER * 2;
        /** 粗采间距（spacing=4：128/4=32×32=1024 次 terrainE） */
        private static final int ERODE_SAMPLING_SPACING = 4;
        /** 骨架层（脊-谷条纹）采样间距：比主 bicubic 流程更密(2)，恢复被低分辨率稀释的坡度 → combiMask 正常触发 */
        private static final int RIDGE_SKELETON_SPACING = 2;
        /** 低分辨率网格边长 */
        private static final int ERODE_LOW_RES = ERODE_TILE_SIZE / ERODE_SAMPLING_SPACING;
    /** 缓存条目数（256 条目 ≈ 全部出生区域 tiles 常驻，无 LRU 驱逐） */
    // ★ 2026-09-17：256 → 512。原因：blendTileDelta 现在对缺失邻居【同步生成】
    //   （确定性修复），容量不足会造成"刚生成→被驱逐→再生成"的抖动 ——
    //   那正是 2026-08-14 把窥探改回同步时"慢到像崩溃"的真凶。加大容量后
    //   工作集（本 tile + 8 邻预热 + 3 个 blend 邻居）能常驻。
    //   内存：单 tile ≈ 4 个 48×48 float 数组 ≈ 38KB ⇒ 512 ≈ 19MB，可接受。
    private static final int ERODE_TILE_CACHE_SIZE = 512;
    /** tile 边界 blend 起始列/行（chunk 内部）。16-BLEND_START=10 块 blend 范围（原 4 块太窄，
     *  独立粒子模拟 delta 差异大时 smoothstep 不够 → 网格感）。 */
    private static final int BLEND_START = 6;

    /** 诊断日志（[ErosionDIAG] 前缀，latest.log 可查） */
    private static final Logger LOGGER = LogManager.getLogger("geogenesis");

    private final ConcurrentHashMap<Long, ErosionTileResult> erosionTileCache = new ConcurrentHashMap<>(ERODE_TILE_CACHE_SIZE);
    /**
     * 各入口共用 tile 单飞表：putIfAbsent 仅占位，生成不持 CHM bin 锁。
     * 取得占位后再查缓存；先发布缓存，再 complete，最后撤占位。
     * singleflight 回归探针覆盖完成回调与过期 miss 两种竞态。
     * 旧 PERF 的成对日志是 logger/stdout 双打印，不能据此认定重复生成。
     */
    private final ConcurrentHashMap<Long, java.util.concurrent.CompletableFuture<ErosionTileResult>>
            erosionTilesInFlight = new ConcurrentHashMap<>();

    /** 侵蚀 tile 缓存命中统计（P0-3 埋点）。 */
    private final CacheStats tileCacheStats = new CacheStats("erosionTile");
    // 【性能测量·默认关】命中/驱逐的既有口径就在上面这两个计数器（tileCacheGet 太热 ⇒ 刻意不加字符串计数）。
    //   HydrologyMetrics（-Dgeogenesis.hydrologyMetrics=true）只补三样：
    //   inflight 等待 hydro.tile.wait + cache.EROSION_TILE.WAIT、实体生成 hydro.tile.solve + .COMPUTE、
    //   驱逐 .EVICT —— 用于把"等待别人"与"真在算"分开。
    /** LRU 逻辑时钟（P0-3）：每次访问自增，驱逐时取最小者。 */
    private final AtomicLong tileAccessClock = new AtomicLong();
    /** 侵蚀配置指纹快照（2026-08-06）：配置改动 → 侵蚀/河流 tile 缓存失效，避免旧配置结果被复用 */
    private long lastCfgFingerprint = Long.MIN_VALUE;

    /**
     * 侵蚀 tile 结果（2026-08-02 分级流水线，2026-08-09 内联终态发布）：
     * <ul>
     *   <li>base — 侵蚀前原貌（bicubic 插值场，L3 定稿）</li>
     *   <li>postErosion — 侵蚀后快照（L3 定稿，<b>永不改变</b>）</li>
     *   <li>delta — 叠加量（侵蚀增量，generateErosionTile 内一次写全，
     *       发布后永不再变；extractFromTile 读它 → 任意时序一致，无断裂）</li>
     * </ul>
     */
    static class ErosionTileResult {
        float[][] base;
        float[][] delta;
        float[][] postErosion;
        float[][] discharge; // 液滴汇聚场（粒子路径重叠计数；侵蚀副产品，供未来河流/诊断用）
        int tileCX, tileCZ;
        int originX, originZ;
        int erosionRound; // 版本号（保留字段，诊断用）
        /** ★ 2026-09-11 P0-3：LRU 驱逐用的"最近访问"逻辑时钟（越小越久未用）。 */
        volatile long lastAccess;
    }

    /**
     * 获取或生成侵蚀 tile delta（终态 = 侵蚀增量，2026-08-09 重构）。接受 chunk 坐标，内部自动分组为 3×3 tile。
     *
     * <p><b>确定性生成（2026-08-01）</b>：flat 全源 terrainE + 粗骨架（无邻居依赖）→
     * tile 结果只与自身世界坐标有关，缓存淘汰后重建结果不变 → 相邻 chunk 无缝。</p>
     *
     * <p><b>终态发布（2026-08-09）</b>：L1 河流已内联进 {@link #generateErosionTile}，
     * delta 一次写全（侵蚀+雕刻）后永不再变。本 tile 同步生成（调用线程直接算，绝不返回空），
     * 邻居 fire-and-forget 后台补全 + extractFromTile 消费时懒生成（终态安全，结果确定相同）。</p>
     *
     * <p>StreamTracer 自包含：界内读本 tile postErosion，出界统一 terrainEQuick（纯世界坐标函数），
     * 雕刻全在 tile 内 → L1 无邻居缓存依赖 → 任意生成时序下结果一致，无断裂。</p>
     */
    /**
     * 取侵蚀 tile（wu 坐标语义，2026-08-10 wu 化）。入参为 wu 坐标（MC 门面已 ÷horizontalScale）。
     * tile 网格 = 48 wu 中心区对齐（floorDiv → 与 HS 无关的固定 wu 网格，HS=1 时与旧 3-chunk 网格一致）。
     */
    public float[][] getErosionTile(int wuX, int wuZ) {
        if (morphBase) return new float[ERODE_TILE_SIZE][ERODE_TILE_SIZE];
        int tileCX = Math.floorDiv(wuX, ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int tileCZ = Math.floorDiv(wuZ, ERODE_TILE_CENTER) * ERODE_TILE_CENTER;

        GeoGenesisConfig cfg = GeoGenesisConfig.INSTANCE;
        // 2026-08-06 修复：侵蚀 tile 缓存随配置失效——原只在 seed() 时 clear()，配置改动
        // （开/关骨架、侵蚀/河流参数）后旧 tile 仍被复用 → "实测没变化"实锤根因。
        long fg = cfg != null ? GeoGenesisConfig.configFingerprint() : 0L;
        if (fg != lastCfgFingerprint) {
            erosionTileCache.clear();
            lastCfgFingerprint = fg;
        }
        boolean erosionOn = cfg != null ? cfgBool(cfg.erosionEnabled, true) : true;
        // 2026-08-06 修复：骨架（脊-谷条纹）与液滴侵蚀解耦——仅开骨架(erosionRidgeEnabled)
        // 而 erosionEnabled=false 时，骨架也必须生效（原门控连带跳过 → 地形零变化）。
        boolean ridgeOn = cfg != null ? cfgBool(cfg.erosionRidgeEnabled, true) : true;
        if (!erosionOn && !ridgeOn) {
            return new float[ERODE_TILE_SIZE][ERODE_TILE_SIZE];
        }

        // L3+L1：邻居惰性化 + 本 tile 同步（2026-08-09 深夜 3 重构 + 同日修复）。
        // 原实现：同步 await 8 邻居完成（串行/并行都锁死并行度——chunk(0,0) 冷启动 7s 实锤）。
        // 重构：1) 邻居 fire-and-forget 提交后台池（putIfAbsent 去重，幂等，跳过自己）
        //       2) 本 tile 直接同步计算（含 L1 河流，终态发布）→ 调用方立即拿到真 delta
        //       3) blend 阶段（extractFromTile）读邻居 null 时 → 同步懒生成该邻居（只算需要的 1-2 个）
        // 效果：chunk(0,0) 7s → 本 tile ~0.7s + 消费时懒邻居 ~0.7-1.4s
        //
        // 邻居预热只在本入口发起；generateErosionTile 不提交任何邻居任务。
        for (int dz = -1; dz <= 1; dz++) {
            for (int dx = -1; dx <= 1; dx++) {
                if (dx != 0 || dz != 0) {
                    scheduleTilePreheat(tileCX + dx * ERODE_TILE_CENTER,
                            tileCZ + dz * ERODE_TILE_CENTER);
                }
            }
        }
        // 本 tile：占位式生成（★ 2026-10-10 替换 computeIfAbsent）
        //   原 computeIfAbsent 会在整个生成期间持有 CHM bin 锁（100~700ms）⇒ 后到线程阻塞
        //   （日志口径：等待被记进 EXTRACT、不算 TILEGEN）。
        // 本入口与 blend/窗口预热共用单飞发布；生成函数本身无邻居依赖。
        long tw0 = com.geogenesis.diagnostics.WorldGenProfiler.begin();
        ErosionTileResult res = getOrGenTileUnchecked(tileCX, tileCZ);
        com.geogenesis.diagnostics.WorldGenProfiler.endIfSlow(
                com.geogenesis.diagnostics.WorldGenProfiler.Stage.TILEWAIT, tw0, 1_000_000L);
        return res == null ? null : res.delta;
    }

    /**
     * 侵蚀 tile 生成/复用（<b>占位式，不持 bin 锁</b>）—— 供 {@link #erosionDeltaE} 内部
     * 与预热路径共用。generateErosionTile 不请求其它 tile，因此不会形成等待环。
     *
     * <p>语义与 {@code computeIfAbsent} 等价但：① 只对"创建占位"上锁（微秒级）；
     * ② 生成在锁外；③ 并发线程 join 复用同一结果（不重复计算）。
     * 失败/中断返回 {@code null}。</p>
     */
    private ErosionTileResult getOrGenTileUnchecked(int tileCX, int tileCZ) {
        long k = tileKey(tileCX, tileCZ);
        ErosionTileResult r = tileCacheGet(k);
        if (r != null) return r;
        java.util.concurrent.CompletableFuture<ErosionTileResult> mine =
                new java.util.concurrent.CompletableFuture<>();
        java.util.concurrent.CompletableFuture<ErosionTileResult> existing =
                erosionTilesInFlight.putIfAbsent(k, mine);
        if (existing != null) {
            // 【测量】inflight 等待（别人正在生成同一 tile）：只补 WAIT 计数与等待时长；
            //   命中率仍由既有 tileCacheStats 记 —— 刻意【不】在 tileCacheGet 里加字符串计数（太热）。
            HydrologyMetrics.cache(Cache.EROSION_TILE, Outcome.WAIT);
            var waitScope = HydrologyMetrics.begin("hydro.tile.wait", tileCX, tileCZ);
            long waitStart = com.geogenesis.diagnostics.WorldGenProfiler.stutterEnabled()
                    ? System.nanoTime() : 0;
            try {
                return existing.join();
            } catch (java.util.concurrent.CompletionException ce) {
                HydrologyMetrics.add("tile.wait.failed", 1L);
                return null;
            } finally {
                HydrologyMetrics.end(waitScope);
                if (waitStart != 0 && System.nanoTime() - waitStart > 100_000_000L) {
                    com.geogenesis.diagnostics.WorldGenProfiler.stutterLog("B", "tile-wait",
                            "tile=" + tileCX + "," + tileCZ + " ms=" + (System.nanoTime() - waitStart) / 1e6);
                }
                // #region agent log: L5 每个冷tile的刚需等待，确认预热与采样同序的重叠
                if (waitStart != 0) com.geogenesis.diagnostics.WorldGenProfiler.stutterLog("L5",
                        "tile-claim-wait-" + tileCX + "-" + tileCZ,
                        "ms=" + (System.nanoTime() - waitStart) / 1e6);
                // #endregion
            }
        }
        try {
            // 首次 miss 与获得占位之间，前一个生成者可能已经发布并退出。
            r = tileCacheGet(k);
            if (r == null) {
                if (Thread.currentThread().isInterrupted()) throw new CancellationException();
                // 【测量】实体生成（一次真实 tile 求解）：成功才记 COMPUTE（取消/失败另计）。
                var solveScope = HydrologyMetrics.begin("hydro.tile.solve", tileCX, tileCZ);
                try {
                    r = generateErosionTile(tileCX, tileCZ);
                    HydrologyMetrics.cache(Cache.EROSION_TILE, Outcome.COMPUTE);
                } finally {
                    HydrologyMetrics.end(solveScope);
                }
                r.lastAccess = tileAccessClock.incrementAndGet();
                erosionTileCache.putIfAbsent(k, r);
                pruneErosionCache();
            }
            // 缓存先发布，再通知等待者，最后撤占位。
            mine.complete(r);
            return r;
        } catch (CancellationException e) {
            HydrologyMetrics.add("tile.solve.cancelled", 1L);
            mine.completeExceptionally(e);
            return null;
        } catch (RuntimeException | Error e) {
            HydrologyMetrics.add("tile.solve.failed", 1L);
            mine.completeExceptionally(e);
            throw e;
        } finally {
            erosionTilesInFlight.remove(k, mine);
        }
    }

    /**
     * 生成侵蚀 tile：spacing=4 粗采 → 全局对齐 Catmull-Rom 双三次插值升采样
     * → 确定性 flat 缓冲区（全源 terrainE + 粗骨架，世界坐标对齐）
     * → 物理液滴侵蚀 → delta + postErosion 缓存。
     */
    private ErosionTileResult generateErosionTile(int tileCX, int tileCZ) {
        long tStart = System.nanoTime();   // PERF 诊断（2026-08-09，优化后保留观察）
        GeoGenesisConfig cfg = GeoGenesisConfig.INSTANCE;
        boolean erosionOn = cfg != null ? cfgBool(cfg.erosionEnabled, true) : true;
        if (PROBE_SKELETON_ONLY) erosionOn = false;   // ★ 2026-08-12 探针诊断：只跑骨架（分离液滴贡献）
        double erosionStr = cfg != null ? cfgDbl(cfg.erosionStrength, 1.0) : 1.0;
        // 骨架开关独立于液滴（2026-08-06：仅开骨架时也要生效）
        RidgeValleyErosion.RidgeConfig rcfg0 = cfg != null
            ? com.geogenesis.config.RidgeConfigAdapter.fromConfig(cfg)
            : new RidgeValleyErosion.RidgeConfig();
        // hs 以 TerrainParams 为准覆盖（适配器读取传入配置；未加载时回退 1.0）
        rcfg0.horizontalScale = (float) params.horizontalScale();
        // 2026-08-13：探针/测试可覆盖骨架参数（无 Forge 环境时对齐 toml 真实配置）
        final RidgeValleyErosion.RidgeConfig rcfg = probeRidgeConfig != null ? probeRidgeConfig : rcfg0;
        boolean ridgeOn = rcfg.enabled;

        long tBaseEnd = System.nanoTime();  // PERF：base 采样结束
        long tStage3 = System.nanoTime();   // PERF：液滴阶段开始标记（防未进入 if 分支）
        long tStage4 = System.nanoTime();   // PERF：液滴阶段结束标记（防未进入 if 分支）
        // tileCX 已是 48 对齐 wu 坐标（wu 化后不再 ×16 换算）
        int originX = tileCX - ERODE_TILE_BORDER;
        int originZ = tileCZ - ERODE_TILE_BORDER;

        // 0) base 提前计算（2026-08-09 无伤优化：原第 3 步移前，粗采/骨架/骨架 flat 复用）
        //    保存 terrainE 原貌（用于算 delta）：同源保证相邻 tile delta 一致。
        //    提前后粗采（第 1 步）与骨架（第 2.5 步）在 base 覆盖区直接复用同值数组，
        //    省 ~5,249 次 terrainEQuick/tile（16,384+1,296+12,769 → 16,384+272+8,544）。
        //    值恒等式：base[x][z] = max(terrainEQuick, -0.05)，与粗采/骨架旧逻辑完全一致 → 输出不变。
        int N0 = ERODE_TILE_SIZE;
        float[][] base = new float[N0][N0];
        // ★ 2026-08-14 恢复并行（安全版：ForkJoinPool.commonPool work-stealing，见 parallelRows
        //   ——曾 TILE_SAMPLER 池 + latch.await 池饥饿死锁；曾串行恢复正确性但性能降）
        parallelRows(N0, z -> {
            for (int x = 0; x < N0; x++) {
                base[z][x] = (float) Math.max(terrainEQuick(originX + x, originZ + z), -0.05);
            }
        });
        tBaseEnd = System.nanoTime();   // PERF：base 采样结束

        // 1) spacing=4 粗采（全局对齐网格，扩展 2 格以消除 Catmull-Rom 边沿退化）
        int spacing = ERODE_SAMPLING_SPACING;
        int lowRes = ERODE_LOW_RES; // = 32
        int gridExtra = 2;
        int extendedLowRes = lowRes + gridExtra * 2; // = 36
        int alignedStartX = Math.floorDiv(originX, spacing) * spacing - gridExtra * spacing;
        int alignedStartZ = Math.floorDiv(originZ, spacing) * spacing - gridExtra * spacing;

        // ★ 2026-08-14 恢复并行（安全版，见 parallelRows）
        float[][] lowResBuf = new float[extendedLowRes][extendedLowRes];
        final float[][] lrb = lowResBuf; // lambda 捕获 final 引用（lowResBuf 后续重赋值）
        parallelRows(extendedLowRes, tz -> {
            for (int tx = 0; tx < extendedLowRes; tx++) {
                int wx = alignedStartX + tx * spacing;
                int wz = alignedStartZ + tz * spacing;
                if (wx >= originX && wx < originX + N0 && wz >= originZ && wz < originZ + N0) {
                    lrb[tz][tx] = base[wz - originZ][wx - originX];
                } else {
                    lrb[tz][tx] = (float) Math.max(terrainEQuick(wx, wz), -0.05);
                }
            }
        });

        // 备份未平滑副本 B（粗侵蚀骨架作用于真实地形，不走 step1.5 平滑）
        float[][] rawLowRes = new float[extendedLowRes][extendedLowRes];
        for (int i = 0; i < extendedLowRes; i++)
            System.arraycopy(lowResBuf[i], 0, rawLowRes[i], 0, extendedLowRes);

        // 1.5) 粗网格 Gaussian 低通滤波：消除控制点对齐噪声
        //     kernel = [1,2,1; 2,4,2; 1,2,1] / 16（σ≈0.85 grid cells ≈ 3.4 blocks）
        //     保留最外层 1 格作为 bicubic 边界条件（扩展带原值）
        float[][] smoothBuf = new float[extendedLowRes][extendedLowRes];
        for (int tz = 0; tz < extendedLowRes; tz++)
            System.arraycopy(lowResBuf[tz], 0, smoothBuf[tz], 0, extendedLowRes);
        for (int tz = 1; tz < extendedLowRes - 1; tz++) {
            for (int tx = 1; tx < extendedLowRes - 1; tx++) {
                float sum = lowResBuf[tz-1][tx-1] + lowResBuf[tz-1][tx]*2 + lowResBuf[tz-1][tx+1]
                          + lowResBuf[tz][tx-1]*2   + lowResBuf[tz][tx]*4 + lowResBuf[tz][tx+1]*2
                          + lowResBuf[tz+1][tx-1] + lowResBuf[tz+1][tx]*2 + lowResBuf[tz+1][tx+1];
                smoothBuf[tz][tx] = sum / 16f;
            }
        }
        lowResBuf = smoothBuf;

        // 2) Catmull-Rom 双三次插值升采样到全分辨率
        int N = ERODE_TILE_SIZE;
        float[][] tile = bicubicUpsampleAligned(lowResBuf, extendedLowRes, spacing,
            alignedStartX, alignedStartZ, originX, originZ, N);

        long tStage1 = System.nanoTime();   // PERF：base+粗采+升采样结束
        // 2.5) 粗侵蚀骨架（脊-谷条纹滤镜）—— 作用于独立更密网格（RIDGE_SKELETON_SPACING=2）
        //       根因：主 bicubic 流程 spacing=4 把地形坡度稀释成 Δe/16，远低于 combiMask 阈值
        //       (rounding·onset≈0.0125) → combiMask 恒≈0 → 条纹被完全淡出（山谷不可见）。
        //       用 spacing=2 采样真实地形恢复坡度 → combiMask 在真实陡坡正常触发 → 脊-谷骨架成形。
        //       纯局部算子（每点独立 evaluate，世界坐标对齐）→ 跨 tile 无缝；陆地 mask 保护海洋深度一致性。
        float[][] coarseDeltaLR = null; // 低分辨率骨架网格（flat 全源双线性采样用）
        int skelSpacing = RIDGE_SKELETON_SPACING;
        // 2026-08-10: 4→8——骨架 evaluateCell 新增局部窗口抬升衰减（LIFT_WINDOW_R=8 格），
        // 扩展区必须容纳窗口使 flat 采样区内所有点的窗口读取落在已填充网格内（clamp 兜底）。
        int skelExtra = 8;
        int skelCover = ERODE_TILE_SIZE + 2 * (ERODE_TILE_BORDER + skelExtra * skelSpacing);
        int skelExtLR = (int) Math.ceil((double) skelCover / skelSpacing) + 1;
        int skelStartX = Math.floorDiv(originX - skelExtra * skelSpacing, skelSpacing) * skelSpacing;
        int skelStartZ = Math.floorDiv(originZ - skelExtra * skelSpacing, skelSpacing) * skelSpacing;
        // 2026-08-06 修复：骨架计算不再被液滴开关(erosionOn)门控，仅开骨架也生效
        if (erosionOn || ridgeOn) {
            if (ridgeOn) {
                double seaE = heightCurve.seaE();
                float[][] skelGrid = new float[skelExtLR][skelExtLR];
                // 2026-08-06 用户决策：骨架完全无类型限制（纯噪声地形上直接雕刻）。
                // 移除 typeMod 类型调制——原按类型权重在过渡带连续渐变 → 类型过渡带出现
                // 人为强度渐变带（用户反馈"骨架与地形类型打架，过渡带变明显"）。
                // 平原条纹弱由坡度自然控制（combiMask 坡度触发，平原坡度小→条纹弱），无需人工调制。
                // ★ 2026-08-14 恢复并行（安全版，见 parallelRows；曾串行——TILE_SAMPLER
                //   池 + latch.await 池饥饿死锁的替代方案）
                parallelRows(skelExtLR, tz -> {
                    for (int tx = 0; tx < skelExtLR; tx++) {
                        int wx = skelStartX + tx * skelSpacing;
                        int wz = skelStartZ + tz * skelSpacing;
                        if (wx >= originX && wx < originX + N0 && wz >= originZ && wz < originZ + N0) {
                            skelGrid[tz][tx] = base[wz - originZ][wx - originX];
                        } else {
                            skelGrid[tz][tx] = (float) Math.max(terrainEQuick(wx, wz), -0.05);
                        }
                    }
                });
                final float[][] deltaLR = new float[skelExtLR][skelExtLR];
                parallelRows(skelExtLR, tz -> {
                    for (int tx = 0; tx < skelExtLR; tx++) {
                        deltaLR[tz][tx] = RidgeValleyErosion.evaluateCell(
                            skelGrid, tx, tz, skelExtLR, skelSpacing, skelStartX, skelStartZ,
                            (float) seaE, rcfg);
                    }
                });
                coarseDeltaLR = deltaLR;
            }
        }

        // 3) （已移至第 0 步提前计算 base——粗采/骨架/骨架 flat 复用，省 ~5,249 次 terrainEQuick/tile）
        long tStage2 = System.nanoTime();   // PERF：骨架阶段结束

        // 4) 液滴侵蚀（SH 多轮迭代）+ flat 全源（terrainE + 粗骨架，确定性）
        float[][] dischargeNxN = null; // 液滴汇聚场（粒子路径重叠计数）
        if (erosionOn) {
            double seaE = heightCurve.seaE();
            int pad = 9;
            int bufSize = N + pad * 2;

            // flat 缓冲区全源：terrainEQuick + 粗骨架（双线性插值，世界坐标对齐）。
            // 2026-08-01 确定性化：去掉三区制（邻居 postErosion 依赖）→ tile 结果只
            // 依赖世界坐标，缓存淘汰后重建结果不变 → 相邻 chunk 无缝；收敛循环随之删除。
            // 2026-08-08 优化：内部区域（与 base 重叠）直接复用 base 值，仅 border 调 terrainEQuick。
            // ★ 2026-08-14 卡死修复：flat 构建改**串行**（曾并行 + latch.await → 池饥饿死锁）
            float[] flat = new float[bufSize * bufSize];
            final float[][] cdLR = coarseDeltaLR;
            // ★ 2026-08-14 恢复并行（安全版，见 parallelRows；曾串行）
            final int fPad = pad, fN = N;
            parallelRows(bufSize, fz -> {
                for (int fx = 0; fx < bufSize; fx++) {
                    int worldX = originX + fx - fPad;
                    int worldZ = originZ + fz - fPad;
                    int baseX = fx - fPad;
                    int baseZ = fz - fPad;
                    float val;
                    if (baseX >= 0 && baseX < fN && baseZ >= 0 && baseZ < fN) {
                        val = base[baseZ][baseX];
                    } else {
                        val = (float) Math.max(terrainEQuick(worldX, worldZ), -0.05);
                    }
                    if (cdLR != null) {
                        val += sampleBilinear(cdLR, skelExtLR, skelSpacing,
                                skelStartX, skelStartZ, worldX, worldZ);
                    }
                    flat[fz * bufSize + fx] = val;
                }
            });
            float[] flatPre = flat.clone();

            // 2026-08-02 恢复 discharge 导出：液滴路径重叠计数 = 粒子汇聚数量
            // （河流源头资格；2026-08-01 曾因两套粒子系统停用）
            float[] dischargeBuf = new float[bufSize * bufSize];
            tStage3 = System.nanoTime();   // PERF：液滴阶段开始
            // 2026-08-13：hs 从 TerrainParams 显式传入（引擎不再读全局配置——探针进程无 Forge
            // 环境时 INSTANCE=null→hs 恒 1.0，与游戏 HS=2 不一致）
            erosion.runErosionOnFlat(flat, flatPre, bufSize, N, originX, originZ,
                (float) seaE, (float) erosionStr, dischargeBuf, (float) params.horizontalScale());
            tStage4 = System.nanoTime();        // PERF：液滴阶段结束

            for (int z = 0; z < N; z++)
                for (int x = 0; x < N; x++)
                    tile[z][x] = flat[(z + pad) * bufSize + (x + pad)];
            dischargeNxN = new float[N][N];
            for (int z = 0; z < N; z++)
                for (int x = 0; x < N; x++)
                    dischargeNxN[z][x] = dischargeBuf[(z + pad) * bufSize + (x + pad)];

            // 5) 轻量 Gaussian 已移除：原 bnd 列表 {40,44,48,...,88} 在 tile 内部每 4 块做一次
            //    5 点平滑，形成可见「网格条带」伪影（用户反馈 2026-07-31）。删除以恢复平滑地形。

        } else if (ridgeOn && coarseDeltaLR != null) {
            // 仅骨架模式（液滴关）：tile = base + 骨架 delta（双线性采样，世界坐标对齐）
            for (int z = 0; z < N; z++) {
                for (int x = 0; x < N; x++) {
                    float d = sampleBilinear(coarseDeltaLR, skelExtLR, skelSpacing,
                        skelStartX, skelStartZ, originX + x, originZ + z);
                    tile[z][x] = base[z][x] + d;
                }
            }
        }

        // 6) delta 限幅：仅 per-cell 安全性限制（防单格暴切），不人为加类型/高度钳制。
        //    噪声已经调好地形类型与高度范围，侵蚀只叠加纹理，不该再有硬上限。
        //    0.22：脊谷陡坡脊点 delta 峰值随 strength=0.12 达 ≈0.25，0.22 仅截断 <5% 极值点
        //    （峰侧衰减后峰顶 delta=0 不受影响；截断点分散不形成平台）。
        float maxDeltaPerCell = 0.22f;
        for (int z = 0; z < N; z++) {
            for (int x = 0; x < N; x++) {
                float val = tile[z][x] - base[z][x];
                if (val > maxDeltaPerCell) tile[z][x] = base[z][x] + maxDeltaPerCell;
                else if (val < -maxDeltaPerCell) tile[z][x] = base[z][x] - maxDeltaPerCell;
            }
        }

        // 6.5/6.6) 河流追踪 + 河谷雕刻（L1）：2026-08-09 内联进本方法 → delta 终态发布。
        //   StreamTracer 出界采样统一 terrainEQuick（纯世界坐标函数）→ 任意 tile 追踪结果
        //   一致、无邻居缓存依赖 → 任意生成时序下 delta 相同 → 跨 tile/chunk 无缝。

        // 7) 计算 delta + postErosion（雕刻前快照），构造 ErosionTileResult
        ErosionTileResult res = new ErosionTileResult();
        res.erosionRound = ++erosionRoundCounter;
        res.base = base;
        res.delta = new float[N][N];
        res.postErosion = new float[N][N];
        for (int z = 0; z < N; z++) {
            for (int x = 0; x < N; x++) {
                res.postErosion[z][x] = tile[z][x];
                res.delta[z][x] = tile[z][x] - base[z][x];
            }
        }
        res.discharge = dischargeNxN;
        res.tileCX = tileCX;
        res.tileCZ = tileCZ;
        res.originX = originX;
        res.originZ = originZ;
        // ★ 2026-09-18：精确记账【每一次】tile 生成（下方日志是每 8 次打印 1 次 ⇒ 会低估 8×，
        //   曾据此误判"tile 只跑了 3.8 秒"）。profiler 关闭时零开销。
        com.geogenesis.diagnostics.WorldGenProfiler.record(
                com.geogenesis.diagnostics.WorldGenProfiler.Stage.TILEGEN,
                System.nanoTime() - tStart);
        // #region agent log: 长生成与帧停顿关联
        if (System.nanoTime() - tStart > 500_000_000L) {
            com.geogenesis.diagnostics.WorldGenProfiler.stutterLog("B", "tile-generation",
                    "tile=" + tileCX + "," + tileCZ + " ms=" + (System.nanoTime() - tStart) / 1e6
                            + " cache=" + erosionTileCache.size() + " inflight=" + erosionTilesInFlight.size()
                            + " preheatActive=" + TILE_PREHEATER.getActiveCount()
                            + " preheatQueue=" + TILE_PREHEATER.getQueue().size());
        }
        // #endregion
        if (++perfTileCount % 8 == 1) {
            double ms = (System.nanoTime() - tStart) / 1e6;
            double bMs = (tBaseEnd - tStart) / 1e6;      // base 采样
            double bicMs = (tStage1 - tBaseEnd) / 1e6;   // 粗采+平滑+bicubic 插值
            double skMs = (tStage2 - tStage1) / 1e6;     // 骨架
            double dMs = (tStage4 - tStage3) / 1e6;      // flat+液滴+平滑
            double dltMs = (System.nanoTime() - tStage4) / 1e6; // delta 并行计算
            String perf = String.format("[PERF] erosion tile (%d,%d) took %.0fms [base=%.0f bicubic=%.0f skeleton=%.0f drops=%.0f delta=%.0f]",
                tileCX, tileCZ, ms, bMs, bicMs, skMs, dMs, dltMs);
            LOGGER.info(perf);
            // ★★★ 2026-10-10【删除重复的 System.out.println】★★★
            // 【曾造成诊断假象】同一行既走 log4j（带 `[时间] [线程] [geogenesis/]:` 前缀）
            //   又走 stdout（裸 `[PERF]` 行）⇒ 任何按行统计的工具都会把每个 tile 数成 2 次。
            //   实测：日志 396 行 / 唯一 tile 180 ⇒ 误判"每个 tile 生成 2 次、重复率 100%"，
            //   而真实生成 **198 次 / 唯一 180**（真重复 18 次 = 10%）。
            //   ⇒ 排查性能时该假象会把人引向错误结论（我本人已据此白查一轮）。
            //   log4j 已写入 latest.log ⇒ stdout 重复行只会污染终端与统计。
        }
        return res;
    }

    /** PERF 诊断：侵蚀 tile 耗时打印计数（每 8 个 tile 打印一次，诊断后删除） */
    private static int perfTileCount = 0;

    /** ★ 2026-08-12 探针诊断开关：true 时只跑骨架（分离液滴贡献） */
    public static volatile boolean PROBE_SKELETON_ONLY = false;
    /** 探针诊断：覆盖骨架配置（无 Forge 环境时对齐游戏 toml 参数，2026-08-13） */
    public static volatile RidgeValleyErosion.RidgeConfig probeRidgeConfig = null;

    /**
     * ★ 2026-09-14 P3 受控验证：对<b>同一块地形</b>跑两次侵蚀（一次含硬度耦合、一次不含），
     * 返回两者的 delta 差（侵蚀后 − 侵蚀前）。
     *
     * <h3>为何必须这样做（而非比较"软岩区 vs 硬岩区"的 delta）</h3>
     * <p>软岩（页岩/砂岩）与硬岩（花岗岩/片麻岩）在真实世界里分布在<b>不同的地质环境</b>
     * （裂谷 vs 造山带）⇒ 降水、汇流量、绝对高度、坡度全不同。实测即便按坡度分层，
     * 仍会得出"软岩蚀得更浅"的<b>反向结论</b>（-0.00492 vs -0.00584）—— 那是环境混杂，
     * 不是岩性效应。</p>
     *
     * <p>本方法对<b>同一坐标的同一地形、同一液滴种子</b>分别跑"有/无硬度"两次：
     * 液滴轨迹完全一致，唯一差异是硬度因子 ⇒ 差值即<b>纯岩性效应</b>，无任何混杂。</p>
     *
     * @param hardnessOn true = 含岩性耦合；false = 不含（= P3 之前的行为）
     * @return 侵蚀后 − 侵蚀前 的 delta 场（行主序，边长 = bufSize）
     */
    public float[][] erosionDeltaABForProbe(int originX, int originZ, boolean hardnessOn) {
        int n = ERODE_TILE_SIZE;
        int pad = 9;
        int bufSize = n + pad * 2;
        float[] flat = new float[bufSize * bufSize];
        for (int z = 0; z < bufSize; z++) {
            for (int x = 0; x < bufSize; x++) {
                flat[z * bufSize + x] =
                        (float) Math.max(terrainEQuick(originX - pad + x, originZ - pad + z), -0.05);
            }
        }
        float[] pre = flat.clone();
        java.util.function.DoubleBinaryOperator saved = hardnessOn ? hardnessProviderRef() : null;
        if (!hardnessOn) erosion.setHardnessProvider(null);
        try {
            erosion.runErosionOnFlat(flat, pre, bufSize, n, originX, originZ,
                    (float) heightCurve.seaE(), 1.0f, null, (float) params.horizontalScale());
        } finally {
            if (!hardnessOn && saved != null) erosion.setHardnessProvider(saved);
        }
        return new float[][]{flat, pre};
    }

    /** 诊断用：取回当前注入的硬度提供者。 */
    private java.util.function.DoubleBinaryOperator hardnessProviderRef() {
        return this::rockResistanceAt;
    }

    /** 设置探针骨架配置覆盖（仅探针用，游戏不调用） */
    public void setRidgeConfig(RidgeValleyErosion.RidgeConfig rcfg) {
        probeRidgeConfig = rcfg;
    }

    private static long tileKey(int tileCX, int tileCZ) {
        return ((long) tileCX << 32) | (tileCZ & 0xFFFFFFFFL);
    }

    // ===== Catmull-Rom 双三次插值（全局对齐版，从 6 月备份 70cd037 GeoGenesisGenerator.java 移植） =====

    /**
     * 全局对齐的双三次插值：相邻 tile 在边界处使用相同的控制点 → 插值结果连续。
     *
     * @param lowRes 低分辨率高度图 [lowRes×lowRes]
     * @param lowResSize 低分辨率网格边长
     * @param spacing 低分辨率网格间距（世界单位）
     * @param alignedStartX 全局对齐的低分辨率网格起始 X（世界坐标）
     * @param alignedStartZ 全局对齐的低分辨率网格起始 Z（世界坐标）
     * @param tileStartX 当前 tile 起始 X（世界坐标）
     * @param tileStartZ 当前 tile 起始 Z（世界坐标）
     * @param tileSize 当前 tile 边长（世界单位）
     */
    /** 从粗网格低分场采样单个世界坐标的双线性插值（flat 全源采样，世界坐标对齐 → 跨 tile 一致）。 */
    private static float sampleBilinear(float[][] grid, int extLR, int spacing,
                                         int stX, int stZ, int worldX, int worldZ) {
        float lx = (float) (worldX - stX) / spacing;
        float lz = (float) (worldZ - stZ) / spacing;
        int last = extLR - 1;
        int ix = (int) Math.floor(lx);
        int iz = (int) Math.floor(lz);
        if (ix < 0 || ix >= last || iz < 0 || iz >= last) return 0f;
        float fx = lx - ix, fz = lz - iz;
        float v00 = grid[iz][ix], v10 = grid[iz][ix + 1];
        float v01 = grid[iz + 1][ix], v11 = grid[iz + 1][ix + 1];
        float top = v00 + (v10 - v00) * fx;
        float bot = v01 + (v11 - v01) * fx;
        return top + (bot - top) * fz;
    }

    private static float[][] bicubicUpsampleAligned(float[][] lowRes, int lowResSize, int spacing,
                                                     int alignedStartX, int alignedStartZ,
                                                     int tileStartX, int tileStartZ, int tileSize) {
        // ★ 2026-08-14 恢复并行（安全版，见 parallelRows；曾串行——TILE_SAMPLER 池饥饿的替代方案）
        float[][] out = new float[tileSize][tileSize];
        int lrLast = lowResSize - 1;
        parallelRows(tileSize, fz -> {
            int worldZ = tileStartZ + fz;
            float lz = (float) (worldZ - alignedStartZ) / spacing;
            int iz = (int) lz;
            float tz = lz - iz;
            int z0 = Math.max(0, iz - 1), z1 = Math.min(lrLast, iz),
                z2 = Math.min(lrLast, iz + 1), z3 = Math.min(lrLast, iz + 2);

            for (int fx = 0; fx < tileSize; fx++) {
                int worldX = tileStartX + fx;
                float lx = (float) (worldX - alignedStartX) / spacing;
                int ix = (int) lx;
                float tx = lx - ix;
                int x0 = Math.max(0, ix - 1), x1 = Math.min(lrLast, ix),
                    x2 = Math.min(lrLast, ix + 1), x3 = Math.min(lrLast, ix + 2);

                float r0 = bspline(lowRes[z0][x0], lowRes[z0][x1], lowRes[z0][x2], lowRes[z0][x3], tx);
                float r1 = bspline(lowRes[z1][x0], lowRes[z1][x1], lowRes[z1][x2], lowRes[z1][x3], tx);
                float r2 = bspline(lowRes[z2][x0], lowRes[z2][x1], lowRes[z2][x2], lowRes[z2][x3], tx);
                float r3 = bspline(lowRes[z3][x0], lowRes[z3][x1], lowRes[z3][x2], lowRes[z3][x3], tx);

                out[fz][fx] = bspline(r0, r1, r2, r3, tz);
            }
        });
        return out;
    }

    /** 三次 B-spline 样条插值核：4 个控制点 + 参数 t ∈ [0,1]。
     *  B-spline 是 C2 连续，无 Catmull-Rom 的 overshoot（控制点处过冲伪影），
     *  适合地形插值——平滑且不会产生 chunk 边界周期性阶梯。 */
    private static float bspline(float p0, float p1, float p2, float p3, float t) {
        float t2 = t * t, t3 = t2 * t;
        return ((-p0 + 3f*p1 - 3f*p2 + p3) * t3
               + (3f*p0 - 6f*p1 + 3f*p2) * t2
               + (-3f*p0 + 3f*p2) * t
               + (p0 + 4f*p1 + p2)) * (1f/6f);
    }

    /**
     * 从侵蚀 tile 提取并填充 16×16 chunk cell。
     * 仅把侵蚀增量（侵蚀后 − 侵蚀前）叠加到最终 e，不重写 eLand。
     *
     * <p>海洋侧不再跳过侵蚀——插值场包含海洋真实深度（海山/洋中脊/深海），
     * ErosionEngine 通过 spawn 门控在浅海大陆架和近岸水下自然侵蚀，
     * 海底地形也会被沉积/剥蚀。</p>
     */
    /**
     * 从侵蚀 tile 提取并填充 16×16 chunk cell（wu 插值版，2026-08-10）。
     *
     * <p><b>wu 化核心</b>：块坐标 (bx,bz) → wu (bx/hs, bz/hs) → 落在 tile 网格（48wu 对齐）格点间
     * → 双线性插值读 delta/河数据。HS=1 时 wu=块整数 → 插值退化为直接索引，与旧实现逐位等价。</p>
     *
     * <p>仅把侵蚀增量（侵蚀后 − 侵蚀前）叠加到最终 e，不重写 eLand。海洋侧不跳过侵蚀
     * （插值场含海洋真实深度，ErosionEngine spawn 门控自行处理浅海/近岸）。</p>
     */
    public void extractFromTile(Cell[] cells, int chunkX, int chunkZ) {
        double hs = params.horizontalScale();
        double invHs = (hs > 0.01 && hs != 1.0) ? 1.0 / hs : 1.0;

        for (int lz = 0; lz < 16; lz++) {
            for (int lx = 0; lx < 16; lx++) {
                Cell cell = cells[lx * 16 + lz];
                int bx = chunkX * 16 + lx, bz = chunkZ * 16 + lz;
                double wuX = bx * invHs, wuZ = bz * invHs;
                applyTileDelta(cell, wuX, wuZ); // 含侵蚀增量 + height 重算 + 陆地重分类
            }
        }
    }

    /**
     * wu 坐标处的侵蚀增量（【e 单位】，含 tile 边界对称 blend）——独立可采样接口。
     *
     * <p>★ 供河网微自适应（RiverLineNetwork 选线场）与 {@link #applyTileDelta} 共用：
     * 量纲与 routingE 的 e 场完全一致（tile delta 本就施加于 cell.e），可直接叠加。</p>
     *
     * <p>中断语义：getOrGenTile 同步中断（null）时返回 0（不施加增量），与
     * applyTileDelta 旧语义一致；半成品 tile 不会被缓存。</p>
     */
    public double erosionDeltaE(double wuX, double wuZ) {
        if (morphBase) return 0.0;
        // ★ 2026-08-12 回退（半开归属方案经实测否决——48k+24 线引入新墙，且最初断崖根因是
        // SLOPE 0.0015 微坡墙而非 blend；恢复基线 floorDiv(wu,48) + 右/下缘 blend）
        int tileCX = Math.floorDiv((int) Math.floor(wuX), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int tileCZ = Math.floorDiv((int) Math.floor(wuZ), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        // ★ 2026-09-19 诊断：取 tile 子项（每格第 1 次；含 tileCacheGet + 生成 + 驱逐）
        long tg0 = com.geogenesis.diagnostics.WorldGenProfiler.begin();
        ErosionTileResult res = getOrGenTile(tileCX, tileCZ);
        com.geogenesis.diagnostics.WorldGenProfiler.end(
                com.geogenesis.diagnostics.WorldGenProfiler.Stage.EXGET, tg0);
        if (res == null) return 0.0; // 中断中止（不缓存半成品）→ 本格不施加 delta，chunk 由调用方丢弃/重采
        // ★ 2026-09-19 诊断：blend 子项（每格 1 次）
        long tb0 = com.geogenesis.diagnostics.WorldGenProfiler.begin();
        try {
            return blendTileDelta(res, wuX, wuZ, tileCX, tileCZ, true);   // 主路径：missing ⇒ 现场生成（确定性）
        } finally {
            com.geogenesis.diagnostics.WorldGenProfiler.end(
                    com.geogenesis.diagnostics.WorldGenProfiler.Stage.EXBLEND, tb0);
        }
    }

    /**
     * 【非阻塞】只窥探缓存的侵蚀增量（【e 单位】）——主 tile 未生成时返回 empty。
     *
     * <p>★ 2026-09-11 P0-1 止血：结构/特征放置阶段（STRUCTURE_STARTS 早于 NOISE）会高频调用
     * {@code getBaseHeight}/{@code getBaseColumn}，而 {@link #erosionDeltaE} 内部的
     * {@code getOrGenTile} 会<b>同步生成</b>侵蚀 tile（实测 400~719 ms/个）→ 世界生成卡死。
     * 本方法与 {@link #erosionDeltaE} <b>共用同一套 blend 逻辑</b>（{@link #blendTileDelta}），
     * 唯一差别是主 tile 缺失时【直接放弃】而非触发生成。</p>
     *
     * <p>语义：返回 empty（而非 0.0）以便调用方区分"确实无侵蚀增量"与"尚不可知"。</p>
     */
    public OptionalDouble peekErosionDeltaE(double wuX, double wuZ) {
        if (morphBase) return OptionalDouble.of(0.0);
        int tileCX = Math.floorDiv((int) Math.floor(wuX), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int tileCZ = Math.floorDiv((int) Math.floor(wuZ), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        ErosionTileResult res = tileCacheGet(tileKey(tileCX, tileCZ));
        if (res == null) return OptionalDouble.empty();   // 未生成 → 绝不触发生成
        return OptionalDouble.of(blendTileDelta(res, wuX, wuZ, tileCX, tileCZ, false));
    }

    /**
     * 【非阻塞】侵蚀感知地表高度：基础高度 + 侵蚀增量（增量仅在 tile 已缓存时可得）。
     *
     * <p>用于 {@code getBaseHeight}/{@code getBaseColumn} 等对延迟敏感的查询。
     * <b>保证绝不触发侵蚀 tile 生成</b>；tile 未生成时退化为无侵蚀基础高度
     * （与 {@link #sample} 一致，即 {@code sampleCellLight} 同源）。</p>
     */
    public double sampleHeightNonBlocking(double wuX, double wuZ) {
        if (morphBase) return baseWorld.height(wuX, wuZ);
        Cell cell = sample(wuX, wuZ);
        OptionalDouble d = peekErosionDeltaE(wuX, wuZ);
        double e = d.isPresent() ? softCapLandE(cell.e + d.getAsDouble()) : cell.e;
        return heightCurve.heightFromE(e);
    }

    /** 诊断用：当前侵蚀 tile 缓存条目数（P0-3 埋点；探针据此断言"未触发 tile 生成"）。 */
    public int erosionTileCacheSize() { return erosionTileCache.size(); }

    /** 侵蚀 tile 缓存命中统计（P0-3 埋点）：hit / miss / evict。 */
    public CacheStats tileCacheStats() { return tileCacheStats; }

    /**
     * tile 边界对称 4 向 blend + 角块双线性 —— {@link #erosionDeltaE} 与
     * {@link #peekErosionDeltaE} 共用（公共逻辑抽离，避免两份实现漂移）。
     */
    private double blendTileDelta(ErosionTileResult res, double wuX, double wuZ,
                                  int tileCX, int tileCZ, boolean allowGen) {
        double delta = sampleTileField(res.delta, res.originX, res.originZ, wuX, wuZ);

        // tile 边界对称 4 向 blend + 角块双线性（2026-08-13 重新启用——上次试验参数未对齐
        // 作废：探针 ridge=2.0 vs 游戏 toml 0.75，hs 未参数化；现已全部对齐）。
        // 依据：液滴 delta 场在 tile 左缘（= 模拟域西界，液滴出生/截断不对称）固有突变
        // （x=-288 实测 3.6 块台阶，基础场 0.1 块连续）→ 需要 blend 吸收，单侧 10wu 不够。
        // 邻居权重在边界趋于 1/2，两侧使用同一平均值；角点四 tile 各占 1/4。
        // 原权重趋于 1 会在归属切换时交换两份独立 delta，形成确定性阶跃。
        // X/Z 方向独立 smoothstep 因子 + 4 tile 双线性组合（不顺序覆盖，角块正确）。
        double w = 16 - BLEND_START;
        double rightEdge = tileCX + (double) ERODE_TILE_CENTER;
        double bottomEdge = tileCZ + (double) ERODE_TILE_CENTER;
        double fx = 0; int ncx = tileCX;
        if (rightEdge - wuX <= w) {
            double b = 1.0 - (rightEdge - wuX) / w;
            fx = 0.5 * b * b * (3.0 - 2.0 * b);
            ncx = tileCX + ERODE_TILE_CENTER;
        } else if (wuX - tileCX < w) {
            double b = 1.0 - (wuX - tileCX) / w;
            fx = 0.5 * b * b * (3.0 - 2.0 * b);
            ncx = tileCX - ERODE_TILE_CENTER;
        }
        double fz = 0; int ncz = tileCZ;
        if (bottomEdge - wuZ <= w) {
            double b = 1.0 - (bottomEdge - wuZ) / w;
            fz = 0.5 * b * b * (3.0 - 2.0 * b);
            ncz = tileCZ + ERODE_TILE_CENTER;
        } else if (wuZ - tileCZ < w) {
            double b = 1.0 - (wuZ - tileCZ) / w;
            fz = 0.5 * b * b * (3.0 - 2.0 * b);
            ncz = tileCZ - ERODE_TILE_CENTER;
        }
        if (fx > 0 || fz > 0) {
            // ★★★ 2026-09-17【确定性修复】★★★
            //   旧写法是 `erosionTileCache.get(...)`（只读窥探），邻居缺失就把
            //   d10/d01/d11 退化为 d00（= 本 tile 未 blend 的值）⇒ **同一个
            //   (seed, 坐标) 的 height 取决于"查询时邻居 tile 在不在缓存"**，
            //   而邻居是异步 fire-and-forget 预热的（见 getOrGenTile）+ 会被 LRU 驱逐
            //   ⇒ 产出依赖【生成顺序 / 线程调度】，违反本项目"纯函数铁律"。
            //   门禁实锤：runHydrologyDeterminismProbe ❌[1] max|A−B| = 1.15e-5（≈0.0022 块）
            //     ❌[2] 正序 vs 倒序 max|Δheight| = 0.0515 块（ΔriverSurfaceY/Δgradient 均为 0）。
            //   ⚠ 2026-09-18 校正：以上两个值是【修复前】的 FAIL 实证，原注释误标为 ✅。
            //     门禁判据是【逐位相等】（HydrologyDeterminismProbe 的 TOL = 0.0）
            //     ⇒ 任何非零值都是 FAIL，不存在"足够小就算通过"。
            //     修复后实测（seed 5436529513624899584）：
            //     [1] max|A−B| = 0、[2] max|Δheight| = 0 ⇒ ALL PASS（与 HANDOFF 记录一致）。
            //
            //   修法：缺失即【同步生成】(neighborTile)。neighborTile 与"已缓存"分支
            //   **必然同值**（tile 是 (seed, 坐标) 的纯函数）⇒ 缓存状态不再影响结果。
            //
            //   ⚠ 为何这次不会重演 2026-08-14 的"数百次同步生成 400~719ms"：
            //     那次是【缓存抖动】—— 容量 256 且异步预热把刚用到的邻居挤掉，于是
            //     逐格 miss → 反复重建。现在①每个 tile 至多触发 3 个**不同**邻居
            //     （computeIfAbsent 去重）②容量已加大（见 ERODE_TILE_CACHE_SIZE）
            //     ③命中时走 tileCacheGet（含 LRU 触碰，防"刚用就被驱逐"）。
            //   回退：把这 3 行改回 erosionTileCache.get(...)。
            //   ⚠ allowGen 闸门（★ 2026-09-17）：只有【主地形路径】(erosionDeltaE) 允许
            //     现场生成邻居；peekErosionDeltaE / applyCachedTileDelta 的契约是
            //     "绝不触发生成"（2026-09-11 P0-1 止血：结构放置阶段高频调用，
            //     同步生成 400~719ms/个 ⇒ 世界生成卡死）⇒ 它们保持"纯窥探 + d00 兜底"。
            //     代价：放置/群系快速路径在 tile 带内仍是近似（**既有行为**，本次不变）。
            ErosionTileResult tx = blendNeighbor(tileKey(ncx, tileCZ), ncx, tileCZ, allowGen);
            ErosionTileResult tz = blendNeighbor(tileKey(tileCX, ncz), tileCX, ncz, allowGen);
            ErosionTileResult txz = blendNeighbor(tileKey(ncx, ncz), ncx, ncz, allowGen);
            double d00 = delta;
            double d10 = tx != null ? sampleTileField(tx.delta, tx.originX, tx.originZ, wuX, wuZ) : d00;
            double d01 = tz != null ? sampleTileField(tz.delta, tz.originX, tz.originZ, wuX, wuZ) : d00;
            double d11 = txz != null ? sampleTileField(txz.delta, txz.originX, txz.originZ, wuX, wuZ) : d00;
            delta = d00 * (1 - fx) * (1 - fz)
                  + d10 * fx * (1 - fz)
                  + d01 * (1 - fx) * fz
                  + d11 * fx * fz;
        }
        return delta;
    }

    /**
     * 对 Cell 施加 wu 坐标处的侵蚀增量（含 tile 边界 blend），并重算 height/重分类。
     * extractFromTile 与 sampleWu 共用的公共逻辑。
     */
    private void applyTileDelta(Cell cell, double wuX, double wuZ) {
        if (morphBase) {
            double denom = 2.0 * Math.max(0.01, params.horizontalScale());
            cell.gradient = (float) Math.hypot(baseWorld.heightDifferenceX(wuX, wuZ) / denom,
                    baseWorld.heightDifferenceZ(wuX, wuZ) / denom);
            return;
        }
        double delta = erosionDeltaE(wuX, wuZ);

        // ★ 2026-08-14 晚场（用户建议"流量累积图当梯度图用起来"）：RIVER_NETWORK 图层
        //   显示粒子侵蚀 discharge 场 = 流量累积图（液滴沿坡流动的集水累积，
        //   本质是地形梯度/流域方向的可视化）。erosionDeltaE 内部已把本 tile 拉进缓存，
        //   此处 getOrGenTile 必命中（或同步中断 → 与 delta=0 一致地跳过）。
        int tileCX = Math.floorDiv((int) Math.floor(wuX), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int tileCZ = Math.floorDiv((int) Math.floor(wuZ), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        // ★ 2026-09-19 诊断：取 tile 子项（每格第 2 次）
        long tg1 = com.geogenesis.diagnostics.WorldGenProfiler.begin();
        ErosionTileResult res = getOrGenTile(tileCX, tileCZ);
        com.geogenesis.diagnostics.WorldGenProfiler.end(
                com.geogenesis.diagnostics.WorldGenProfiler.Stage.EXGET, tg1);
        // ★ 2026-09-19 诊断：落格子项（含陆地重分类，每格 1 次）
        long tc0 = com.geogenesis.diagnostics.WorldGenProfiler.begin();
        try {
            coreApplyDelta(cell, delta, res, wuX, wuZ);
        } finally {
            com.geogenesis.diagnostics.WorldGenProfiler.end(
                    com.geogenesis.diagnostics.WorldGenProfiler.Stage.EXCORE, tc0);
        }
    }

    /**
     * 【非阻塞】把<b>已缓存</b>的侵蚀增量施加到 cell（含 height 重算 / 陆地重分类 / 坡度），
     * 使群系快速路径 {@code sampleCellLight} 在已探索区域与完整管线<b>收敛</b>。
     *
     * <p>★ 2026-09-11 B2：快速路径原本只跑 {@link #sample}（无侵蚀），导致
     * ① {@code terrainType} 与完整管线（侵蚀后重分类）在海岸/火山等阈值边缘不一致；
     * ② {@code height} 不含侵蚀（也不含河谷雕刻）—— 当前群系判定不读 height，但属
     * <b>潜在陷阱</b>（降水/风场等后续消费者要读）。本方法与 {@link #applyTileDelta}
     * 共用 {@link #coreApplyDelta}，差别仅是 tile 缺失时【放弃】而非触发生成。</p>
     *
     * @return true = 已施加侵蚀增量；false = tile 未生成，cell 保持原样（绝不阻塞）
     */
    public boolean applyCachedTileDelta(Cell cell, double wuX, double wuZ) {
        if (morphBase) return false;
        int tileCX = Math.floorDiv((int) Math.floor(wuX), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int tileCZ = Math.floorDiv((int) Math.floor(wuZ), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        ErosionTileResult res = erosionTileCache.get(tileKey(tileCX, tileCZ));
        if (res == null) return false;              // 未生成 → 绝不触发
        coreApplyDelta(cell, blendTileDelta(res, wuX, wuZ, tileCX, tileCZ, false), res, wuX, wuZ);
        return true;
    }

    /**
     * 侵蚀增量施加核心（{@link #applyTileDelta} 与 {@link #applyCachedTileDelta} 共用）：
     * discharge 场 → e/height 更新 → 陆地重分类 → 坡度。{@code res} 可为 null（中断语义）。
     */
    private void coreApplyDelta(Cell cell, double delta, ErosionTileResult res,
                                double wuX, double wuZ) {
        if (res != null && res.discharge != null)
            cell.riverNetDischarge = sampleTileField(res.discharge, res.originX, res.originZ, wuX, wuZ);
        // RIVER_TYPE 图层与 isLake/lakeMask 统一由水文雕刻计划写入
        // （GeoGenesisTerrain.applyHydrologyValley / GeoGenesisGenerator.applyHydrologyChunk）。
        // 旧 RTF 河网已下线：此处曾对每个 cell 采样几何河网写入上述字段，既与水文结果
        // 互相覆盖造成误导，又是逐 cell 的无效开销。

        // 对全地形施加侵蚀增量（**含海洋**）。
        // 原先用 `delta * cell.blendCont` 保护海洋侧（blendCont=0 → delta=0），
        // 但这导致**水下完全没有侵蚀**——河谷/水下峡谷被擦除，河口三角洲也异常平整。
        // 现已废除：ErosionEngine 自身已有 NaN/Inf 守卫（spd sqrt 处 + 末尾 clampF(-1,1)），
        // 不会再产生柱子伪影。delta 直接施加给所有地形（含海洋/陆架/深海）。
        // NaN/Inf 守卫：避免 fillTerrainColumn 因 (int)Math.floor(NaN)→0 把全列铺到世界底。
        double newE = cell.e + delta;
        if (Double.isNaN(newE) || Double.isInfinite(newE)) newE = cell.e;
        double e = softCapLandE(newE);
        cell.e = e;
        cell.height = heightCurve.heightFromE(e);

        // 重分类：仅陆地侧（e>=0），避免海洋的 12 类细分被破坏
        if (e >= 0) {
            TerrainClass ct = TypeLandShape.dominantFromWeights(cell.typeWeights);
            // ★ 2026-09-13 修复：必须传入 cell.landFeat —— 否则侵蚀 tile 生成后
            //   该区块的 VOLCANO/VOLCANIC_FIELD 会被重分类抹掉
            //   （用户反馈："大范围预览显示火山，关掉就不显示火山了，改显示其他类型"）。
            cell.terrainType = classifyTerrain(e, cell.eLand, ct, cell.temperature,
                cell.humidity, cell.typeWeights, cell.coastCoord, cell.landFeat);
        }

        // 坡度（陡坡裸岩用）：取 tile 的【侵蚀后】高度网格做 ±1 wu 中心差分。
        // ★ 必须用 tile 网格而非 chunk 的 16×16：chunk 边缘只能 clamp → 16 块间距的接缝。
        //   tile 自带 padding，跨 tile 连续；且 postErosion 已含侵蚀 → 与真实地表一致。
        if (res != null && res.postErosion != null) {
            double hs = Math.max(0.01, params.horizontalScale());
            double hxp = heightCurve.heightFromE(
                sampleTileField(res.postErosion, res.originX, res.originZ, wuX + 1.0, wuZ));
            double hxm = heightCurve.heightFromE(
                sampleTileField(res.postErosion, res.originX, res.originZ, wuX - 1.0, wuZ));
            double hzp = heightCurve.heightFromE(
                sampleTileField(res.postErosion, res.originX, res.originZ, wuX, wuZ + 1.0));
            double hzm = heightCurve.heightFromE(
                sampleTileField(res.postErosion, res.originX, res.originZ, wuX, wuZ - 1.0));
            // 1 wu = hs 块；中心差分跨 2 wu → 除以 2*hs 得「每块抬升」
            double dhx = (hxp - hxm) / (2.0 * hs);
            double dhz = (hzp - hzm) / (2.0 * hs);
            cell.gradient = (float) Math.sqrt(dhx * dhx + dhz * dhz);
        }
    }

    /**
     * wu 语义完整采样（含侵蚀 tile delta 叠加；SpikeLocateProbe 诊断用）。
     * 基础 sample + {@link #applyTileDelta}，与 extractFromTile 同源。
     */
    public Cell sampleWu(double wuX, double wuZ) {
        Cell cell = sample(wuX, wuZ);
        applyTileDelta(cell, wuX, wuZ);
        return cell;
    }

    /**
     * 仅采样侵蚀后高度，与 sampleWu().height 同源，跳过气候、分类和坡度计算。
     * 增量后的第二次 softCap 必须保留；height-only 探针覆盖真实压缩窗口及负对照。
     * 可触发侵蚀 tile 生成，不是非阻塞 peek。
     */
    public double erodedHeight(double wuX, double wuZ) {
        if (morphBase) return baseWorld.height(wuX, wuZ);
        double e0 = terrainEQuick(wuX, wuZ);
        double ne = e0 + erosionDeltaE(wuX, wuZ);
        if (Double.isNaN(ne) || Double.isInfinite(ne)) ne = e0;
        return heightCurve.heightFromE(softCapLandE(ne));
    }

    /**
     * ★ 2026-09-14 探针专用：<b>直接以给定原点跑一次侵蚀</b>（不走 tile 缓存）。
     *
     * <p>供 {@code HardnessRaceProbe} 复现"多线程共享 ErosionEngine 实例"的竞态 ——
     * 走缓存会被 tile 复用掩盖（同一 tile 只算一次），无法并发触发。</p>
     */
    public void runErosionAtForProbe(int originX, int originZ, double hs) {
        // ★ 必须与生产同构：bufSize = N + pad*2（pad=9，见 generateErosionTile）
        //   初版误用 bufSize = N ⇒ 液滴走到 flat 边界越界（Index 16384 of 16384）。
        int n = ERODE_TILE_SIZE;
        int pad = 9;
        int bufSize = n + pad * 2;
        float[] flat = new float[bufSize * bufSize];
        for (int z = 0; z < bufSize; z++) {
            for (int x = 0; x < bufSize; x++) {
                flat[z * bufSize + x] =
                        (float) Math.max(terrainEQuick(originX - pad + x, originZ - pad + z), -0.05);
            }
        }
        float[] pre = flat.clone();
        erosion.runErosionOnFlat(flat, pre, bufSize, n, originX, originZ,
                (float) heightCurve.seaE(), 1.0f, null, (float) hs);
    }

    /** 探针专用：直接生成/取 tile 结果（ErosionPeriodProbe 用，不经 getOrGenTile 的中断捕获）。 */
    public ErosionTileResult getErosionTileResultForProbe(int tileCX, int tileCZ) {
        // ⚠【测量口径】本入口刻意【不】走 getOrGenTileUnchecked ⇒ 不计入
        //   hydro.tile.solve / cache.EROSION_TILE.COMPUTE，否则探针会把生产统计污染掉。
        long k = tileKey(tileCX, tileCZ);
        ErosionTileResult r = erosionTileCache.get(k);
        if (r == null) {
            r = generateErosionTile(tileCX, tileCZ);
            erosionTileCache.putIfAbsent(k, r);
        }
        return r;
    }

    /**
     * 取 tile 结果（缓存命中优先，缺失则同步生成——blend 懒邻居语义保留，并发安全 putIfAbsent）。
     *
     * <p><b>2026-08-10 中断安全（v2，修正过严缓存）</b>：预览拖动 cancelAll → Worker 线程中断 →
     * generateErosionTile 的 latch.await 抛 CancellationException（绝不"恢复标志后继续用未完成数据"）
     * → 此处返回 null，半成品不入缓存（永久污染 → 方块伪影）。
     * <b>但成功返回的 tile 无条件入缓存</b>——生成结果确定性完整，即使线程随后被 cancel(true)
     * 置了中断位也应缓存（否则拖动取消 → 已完成 tile 反复重算 → 面板卡顿）。
     * 注意：InterruptedException 抛出时中断位已被 JVM 清除，无需（也禁止）重新 interrupt()——
     * 重新置位会让后续任务的 isInterrupted() 检查误判，且不参与取消语义（取消判据 = canceled 标志）。</p>
     */
    /**
     * 窗口覆盖的可选预热：独立小型池，饱和即停止提交，不等待、不运行在调用者上。
     * 未预热的 tile 由必需查询生成，生成内容及 blend 语义不变。
     */
    public void prewarmErosionTiles(double blockX0, double blockZ0, double blockSpan, double hs) {
        if (morphBase) return;
        double wu0x = blockX0 / hs, wu0z = blockZ0 / hs;
        double wu1x = (blockX0 + blockSpan) / hs, wu1z = (blockZ0 + blockSpan) / hs;
        // tile 键用 floorDiv(wu, CENTER)*CENTER
        int t0x = Math.floorDiv((int) Math.floor(wu0x), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int t0z = Math.floorDiv((int) Math.floor(wu0z), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int t1x = Math.floorDiv((int) Math.floor(wu1x), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int t1z = Math.floorDiv((int) Math.floor(wu1z), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int nx = (t1x - t0x) / ERODE_TILE_CENTER + 1;
        int nz = (t1z - t0z) / ERODE_TILE_CENTER + 1;
        // 刚需从低坐标向高坐标扫描；预热从另一端推进，避免先占住刚需马上要取的tile。
        for (int a = nx - 1; a >= 0; a--) {
            for (int b = nz - 1; b >= 0; b--) {
                if (!scheduleTilePreheat(t0x + a * ERODE_TILE_CENTER,
                        t0z + b * ERODE_TILE_CENTER)) return;
            }
        }
    }

    private boolean scheduleTilePreheat(int cx, int cz) {
        long key = tileKey(cx, cz);
        if (erosionTileCache.containsKey(key) || erosionTilesInFlight.containsKey(key)
                || !queuedTilePreheats.add(key)) return true;
        try {
            TILE_PREHEATER.execute(() -> {
                try {
                    // 已有刚需生成者时不占住预热池等待其 future。
                    if (!erosionTilesInFlight.containsKey(key)) getOrGenTile(cx, cz);
                } finally {
                    queuedTilePreheats.remove(key);
                }
            });
            return true;
        } catch (RejectedExecutionException e) {
            queuedTilePreheats.remove(key);
            com.geogenesis.diagnostics.WorldGenProfiler.stutterLog("A", "preheat-rejected",
                    "queue=" + TILE_PREHEATER.getQueue().size());
            return false; // 可选工作放弃；刚需采样仍同步补齐，不改变内容。
        }
    }

    private ErosionTileResult getOrGenTile(int tileCX, int tileCZ) {
        long k = tileKey(tileCX, tileCZ);
        ErosionTileResult r = tileCacheGet(k);
        if (r == null) {
            // ★★ 2026-09-19 修复（性能）：中断位已置 ⇒ 立即放弃，不尝试生成。
            //   与 neighborTile 同一机制的另一个入口 —— 且本方法在 erosionDeltaE 里
            //   【先】被调用（每格 1 次），若不拦，风暴会在这里发生而根本走不到 blend。
            //   详见 neighborTile 处的完整推导；产出不变（原本也是 null → delta=0 兜底）。
            if (Thread.currentThread().isInterrupted()) return null;
            // ★★★ 2026-10-10【统一到占位式生成（不持 bin 锁、不重复计算）】★★★
            //   原先此处内联一份占位逻辑、neighborTile 用 computeIfAbsent、
            //   generateErosionTile 内部 8 邻预热又是第三份 ⇒ 三处不一致。
            //   现统一委托 getOrGenTileUnchecked（语义：创建者生成、其它线程 join 复用）。
            r = getOrGenTileUnchecked(tileCX, tileCZ);
        }
        return r;
    }

    /**
     * ★ 2026-09-17：blend 的邻居取法（见 {@link #neighborTile} 与
     * {@link #blendTileDelta} 的确定性说明）。
     *
     * @param allowGen {@code true} = 主地形路径：缺失即同步生成（结果与"已缓存"必然同值 ⇒ 顺序无关）；
     *                 {@code false} = 非阻塞路径（结构放置 / 群系快速路径）：
     *                 保持"纯窥探 + d00 兜底"，绝不触发生成（P0-1 延迟契约）
     */
    private ErosionTileResult blendNeighbor(long key, int tileCX, int tileCZ, boolean allowGen) {
        return allowGen ? neighborTile(key, tileCX, tileCZ) : tileCacheGet(key);
    }

    /**
     * 侵蚀 tile 缓存查询入口 —— 命中埋点 + LRU 触碰（★ 2026-09-11 P0-3）。
     * 集中入口可避免各处直接 {@code .get} 导致统计与 LRU 序失准。
     */
    private ErosionTileResult tileCacheGet(long key) {
        ErosionTileResult r = erosionTileCache.get(key);
        if (r != null) {
            r.lastAccess = tileAccessClock.incrementAndGet();
            tileCacheStats.hit();
        } else {
            tileCacheStats.miss();
        }
        return r;
    }

    /**
     * ★ 2026-09-17【确定性修复】取邻居 tile：<b>缺失即同步生成</b>（不触发 8 邻预热，
     * 避免二级级联）。
     *
     * <p>为什么必须有这一步：tile delta 是 {@code (seed, 世界坐标)} 的纯函数，
     * 因此"已缓存"与"现场生成"必然同值 —— 只要<b>缺失时补算</b>，缓存状态就不再
     * 影响产出（这正是 {@code blendTileDelta} 此前只有窥探、缺失退化 d00 所破坏的性质）。</p>
     *
     * <p>中断语义与 {@code getOrGenTile} 一致：{@code generateErosionTile} 在池线程
     * 被中断时抛 {@link CancellationException} ⇒ 返回 {@code null}，调用方退回 d00
     * （该 chunk 由调用方丢弃/重采，见 {@code erosionDeltaE} 的说明）。</p>
     */
    private ErosionTileResult neighborTile(long key, int tileCX, int tileCZ) {
        ErosionTileResult r = tileCacheGet(key);
        if (r != null) return r;
        // ★★ 2026-09-19 修复（性能；实测单块 extract 103 秒的根因路径）：
        //   <b>中断位已置 ⇒ 立即放弃，绝不再尝试生成。</b>
        //
        //   机制（为何是一百秒而不是一百毫秒）：
        //   线程被 cancel(true) 后 flag 常驻 → generateErosionTile 内部的 ForkJoin
        //   并行段（parallelRows，跑在 commonPool）抛 CancellationException
        //   → 本方法 return null 且【半成品绝不入缓存】（见上方 1755 行注释）
        //   → 下一个 cell 再试 → 每块 256 格 × 至多 3 个邻居 ≈ 768 次
        //   → 每次白烧"到抛点之前"的 CPU（tile 生成实测均 246ms）
        //   ⇒ 768 × ~130ms ≈ 100 秒，且【全部计入 EXTRACT、完全不计入 TILEGEN】
        //     （TILEGEN 记账在 generateErosionTile 末尾，中止的生成走不到）
        //   ⇒ 这正是实测"TILEGEN 仅 70 次 / 17.2s，而单块 extract 达 103s"的原因。
        //
        //   ⚠ 产出不变：原本也是返回 null（d00 兜底），本改动只是不再白烧 CPU。
        //   ⚠ 判据放在缓存查询【之后】：已缓存 tile 即使 flag 置位也照常返回，
        //     符合"成功返回的 tile 无条件可用"的既有语义。
        if (Thread.currentThread().isInterrupted()) return null;
        try {
            // ★ 2026-09-18 诊断：同上（blend 邻居路径，每 chunk 最多 768 次访问）
            long tw0 = com.geogenesis.diagnostics.WorldGenProfiler.begin();
            // ★★★ 2026-10-10【改用占位式（不持 bin 锁）】★★★
            //   原用 computeIfAbsent ⇒ 生成期间（100~700ms）持 CHM bin 锁 ⇒ 阻塞同 bin
            //   的其它线程（本文件 1014-1019 行的既有结论）。现与 getOrGenTile 统一：
            //   只对"创建占位"上锁（微秒级），生成在锁外进行，并发线程 join 复用结果。
            ErosionTileResult nr = getOrGenTileUnchecked(tileCX, tileCZ);
            if (nr == null) return null;
            com.geogenesis.diagnostics.WorldGenProfiler.endIfSlow(
                    com.geogenesis.diagnostics.WorldGenProfiler.Stage.TILEWAIT, tw0, 1_000_000L);
            nr.lastAccess = tileAccessClock.incrementAndGet();
            return nr;
        } catch (CancellationException ce) {
            // ★ 2026-09-19：不再重新 interrupt() —— 本文件 1757 行本就规定
            //   "无需（也禁止）重新 interrupt()"。且 CancellationException 并不清除
            //   中断位，故该调用本就是空操作（移除后语义不变）。
            return null;
        } catch (java.util.concurrent.CompletionException ce) {
            // 生成者失败（中断/异常）⇒ 与旧行为一致地返回 null
            return null;
        }
    }

    /**
     * 侵蚀 tile 缓存有界驱逐 —— <b>真 LRU</b>（★ 2026-09-11 P0-3）。
     *
     * <p>原实现为「超 256 任意删 1/8」：ConcurrentHashMap 无访问序，删掉的可能正是
     * 刚生成的热点 tile（~128KB、生成 400~719 ms）→ 玩家原地打转也会反复重建。
     * 现按 {@link ErosionTileResult#lastAccess} 淘汰最久未访问者。本方法仅在
     * <b>超容量时</b>触发（约每 32 次生成一次），O(n log n)（n≈256）开销可忽略。</p>
     */
    private void pruneErosionCache() {
        int size = erosionTileCache.size();
        if (size <= ERODE_TILE_CACHE_SIZE) return;
        int toRemove = Math.max(1, size / 8);
        // 注意：本类 import 了 com.geogenesis.worldgen.noise.*（含名为 Map 的类），
        // 与 java.util.Map 冲突 → 此处必须用全限定名。
        List<java.util.Map.Entry<Long, ErosionTileResult>> entries =
            new ArrayList<>(erosionTileCache.entrySet());
        entries.sort(Comparator.comparingLong(e -> e.getValue().lastAccess));
        for (int i = 0; i < toRemove && i < entries.size(); i++) {
            if (erosionTileCache.remove(entries.get(i).getKey()) != null) {
                tileCacheStats.evicted();
                HydrologyMetrics.cache(Cache.EROSION_TILE, Outcome.EVICT);
            }
        }
    }

    /**
     * 从 tile 网格按 wu 坐标双线性插值读字段。HS=1 时 wu 为整数 → 直接索引（逐位等价旧实现）。
     * 越界返回 0（border 外无数据，delta=0 语义）。
     */
    private static float sampleTileField(float[][] field, int originX, int originZ, double wuX, double wuZ) {
        double lx = wuX - originX, lz = wuZ - originZ;
        int ix = (int) Math.floor(lx), iz = (int) Math.floor(lz);
        if (ix < 0 || ix >= ERODE_TILE_SIZE - 1 || iz < 0 || iz >= ERODE_TILE_SIZE - 1) {
            if (ix >= 0 && ix < ERODE_TILE_SIZE && iz >= 0 && iz < ERODE_TILE_SIZE) return field[iz][ix];
            return 0f;
        }
        float fx = (float) (lx - ix), fz = (float) (lz - iz);
        float v00 = field[iz][ix], v10 = field[iz][ix + 1];
        float v01 = field[iz + 1][ix], v11 = field[iz + 1][ix + 1];
        float top = v00 + (v10 - v00) * fx;
        float bot = v01 + (v11 - v01) * fx;
        return top + (bot - top) * fz;
    }

    /**
     * 连续形态分类（使用 typeWeights 连续权重替代离散 argmax）。
     * 海洋区域按特征分量细分：大陆架 / 洋中脊 / 海山 / 海洋 / 深海。
     */
    public TerrainClass classify(double c, double e, double eLand,
                                  TerrainClass cellType, double[] typeWeights,
                                  double temperature, double humidity,
                                  OceanFeatures.FeatureResult oceanFeat,
                                  LandFeatures.FeatureResult landFeat,
                                  double cEdge) {
        if (e < 0.0) {
            // 海洋地形细分
            double ridgeAmp = oceanFeat != null ? oceanFeat.ridge : 0;
            double seamountAmp = oceanFeat != null ? oceanFeat.seamount : 0;
            // ★ 2026-09-13 Phase T6：火山弧（离轴隆起）也是"海中的显著凸起"，
            //   语义上同属 SEAMOUNT（海底火山）。不新增枚举 —— 见 TerrainClass 说明。
            //   注意 oceanFeat.arc 是【带符号】剖面（>0 弧 / <0 海沟窄槽），故取正部判断。
            double arcAmp = oceanFeat != null ? Math.max(0.0, oceanFeat.arc) : 0;
            // ★★★ 2026-09-13 修复（用户反馈"大陆架好像并没有包住整个大陆"）★★★
            //   深度分带判据由 `oceanFeat.baseE`（c 场推算的海底基面）改为 **eLand**。
            //
            //   【为何是 bug】**海岸线是由 eLand 定义的**（e = eLand + 海洋特征，e=0 即海岸）。
            //   用 c 场推算的 baseE 分带 ⇒ 陆架带与真实海岸线**错位**：
            //   实测沿海海洋点仅 **52.2%** 被判 SHELF，且与构造体制无关
            //   （活动边缘 60.8% / 被动边缘 46.9% —— 若真是"活动边缘无陆架"的地质正确性，
            //    该比例应与构造强相关，实测反之 ⇒ 纯属两个场错位）。
            //   改用 eLand 后同一实测升至 **81.4%**（其余为海山/洋中脊优先 + 真属陆坡）。
            //
            //   【为何不破坏原注释的初衷】原用 baseE 是为了"不含特征增量，防止海山顶峰
            //   被抬升后自相矛盾地判成 SHELF"（见下方 2026-08-06 记录）。
            //   而 `eLand` **同样不含海洋特征增量**（features 在 oceanFeat.total 里单独叠加）
            //   ⇒ 该防线完整保留，同时海岸线对齐。两全。
            //
            //   【分带随之成为沿岸等深带】地质正确的陆架→陆坡→深海平原序列：
            //     eLand > −0.08           → 大陆架
            //     −0.18 < eLand ≤ −0.08   → 海洋（陆坡 / 浅海）
            //     eLand ≤ −0.18           → 深海（深海平原）
            //   （2026-08-06 旧记录：原用逐点 e 会自相矛盾 —— 海山顶峰 e>−0.08 被判 SHELF，
            //     探针实测 SEAMOUNT 仅 11 个。改用 eLand 后该问题不复现，因它不含特征增量。）
            // SEAMOUNT 判定优先于 RIDGE（海山独立特征，避免被洋中脊抢走）。
            if ((seamountAmp > 0.02 || arcAmp > 0.02) && eLand < -0.08) return TerrainClass.SEAMOUNT;
            // 2026-08-06 调稀洋中脊：阈值 0.03→0.05（用户反馈"洋中脊有点多"）——边缘弱贡献区
            // 归入 OCEAN/DEEP_OCEAN，仅脊线主体保留 RIDGE 类型（地形抬升不受影响）。
            if (ridgeAmp > 0.05 && eLand < -0.08) return TerrainClass.SUBMARINE_RIDGE;
            if (eLand > -0.08) return TerrainClass.CONTINENTAL_SHELF;
            return eLand < -0.18 ? TerrainClass.DEEP_OCEAN : TerrainClass.OCEAN;
        }
        // 【2026-08-03 用户决策】BEACH 不再作为独立地形类型（沙滩是海岸过渡带而非地形形态）：
        // 海岸窄条自然落入后续陆地类型（PLAIN/HILLS 等），群系层面仍由 BiomeClassifier 按气候映射。

        // 火山优先（可见特征，用户核心诉求：陆地需有火山地形）。
        TerrainClass vol = volcanoClass(landFeat);
        if (vol != null) return vol;

        // 【2026-08-05 用户决策】PEAK 不再作为独立地形类型（山峰=山脉的高海拔部分，
        // 与 BEACH/SNOW 同为状态/过渡而非独立形态）：高海拔山地直接落入 MOUNTAINS
        // （typeWeights dominant），雪峰/尖峰群系由 BiomeClassifier 按 cell.e>0.60 映射，不丢失。
        return cellType;
    }

    /**
     * ★ 2026-09-13 修复（用户反馈"火山只在大范围预览显示，关掉就没有了"）：
     * <b>火山优先判定</b>（主 {@link #classify} 与侵蚀后静态重分类<b>共用</b>）。
     *
     * <p><b>为何要抽成共用函数</b>：原先 {@code classify} 有这段判定，而
     * {@code classifyTerrain}（侵蚀回写后调用）<b>没有</b>，且其签名里根本没有
     * {@code landFeat} 参数 ⇒ 侵蚀 tile 生成后（近距离，预览放大时）该区块的
     * {@code VOLCANO/VOLCANIC_FIELD} 被<b>静默重分类</b>成底层类型（PLAIN/MOUNTAINS…）
     * ⇒ 用户看到的"远处有火山、走近就没了"。
     * 抽成一处可保证<b>两个入口的阈值永不漂移</b>。</p>
     *
     * @return 火山类型；非火山返回 {@code null}（调用方继续后续判定）
     */
    private static TerrainClass volcanoClass(LandFeatures.FeatureResult landFeat) {
        if (landFeat == null) return null;
        // ★ 2026-09-13 修复（用户反馈"火山中间竟然是旁边的地形"）：
        //   判据由【净抬升 single/field（含火口下凹）】改为【山体掩码 singleEdifice/fieldEdifice
        //   （不扣火口）】。原因：火口在中心下凹 0.02~0.07 e，当 amp 较小时
        //   `single(中心) = amp − crater` 会跌破阈值（实测 amp=0.12, crater=0.07
        //   → 恰好 0.05，严格大于不成立）⇒ 中心被判成周围类型，火山只剩一圈"环形"。
        //   而地质上<b>火口内部仍属这座火山</b>（火山口湖亦是火山的一部分）⇒ 应按"山体覆盖"判。
        //
        // ★ 2026-09-13 阈值修正（用户反馈"火山类型包不全火山的山体"）：
        //   原阈值 0.05 / 0.04 是**任意常数**，与"地形上看得见"没有关系。
        //   陆地 1 e = (maxY−seaLevel)×peakFraction = 257×0.92 ≈ 236 格 ⇒
        //   0.05 e ≈ 11.8 格 —— 远高于"可见"的门槛（~2 格 ≈ 0.0085 e）。
        //   后果：山体外缘（抬升 2~11 格、肉眼明显是火山锥面）被判成周围类型。
        //   现按【可见地形】定阈值：0.010 e ≈ 2.4 格 ⇒ 类型覆盖≈可见山体。
        if (landFeat.singleEdifice > 0.010) return TerrainClass.VOLCANO;
        if (landFeat.fieldEdifice > 0.010) return TerrainClass.VOLCANIC_FIELD;
        return null;
    }

    /**
     * 静态分类方法（侵蚀回写后重分类用）。
     */
    public static TerrainClass classifyTerrain(double ne, double eLand,
                                                TerrainClass cellType,
                                                double temperature, double humidity) {
        return classifyTerrain(ne, eLand, cellType, temperature, humidity, null, 0.0, null);
    }

    /**
     * 静态分类方法（带连续类型权重 + coastCoord 海岸约束）。
     * PEAK/SNOW 使用 typeWeights 连续阈值，避免离散 argmax 跳变。
     * 海洋区域按深度细分：大陆架 / 海洋 / 深海（无特征分量，仅靠 e）。
     *
     * <p>★ 2026-09-13 新增 {@code landFeat} 参数：侵蚀回写后必须与 {@link #classify}
     * 用<b>同一套火山判定</b>，否则火山类型会在侵蚀 tile 生成后被抹掉（见
     * {@link #volcanoClass} 注释）。传 {@code null} 表示"该调用点不掌握火山信息"
     * （退化为不判火山，与旧行为一致）。</p>
     */
    public static TerrainClass classifyTerrain(double ne, double eLand,
                                                TerrainClass cellType,
                                                double temperature,
                                                double humidity,
                                                double[] typeWeights,
                                                double coastCoord,
                                                LandFeatures.FeatureResult landFeat) {
        if (ne < 0.0) {
            if (ne > -0.08) return TerrainClass.CONTINENTAL_SHELF;
            return ne < -0.18 ? TerrainClass.DEEP_OCEAN : TerrainClass.OCEAN;
        }
        // 【2026-08-03 用户决策】BEACH/SNOW 不再作为独立地形类型（见主 classify 注释）。
        // ★ 火山优先（与主 classify 一致）——修复"侵蚀后火山消失"。
        TerrainClass vol = volcanoClass(landFeat);
        if (vol != null) return vol;
        // 【2026-08-05 用户决策】PEAK 不再独立分类（山峰=山脉高海拔部分，群系由
        // BiomeClassifier 按 cell.e 阈值映射），此处直接取 typeWeights 主导类型。
        if (typeWeights != null && typeWeights.length >= TerrainClass.COUNT) {
            return TypeLandShape.dominantFromWeights(typeWeights);
        }
        return cellType;
    }

    /** 兼容旧签名的重载（不判火山）。 */
    public static TerrainClass classifyTerrain(double ne, double eLand,
                                                TerrainClass cellType,
                                                double temperature,
                                                double humidity,
                                                double[] typeWeights,
                                                double coastCoord) {
        return classifyTerrain(ne, eLand, cellType, temperature, humidity,
                typeWeights, coastCoord, null);
    }

    // ===== 内联工具 =====

    /**
     * 降水合成（★ 2026-09-11 Phase B）。
     *
     * <pre>
     * precip = humidity01        // 水汽供给（湿度 [−1,1] → [0,1]）
     *        × LatPrecipProfile   // 纬度结构（ITCZ 峰 / 副热带谷 / 西风带次峰 / 极地低）
     *        × (1 + 地形雨)        // 迎风坡抬升凝结
     *        × (1 − 雨影)          // 背风坡减雨
     *        × tempGate           // 冷空气持水能力低（下限 0.55，不归零）
     * </pre>
     *
     * <p><b>Phase B 只"产出"降水</b>（写入 {@link Cell#precipitation} 与
     * {@link com.geogenesis.worldgen.climate.Climate#precipitation}）：
     * <b>尚未驱动水文</b>（Phase C 才把汇流累积改为受降水加权），
     * 也<b>尚未参与 Whittaker 群区</b>（Phase D 才切换，避免群系立刻漂移）。</p>
     *
     * @return 归一化降水 [0, 1.5]
     */
    private static double precipitationFrom(double humE, double tempE, double lat01,
                                            PrecipField.Mod pm) {
        double humidity01 = clamp(humE * 0.5 + 0.5, 0.0, 1.0);
        double base = humidity01 * LatPrecipProfile.at(lat01);
        double tempGate = 0.55 + 0.45 * ((tempE + 1.0) * 0.5);   // 冷 → 0.55，热 → 1.0
        double v = base * (1.0 + pm.orographicGain()) * (1.0 - pm.shadowLoss()) * tempGate;
        return clamp(v, 0.0, 1.5);
    }

    /**
     * 计算温度的"寒冷权重"（样条连续值）。
     * 综合 frozenWeight + coldWeight，用于 SNOW/冰雪判定。
     * 在温度阈值附近平滑过渡，避免硬边界跳变。
     */
    private static double temperatureColdWeight(double temperature) {
        GeoGenesisConfig cfg = GeoGenesisConfig.INSTANCE;
        if (cfg != null) {
            ClimateSpline spl = ClimateSpline.temperature(
                cfg.tempFrozenThreshold.get(),
                cfg.tempColdThreshold.get(),
                cfg.tempWarmThreshold.get(),
                cfg.tempHotThreshold.get());
            // frozen + cold 区域权重之和
            return spl.zoneWeight(temperature, ClimateSpline.TEMP_FROZEN)
                 + spl.zoneWeight(temperature, ClimateSpline.TEMP_COLD);
        }
        // 默认：简单线性插值
        return temperature < -0.6 ? 1.0 : temperature < -0.2 ? (-0.2 - temperature) / 0.4 : 0.0;
    }

    /**
     * 抖动后的主导地形类型（<b>仅用于群系变体选择</b>，见 {@code Cell.variantTerrain}）。
     *
     * <p>地形类型场是两个 Voronoi 站点高斯权重相等处 → 边界为<b>直线段</b>（站点上下排列时
     * 即长水平线，实测达 424 wu）。若群系变体直接按 {@link Cell#terrainType} 切换，
     * 群系边界就沿这条直线走。此处对每类权重叠加独立高频噪声后取最大：
     * 边界附近两类权重接近，噪声使主导类型随机翻转 → 变体边界被打散。
     *
     * @param weights 5 类地形权重（按 {@link TerrainClass#ordinal()} 索引，和=1）
     */
    private TerrainClass ditheredTerrain(double[] weights, double x, double z) {
        if (weights == null || weights.length == 0) return null;
        TerrainClass[] all = TerrainClass.values();
        int best = -1;
        double bestW = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < weights.length && i < all.length; i++) {
            // 每类独立噪声（坐标加不同偏移），波长 ≈ 区尺寸/3 ≈ 128 wu（2026-09-10：调大，变体斑块更完整）
            double dith = regionWarp.compute(x * 3.0 + i * 733.0, z * 3.0 - i * 1499.0) * 0.12;
            double w = weights[i] + dith;
            if (w > bestW) {
                bestW = w;
                best = i;
            }
        }
        return best >= 0 ? all[best] : null;
    }

    /**
     * 气候区边界的 3 倍频扰动位移（wu）。
     * 用同一噪声按坐标倍频叠加（1、2、4 倍），省掉额外噪声实例；
     * 幅值 0.25/0.12/0.06 × regionSize，合计最大约 0.43 个区尺度。
     */
    private double regionWarpOffset(double x, double z) {
        double o = regionWarp.compute(x, z) * 0.25
                 + regionWarp.compute(x * 2.0, z * 2.0) * 0.12
                 + regionWarp.compute(x * 4.0, z * 4.0) * 0.06
                 + regionWarp.compute(x * 8.0, z * 8.0) * 0.04
                 + regionWarp.compute(x * 16.0, z * 16.0) * 0.02;
        return o * regionSize;
    }

    /**
     * 区域层温度：纬度基值 + 区域级扰动。区界处与次近区混合 → C0 连续。
     */
    private double regionTemperature(ClimateRegion.Sample reg) {
        double t1 = temperatureAt(reg.centerX(), reg.centerZ());
        if (reg.blend() <= 0.0) return t1;
        double t2 = temperatureAt(reg.centerX2(), reg.centerZ2());
        return t1 + (t2 - t1) * reg.blend();
    }

    /** 单点温度基值：纬度梯度（赤道 +1 → 两极 −1）+ 温度扰动噪声 */
    private double temperatureAt(double x, double z) {
        double lat = Latitude.latitude01(z, 1.0 / tempFreq);
        return (1.0 - 2.0 * lat) + tempWarp.compute(x, z) * 0.15;
    }

    /** 区域层湿度：区域噪声，区界处与次近区混合 → C0 连续 */
    private double regionMoisture(ClimateRegion.Sample reg) {
        double m1 = humidityNoise.compute(reg.centerX(), reg.centerZ());
        if (reg.blend() <= 0.0) return m1;
        double m2 = humidityNoise.compute(reg.centerX2(), reg.centerZ2());
        return m1 + (m2 - m1) * reg.blend();
    }

    /**
     * 海拔递减率（参考 FreeTerraForged 的 ClimateModule.modifyTemp）。
     * e≤0.35 基本不降温，0.35→0.65 线性增强，e≥0.65 达到最大 0.16。
     * 逐格生效 → 山体保有真实垂直气候分异，群系因而"看得见地形"。
     */
    private static double elevationTempDrop(double e) {
        if (e <= 0.35) return 0.0;
        if (e >= 0.65) return 0.16;
        return 0.16 * (e - 0.35) / 0.30;
    }

    /**
     * 高海拔/山地雨影导致的减湿：e≤0.25 无影响，0.25→0.60 线性增强，最大 0.20。
     *
     * <p>【2026-09-10】原先用类型权重 {@code montW} 驱动（{@code -montW*0.25}），
     * 但地形类型权重在类型边界处变化很快 → 相邻格湿度可跳变 0.2 以上，
     * 直接跨过 Whittaker 的中间分区（探针实测违例）。改用连续高程 e 后同一效应平滑得多。
     */
    private static double elevationMoistureDrop(double e) {
        if (e <= 0.25) return 0.0;
        if (e >= 0.60) return 0.20;
        return 0.20 * (e - 0.25) / 0.35;
    }

    /**
     * 大陆性对湿度的调制（参考 FreeTerraForged 的 ClimateModule.modifyMoisture）。
     * 海洋/沿海 → 拉向湿润；深内陆 → 拉向干燥（大陆性才是湿度主控，噪声只提供区域差异）。
     *
     * @param hum       区域级湿度 [-1,1]
     * @param continent 大陆性 [-1,1]（负=海洋，0=海岸，正=内陆）
     */
    private static double continentMoisture(double hum, double continent) {
        double c01 = clamp(continent * 0.5 + 0.5, 0.0, 1.0); // 0=深海 0.5=海岸 1=深内陆
        double m01 = hum * 0.5 + 0.5;
        double limit = 0.5;                                   // 海岸线位置
        if (c01 < limit) {
            double k = (limit - c01) / limit * 0.55;          // 海洋侧：最多把湿度拉向 1 的 55%
            m01 += (1.0 - m01) * k;
        } else {
            double k = (c01 - limit) / (1.0 - limit) * 0.55;  // 内陆侧：最多拉向 0 的 55%
            m01 -= m01 * k;
        }
        return clamp(m01 * 2.0 - 1.0, -1.0, 1.0);
    }

    private static double clamp(double v, double lo, double hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    /**
     * 陆地 e 软钳制（实际地形 < 理论峰顶铁律）：
     * 类型高端 maxLandHi（默认 0.95 → 理论峰顶 Y≈288）之上渐近压缩、永不触顶，
     * 实际 e 恒低于 maxLandHi，HeightCurve 的 clamp(e×verticalScale,0,1) 永不触发 → 无压平山尖、
     * 不超配置地形图表的理论最高高度。海洋侧（e≤0）不受影响（clamp 下界 -1 保底）。
     */
    private double softCapLandE(double e) {
        if (e <= 0.0) return Math.max(-1.0, e);
        double maxLandHi = params.splineConfig().maxLandHi();
        // 2026-08-01：压缩窗口起点 0.92→0.97×maxLandHi（0.874→0.922）。
        // 原起点太贴上限：山峰自然分布 p99≈0.8745（MOUNTAINS p99=0.89）落在窗口内 →
        // 峰尖被压平（用户"山脉碰生成上限"观感，HeightHitProbe 实测 max=0.9044 且 2% 进入压缩区）。
        // 0.97 后 99% 山峰自然尖峰保留，仅超设计极限（>0.92）的极端叠加兜底压缩。
        double softStart = maxLandHi * 0.97;
        if (e <= softStart) return e;
        double cap = maxLandHi * 0.98;       // 实际天花板（默认 0.931），低于理论 0.95
        double span = cap - softStart;
        return softStart + span * (1.0 - 1.0 / (1.0 + (e - softStart) / span));
    }
    private static double saturate(double v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }
    private static double smoothstep(double edge0, double edge1, double x) {
        double t = saturate((x - edge0) / (edge1 - edge0));
        return t * t * (3.0 - 2.0 * t);
    }

    /**
     * 安全读取 Forge 配置值（委托公共门面 {@link com.geogenesis.config.ConfigSafe}）。
     * 游戏内（config 已加载）→ 正常返回 toml 值；独立预览/探针（config 未加载运行时）
     * 的 {@code ConfigValue.get()} 会抛 IllegalStateException，此时回退到代码默认值。
     * 仅在配置未加载时改变行为，不影响游戏内结果。
     */
    private static double cfgDbl(net.minecraftforge.common.ForgeConfigSpec.DoubleValue v, double fallback) {
        return com.geogenesis.config.ConfigSafe.dbl(v, fallback);
    }

    private static boolean cfgBool(net.minecraftforge.common.ForgeConfigSpec.BooleanValue v, boolean fallback) {
        return com.geogenesis.config.ConfigSafe.bool(v, fallback);
    }

    /** 采样大陆性快捷接口 */
    public double sampleContinent(double wx, double wz) {
        return continent.sample(wx, wz);
    }

    /** HeightCurve 引用 */
    public HeightCurve heightCurve() { return heightCurve; }

    /** TypeLandShape 引用 */
    public TypeLandShape typeLandShape() { return typeLandShape; }

    // ===== 诊断访问器 =====

    /** 包级私有：获取缓存的侵蚀 tile 结果（用于 ErosionTileProbe 诊断）。返回 null 若 tile 未生成。 */
    ErosionTileResult getTileResult(int tileCX, int tileCZ) {
        return erosionTileCache.get(tileKey(tileCX, tileCZ));
    }

    /**
     * discharge 场采样（wu 语义）——供 RIVER_NETWORK 预览图层使用。
     *
     * <p>双线性插值侵蚀 tile 的 discharge 数组。历史要点（保留以免回退）：
     * ①48 对齐中心（曾用 128 网格错位 → discharge 恒 0）；
     * ②<b>缓存优先（缺失返回 0 不生成）</b>——同步生成侵蚀 tile 约 670ms/个，
     * 会卡死首 chunk（曾见 place=2183/4964/6576ms）；
     * ③null 防御（CancellationException → 0）。</p>
     *
     * @return discharge 值（侵蚀关闭 / 无数据 = 0）
     */
    public double sampleDischarge(double wuX, double wuZ) {
        int tileCX = Math.floorDiv((int) Math.floor(wuX), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int tileCZ = Math.floorDiv((int) Math.floor(wuZ), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        ErosionTileResult r = erosionTileCache.get(tileKey(tileCX, tileCZ));
        if (r == null) r = getOrGenTile(tileCX, tileCZ); // 探针/诊断：缺失生成（游戏路径用 cached 版）
        // ★ 2026-08-14 null 防御：tile 生成被取消（CancellationException → getOrGenTile
        //   返回 null）时返回 0——曾直接 r.discharge → NPE 中断 chunk 生成 → 河流雕刻被
        //   跳过（用户"实际河道完全没变动"候选根因）
        if (r == null) {
            if (dischargeDiagCount.getAndIncrement() < 5) {
                LOGGER.info("[RIVER-DIAG#{}] tile null tile=({},{}) thread={}",
                    dischargeDiagCount.get() - 1, tileCX, tileCZ, Thread.currentThread().getName());
            }
            return 0;
        }
        if (r.discharge == null) {
            if (dischargeDiagCount.getAndIncrement() < 5) {
                LOGGER.info("[RIVER-DIAG#{}] discharge null tile=({},{}) erosionOn={} thread={}",
                    dischargeDiagCount.get() - 1, tileCX, tileCZ, erosionEnabledDiag(),
                    Thread.currentThread().getName());
            }
            return 0;
        }
        double v = sampleTileField(r.discharge, r.originX, r.originZ, wuX, wuZ);
        // ★ 2026-08-14 诊断：前 5 次采样全打印（用 LOGGER——System.out 不写 latest.log，
        //   用户日志无 DIAG 的根因）
        if (dischargeDiagCount.getAndIncrement() < 5) {
            float max = 0; long nz = 0;
            for (float[] row : r.discharge) {
                for (float f : row) {
                    if (f > max) max = f;
                    if (f > 0.01f) nz++;
                }
            }
            LOGGER.info("[RIVER-DIAG#{}] sample=({},{})={} tile=({},{}) arrMax={} nz={} erosionOn={} thread={}",
                dischargeDiagCount.get() - 1, wuX, wuZ, v, tileCX, tileCZ, max, nz,
                erosionEnabledDiag(), Thread.currentThread().getName());
        }
        return v;
    }

    /**
     * discharge 场采样（缓存优先，**不触发生成**）——游戏河网构建用（性能铁律：
     * 生成版会同步生成侵蚀 tile 670ms/个 → 首 chunk 卡死 2-6s）。
     * tile 未生成（如 applyTileDelta 尚未覆盖的区域）→ 0（无引导，走地形评分，可接受）。
     */
    public double sampleDischargeCached(double wuX, double wuZ) {
        int tileCX = Math.floorDiv((int) Math.floor(wuX), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        int tileCZ = Math.floorDiv((int) Math.floor(wuZ), ERODE_TILE_CENTER) * ERODE_TILE_CENTER;
        ErosionTileResult r = erosionTileCache.get(tileKey(tileCX, tileCZ));
        if (r == null || r.discharge == null) return 0;
        return sampleTileField(r.discharge, r.originX, r.originZ, wuX, wuZ);
    }

    /** 诊断：erosionEnabled 配置实际值（探针无 Forge 配置 → no-config） */
    private static String erosionEnabledDiag() {
        try {
            GeoGenesisConfig cfg = GeoGenesisConfig.INSTANCE;
            return cfg == null ? "no-config" : String.valueOf(cfg.erosionEnabled.get());
        } catch (Throwable t) {
            return "no-config(" + t.getClass().getSimpleName() + ")";
        }
    }

    /** ★ discharge 诊断计数（前 5 次采样打印） */
    private static final java.util.concurrent.atomic.AtomicInteger dischargeDiagCount = new java.util.concurrent.atomic.AtomicInteger();

}
